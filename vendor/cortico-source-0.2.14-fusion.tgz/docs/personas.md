<!-- Owner: src/core/types.ts (Persona), src/bot.ts -->

# Persona 与 Bot

Persona 定义一类 Bot 的语义:上下文怎么构造、有哪些 session、认知流程、交接策略、对 Memory 的
解释与操作工具。Bot 是一份装配定义:选一个 Persona、声明一组 World、给出默认配置。两者都在
`bots/<名>/` 下,进版本控制,或者作为 `kind: "bot"` 的扩展包装在 `extensions/` 下(见
[extensions.md](extensions.md));Memory 与配置在部署里。

## Persona 契约

Core 在生命周期节点调用 Persona 钩子。Persona 通过钩子返回值和注入接口提供上下文中的语义内容。

必填:

| 成员 | 含义 |
|---|---|
| `systemSegments(ctx)` | system 前缀的有序命名段,Core 逐字拼接 |
| `memoryDir` | Memory 目录绝对路径 |
| `blobs` | `mem:` 句柄的后端。句柄要能原样当工具参数传:可打印字符,用 `/` 分隔,不含 `..` 和空段;World 校验句柄时按这个形状放行 |
| `attach(core)` | 拿到 `CoreApi`;在 `declareSessions` 之前调用 |
| `declareSessions()` | session 声明,恰好一个 `receivesEvents` 且 `persistent`(见 [sessions.md](sessions.md)) |

可选时机钩子:`onOpening({ reason })`(session 开场)、`onDelivery({ events })`(一批唤醒项投递刻;
可返回 Promise,Core 等它完成再投递，完成前 `injectInternal` 的项加入本批)、`onBatchEnd()`(一批处理结束,可执行上下文容量策略)、
`onTurnEnded()`、`onIdle()`、`onStallsRecovered()`(回一句措辞或 null)、
`onWorldLifecycle(event)`、`sessionHead()`(合成开头:置于 system 之后、持久历史之前的 item 列表,每次请求现取,不落盘)、
`onHandoff(snapshot, { hardTokens })`(回 `{ tail, trim? }`)、`promptVarValues(ctx)`、
`ownToolNames()`(自有工具名,装配层据此拒绝工具名冲突的 World,并在 `createBot()` 时对照 `BotDefinition.describe.tools`,
不在其中的名字记一条 warn、在 Persona 页列出;未提供时仅告警并保留先注册的工具,也不做这项对照)、
`cognition`(处理 World 的后台认知请求)、`webUi()`(Persona 页的声明;其中 `memory` 子声明是
Memory 页的面板、模板与存储项)。
Persona 页的标题取 Persona 的类名;Memory 页的标题先取 `BotDefinition.memoryName`,
没给就取 `Persona.memory` 的类名,两者都没有时是 `Memory`。
钩子的异常处理方式见 [Core 文档](../src/core/README.md)。

工具不在 Persona 上,在每个 `SessionDecl.tools()` 里;`end_turn`、`save_blob` 这类是 bot 侧的
Persona 工具,Core 只认 `ToolDef.endsTurn`。仓内 bot 的 Persona 工具声明是模块常量(`CORMINI_TOOL_DECLS` 等),
`BotDefinition.describe.tools` 用 `describeTools(decls, summaries)` 从同一份声明拼成。

`CoreApi` 是 Persona 唯一的 Core 入口:`injectInternal` / `injectDeferred` / `injectExternal`(都可带附件，规则同 World 事件的 `blobs`)、
`requestContextHandoff`、`spawnFork`、`sessionInfo`、`llm`、`timers`、`deliveryGate`、
`personaState` / `savePersonaState`(不透明状态,Core 只负责原子持久化)、`toolsTagged`、
`blob`、`log`。

## Bot 定义

包代码通过 `cortico/<src 下的路径>` 导入框架,如 `cortico/bot.ts`、`cortico/core/types.ts`。
仓内包和扩展包使用相同的导入路径。

`bots/<名>/index.ts` 默认导出 `BotDefinition`:

| 字段 | 含义 |
|---|---|
| `id` | 包 id;仓内包与目录同名 |
| `memoryName` | 可选,Memory 页的标题 |
| `defaults()` | bot 默认配置,可包含 World 段。启动器用 `withWorlds()` 补充内建与扩展 World 中缺失的默认段,保留此处已有的段 |
| `declares` | 默认启用的 World id;未安装时显示为不可用。已安装但未声明的 World 默认关闭,部署可自行启用 |
| `build(loaded, worlds)` | 创建 Persona,返回 `BotParts { persona, worlds?, llm?, onStart?, onStop?, webUi? }` |
| `describe` | 可选,自描述:Persona 的全部工具与 Memory 的形式,见 [extensions.md](extensions.md)「自描述」 |

`createBot()` 的顺序:算提示词覆盖目录 → 定默认语言 → `WorldAssembly` → `build()` → `Core` →
装配层绑定挂载钩子 → 收配置组(含未激活槽位)→ provider 设置页与端点编辑 → `WebApp`。
`start()`:单实例锁 → WebUI → 启动 active provider → `onStart` → `core.start()`。
`activeProvider` 为空或指向不存在的端点时跳过这一步,WebUI 照常起来,由操作员在模型供应商页
配置;状态里的 `modelConnection` 报当前端点。

## 包里有什么

| 路径 | 内容 |
|---|---|
| `index.ts` | `BotDefinition`,声明包 id、默认配置与装配方法 |
| `persona/` | Persona 代码与它的提示词模板(`PREFIX.md`、`ENV_SECTION.md`、`CORE.md`…) |
| `webui/client.ts` | Persona 页的面板 bundle(可选) |
| `worlds/<id>/config.json`、`worlds/<id>/ENV_PROMPT.md` | 对某个 World 的默认配置与环境提示词覆盖 |
| `vtuber-pack/` | 挂 `cortico-world-vtuber` 的包才有:演出词表、曲线、参数集 |

部署里的东西见 [deployment.md](deployment.md)。

## 参考 bot

| 包 | Persona | 一句话 | 端口 | Memory |
|---|---|---|---|---|
| `corti-soulmate` | `CortiSoulmate` | 分层记忆、交接后并行梦、QQ 起草-确认门、宪法归梦修订 | 7777 | `memory/` |
| `cormini` | `Cormini` | 最小完整实现:工作区即记忆、宪法即前缀、一个 session、只有控制台 | 7788 | `workspace/` |
| `cortiv` | `CortiV` | AI VTuber 实时系统:演出舞台、B 站直播间、游戏 | 7789 | `workspace/` |

## 添加 Bot

- 继承:像 `cortiv` 那样 `class CortiV extends Cormini`,差异写成独立类的行为(覆写时机钩子、
  前缀段、交接策略),不给基类加构造开关。
- 复制:要改记忆结构或 session 形态时,复制 `bots/cormini/` 整个目录再改 `persona/`。

修改 `index.ts` 中的 `id` 与 `web.port`,再在部署根下创建引用此包的部署。
框架提供通用 WebUI 页,专有面板通过 `webUi()` 声明。

## 换 Memory 后端

Memory 存在哪、怎么读写由 Persona 决定，Core 没有记忆后端的接口。换后端就写一个 `kind: "bot"` 的
扩展包(见 [extensions.md](extensions.md)「写一个 bot 扩展」),在它的 Persona 里接自己的存储;
`templates/extension/bot/` 可作起点，把其中的 `memory_write` 与 `persona/blobs.ts` 换成自己的实现。

| 成员 | 接自己的存储时 |
|---|---|
| `memoryDir` | 仍须是绝对路径;Core 不读它,`check:extension` 只校验它是字符串。存储不在本机时给 `build()` 收到的 `loaded.memoryDir`(部署的 `paths.memory`),放缓存或本地状态 |
| `blobs` | 实现 `BlobStore` 的 `put`、`get`、`list`,字节存进自己的后端。Core 只调 `get`,用于把 `mem:` 附件发给模型、在 WebUI 显示，以及 `WorldHost.blob()` 与 `CoreApi.blob()`;`put` 与 `list` 由 Persona 自己调 |
| 记忆工具 | 读、写、检索记忆的工具放进自己 session 的 `SessionDecl.tools()`,名字列进 `BotDefinition.describe.tools` |
| 上下文里的记忆 | 由 `systemSegments()`、`sessionHead()` 或 `injectInternal` 给出;Core 不从 Memory 取文本 |
| `memory` | 可选，放后端实例;Core 不读它的内容 |

权限、版本冲突、幂等与超时都在 Persona 里处理。`onDelivery` 返回的 Promise,Core 等它完成再投递，不设期限，
钩子发起的外部调用由 Persona 自己设超时。
