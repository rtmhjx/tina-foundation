<!-- Owner: src/providers/base.ts, src/providers/webui/hub.ts, src/providers/hub-api.ts, src/providers/name.ts, src/providers/registry.ts, src/providers/webui/settings.ts, src/providers/webui/config.ts, src/providers/openai-responses-compat/config.ts, src/providers/openai-responses-compat/native.ts, src/providers/llamacpp/config.ts, src/providers/llamacpp/options.ts, src/providers/llamacpp/native.ts, src/providers/llamacpp/huggingface.ts, src/providers/transport/responses-input.ts, src/providers/pricebook.ts, src/core/generation.ts (PriceSnapshot, priceUsage) -->

# Provider

Provider 适配模型服务的通信协议。仓库内建 `openai-responses-compat`（原生 Responses API）与
`llamacpp`（本机 llama-server，支持下载和进程托管）；其他实现通过扩展包安装，如
`cortico-provider-grok`。模型在端点配置中选择，Persona 不指定模型。

卸载供应商扩展时,`ProviderHub.removeModule` 持端点表的写锁(`providers/.write-lock`)确认没有供应实例引用它,
有就回 409 并列出实例名;没有就从本进程的模块注册里撤下,再删包。撤下后新建、保存、预览和已打开面板的调用都找不到这个模块;
删包失败则恢复注册。撤下只作用于本进程,共用同一端点表的其他部署不受影响。

## 端点表

`config.providers` 是一张以端点名为键的表,`config.activeProvider` 指其中一个。每条端点:

| 字段 | 含义 |
|---|---|
| `kind` | provider 模块的 id，决定通信协议的实现 |
| `baseUrl` | 模型服务的基础 URL |
| `secret` | 自定义密钥环境变量名；优先读取进程环境，其次读取端点目录的 `.env` |
| `spec` | 模型与生成参数：`model`、`thinking`、`reasoningEffort`、`temperature`、`maxTokens`、`contextWindow` |
| `multimodal` | 是否接受图片 |
| `serviceTier` / `pricing` / `options` | 服务档位、价目、模块自定义项 |

主 session 与 fork 用哪个端点见 [sessions.md](sessions.md)。
provider 模块不预设任何模型名;端点
没有 `spec` 就不能被设为 active。新环境端点表为空；已有端点目录与原 activeProvider 引用继续读取。

## 端点目录

同一部署根下的各部署共用端点配置。每个 `<部署根>/providers/<端点名>/` 目录包含端点的
`config.json` 和存放密钥的 `.env`，同名密钥优先读取进程环境。目录内其余文件由 provider
模块管理。各部署在自己的 `config.json` 中设置 `activeProvider`。

## WebUI

模型供应商页列出共享端点,一次编辑其中一条。选中一条不改变 `activeProvider`,「设为当前」只写
当前部署的那一项。字段改动随手暂存在浏览器,切走再回来接着编,「放弃更改」丢掉暂存;保存时整条端点
一次写入配置与密钥;暂存不进共享配置,API Key 不写入浏览器。保存带上读取时的 revision,配置或密钥
已被别处改过就返回 409,重新加载后再保存。复制端点只在新端点有密钥变量且与来源同名时复制 `.env`,没有密钥变量的端点(已登录账号的令牌)不复制。改名连带目录和部署根内各部署的 `activeProvider` 引用一起改;
还被引用的端点不能删。`kind` 保存后不可更改。

编辑页的段落顺序由模块声明:模块在 `webUi()` 的 `panels` 里把编辑页自带的
四块(`connection-endpoint` 地址与密钥、`connection-model` 模型与生成、`connection-pricing` 计价、
`connection-protocol` 协议,默认文案由 `connectionBlocks` 给)与自己的面板排成一列,标题与说明可改;
一块都不声明的模块得到默认顺序,自家面板排在模型与计价之间。`openai-responses-compat` 是
连接→模型→思维链→计价→协议,`llamacpp` 是服务地址→运行时→模型→模型与生成→计价→协议。
每个段落可折叠,面板声明的 `defaultOpen` 是初始状态,省略时展开;操作员折叠或展开后,浏览器按段落 id
记住,所有端点共用。`connectionBlocks` 里计价与协议默认收起。
面板的 `setConfig` 同样只进暂存;运行时启停、安装与拉取模型要求端点已保存。「测试连接」与
「获取模型列表」按编辑页当前内容(含刚输入的 API Key)发请求,不写盘,不参与可用性判断。
连接测试与正式生成一样使用流式请求；响应中的错误或流提前中断会报告为失败。
取到的模型(`ProviderInstance.listModels()` 的返回项;没带 `contextWindow` 的项用 `ProviderInstance.contextWindow(id)` 补上;llamacpp 端点不补,它的列表只带已探测过的窗口)进入模型选单,标签取 `displayName`,缺省用 id;
选一项等同手填它的 id:该项的 `contextWindow` 填进上下文上限,`inputImages` 设定图像开关,
`maxOutputTokens` 只显示,不改最大输出。列表外的 id 照样可以手填。

WebUI 保存的 `secret` 遵循环境变量名格式 `[A-Za-z_][A-Za-z0-9_]*`。
只填密钥值未填变量名时,默认名按端点名派生:`CORTICO_KEY_<端点名>`,`-` 折成 `_`。
从磁盘直接加载的名字按字面匹配;密钥值写入端点 `.env` 的同名项。

## 可用性

一个端点可用,是指它此刻能发起一次生成:选了模型、声明的 `secret` 读得到,模块自己的条件
也满足。判断只看本地状态,不连上游——探活是操作员按出来的另一件事。模块的那部分由
`ProviderModule.availability` 回答,不实现就只有通用条件(`llamacpp` 用它回答托管运行时装没装)。

控制台页从状态帧读取当前端点的名称、模型、模块与地址,点开就是那条端点;一条都不可用时,输入框
的灰字写明去哪儿设置。

## 内建 openai-responses-compat

`POST <baseUrl>/responses`,每次请求重放完整上下文。整条响应为 `completed` 时,没带 `status` 的
`function_call` 项补成 `completed`;响应未完成时原样交给 Core,Core 不执行这些调用。历史推理按
`options.reasoningReplay` 回传:
`encrypted`(默认)只回 `encrypted_content`,且只回来源实例、模块、兼容域与模型均匹配的项,受
`keepPastThinking` 控制;`plaintext` 把推理文字以 `reasoning_text` 回传、不带签名块(没有文字只有签名块的项按 `encrypted` 的来源规则),最后一条 user 消息之后的
那一轮不受 `keepPastThinking` 约束,没有记录来源的工具调用前补一项合成推理(`options.sendSyntheticReasoning`
为 false 时不补;探测的明文一侧始终补)。签名块要靠
`include` 取回,所以只有 `encrypted` 形态的请求带 `include: ['reasoning.encrypted_content']`;
不认 `include` 的端点因此只在这一形态上会拒收整条请求。项的 `id` 是签发它的服务端的资源 id:来源实例、
模块或兼容域与本次请求不同的 message、function_call、function_call_output 出线时不带 `id`,
`call_id` 照带;同一来源和没有记录来源的项(Core 合成的 `msg_` / `fc_` / `fco_`)保留 `id`。模块的 `detect`
探测发两条诊断请求(合成调用不带 / 带明文推理),按上游接受哪种写回 `reasoningReplay`。
`options.endpointPath`、
`options.extraHeaders`、`options.extraBody` 分别改路径、加头、并进请求体(`extraBody` 最后
合并,能覆盖 `service_tier` 之类)。模型列表走 `GET <baseUrl>/models`;行里有 `name`、`context_length`、
`top_provider.max_completion_tokens`、`architecture.input_modalities` 时,分别成为列表项的
`displayName`、`contextWindow`、`maxOutputTokens` 与 `inputImages`(模态含 `image`)。

`spec` 同时填了 `contextWindow` 与 `maxTokens` 时,`contextWindow` 必须大于 `maxTokens`,否则保存与设为当前都被拒绝。
模型上下文上限取服务探测值与配置的 `contextWindow` 中的较小者；Core 根据该上限限制请求
容量，阶段预算由 Persona 决定（见 [sessions.md](sessions.md)）。

## 内建 llamacpp

`POST <baseUrl>/chat/completions`,思维链是模板开关(`chat_template_kwargs.enable_thinking`),
回执里的 `reasoning_content` 归一成推理项,历史里的随每次请求照原样发回;
`keepPastThinking` 关时只留合成开头那一条,思维链关时一条不带。两种用法由 `options.runtime` 有无
决定:

- **外部**:连接独立运行的 llama-server。通过 `/health` 检查状态、`/props?model=`
  读上下文窗口、`/models` 列模型(带加载状态与输入模态,输入模态给出列表项的 `inputImages`)。
- **托管**:端点页的运行时段落点「开启托管」后,`options.runtime` 记版本 tag 与后端,`options.launch`
  记 `-c` / `-ngl` / `--parallel` 与附加参数,`options.autoStart` 决定 bot 启动时是否一并起。
  运行时和启动配置由模块的 `ConfigGroup` 声明,端点面板复用 WebUI schema 渲染器,
  修改经 `setConfig` 校验并保存。
  「下载并安装」把所选官方 release 解压到 `<部署根>/runtimes/llama.cpp/<tag>/<平台-后端-架构>/`;
  「启动」以 router 模式起 llama-server,不带模型,`LLAMA_CACHE` 与 `--models-dir` 指向
  `<部署根>/models/llamacpp/`。启动参数在下一次启动时生效,面板会标出待生效。
  端点已有外部服务时不接管该进程。

模型段落调用 llama-server 的 `/models*` 接口。输入 HuggingFace 仓库 id 后，由服务器
下载到缓存，面板从接口读取进度和状态。搜索框查 HuggingFace 上带 `gguf` 标签的仓库,站点与
llama-server 拉取的同一个(`MODEL_ENDPOINT`,其次 `HF_ENDPOINT`,缺省 huggingface.co);点开一个仓库
列出它的 GGUF 文件,量化标签从文件名读出,「拉取」按 `仓库:标签` 下载。本机 GGUF 放入 `local/`
目录后需要重新扫描。`spec.model` 使用模型列表中的 id，「选用」把它填进模型段落,首次请求时由
router 自动加载。
目录约定见 [runtimes.md](runtimes.md)。

## 传输

一次生成可包含多次请求尝试,重试间隔为 1s / 4s / 10s;状态 0、408、429 与 5xx 重试,401/403 先刷新一次凭证。
流里的 `error` 事件是上游自己报的失败,不重试。非 2xx 的错误消息是 `LLM API <状态码>: <上游的错误说明>`,
说明取 JSON 正文的 `error.message` 或 `message`,没有就取正文，压成一行;完整正文在 `GenerationError.body`。
响应带 `Retry-After` 时按它退避,等待与生成中的其他等待一样可被调用方中断。
已提交不可逆增量之后不再重试。终态只接受 `completed` 与 `incomplete`:截断落成
`incomplete_details.reason`,被截断的工具调用由 Core 标成未执行。输出字符数超过
`max_output_tokens × 12` 时终止请求并报告输出字符数超限。

## 计价

每次请求尝试按价目中声明的计量项计费,包括输入、输出、缓存命中与推理用量等,币种默认 USD,写入
`data/usage.jsonl`;WebUI「用量」页与 `/api/usage` 聚合。所选币种没有原价的调用按 1 USD 的汇率从别的币种换算：Core 打开用量页时先向 open.er-api.com 取实时汇率，失败依次换 currency-api 的两个地址，结果缓存 12 小时，全部失败 10 分钟内不再请求；一次也没取到时用 `USAGE_RATES`(`src/core/config.ts`)里 2026-10-10 的中间价。模块自带价目,端点条目的 `pricing`
按成本基准覆盖。`pricing` 为空时仍使用模块价目;两者都没有适用价目时,调用只记用量,
不记金额。缺少所需计量的费用项记为未知。

一份价目按三个维度依次选档:时段、服务档、输入阶梯。`timeWindows` 里的每个窗口自带一张完整
价目表(`rules`,可再带 `inputBands` 与 `serviceTiers`),`from`、`to` 是 `timezone` 这个时区的
`HH:MM`,左闭右开,`to` 不晚于 `from` 表示跨零点。`weekdays`(ISO 星期,1 为周一、7 为周日)限定
窗口在哪些日期开始,`exceptDates`(`YYYY-MM-DD`)去掉个别日期;跨零点的一段算在它开始的那天。
节假日表由 provider 扩展自己维护,Core 不带任何地区的日历。选档按请求开始时刻,命中的第一个窗口为准,
都不命中用窗口外的那张表;窗口随价目写进快照,重算历史流水得到同一结果。窗口的时区、时刻、星期
或日期读不出来时,这次调用的金额记为未知。

内建 provider 不带分时段价目,端点的 `pricing` 也不接受 `timeWindows`:按时段计费由 provider
扩展在自己的模块价目里声明。

## 添加 Provider

写一个 provider 扩展:`kind: 'provider'`,默认导出 `ProviderModule`,带 `describe`(见 [extensions.md](extensions.md)「自描述」)。接口与注册流程见
[src/providers/README.md](../src/providers/README.md),打包见 [extensions.md](extensions.md)。
