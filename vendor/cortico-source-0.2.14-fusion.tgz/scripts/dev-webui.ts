import { ProviderHub } from '../src/providers/webui/hub.ts';
import { ProviderSettings } from '../src/providers/webui/settings.ts';
import { ProviderRegistry } from '../src/providers/registry.ts';
import type { FixtureMessage } from '../tests/core/fixture-messages.ts';
import { fixtureRecords } from '../tests/core/fixture-messages.ts';
import { responseTimelineFixture } from '../tests/web/response-timeline-fixture.ts';
import { functionCall, functionResult, message } from '../src/protocol/open-responses/context.ts';
/**
 * 使用代表性固定夹具启动 WebApp，供前端开发与截图核验。
 * 不连接真实 API，不启动 core。
 *   npx tsx scripts/dev-webui.ts          → http://127.0.0.1:8848/
 *   CORTICO_PORT=9000 npx tsx scripts/dev-webui.ts
 *   CORTICO_DEV_MINIMAL=1 npx tsx scripts/dev-webui.ts   → 只挂框架级那一套(见下方 MINIMAL)
 *   CORTICO_DEV_PASSWORD=xxx npx tsx scripts/dev-webui.ts → 带访问密码起,用来看登录页
 */
import { mkdirSync, mkdtempSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { createServer } from 'node:http';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { deflateSync } from 'node:zlib';
import { loadConfig } from '../bots/corti-soulmate/assemble.ts';
import { assembleSystem, renderWorldEnvPrompt } from '../src/core/prefix.ts';
import { JsonlEventStore } from '../src/core/event-store.ts';
import { LogBlobStore, withBlobLines } from '../src/core/blobs.ts';
import type { BlobRef } from '../src/core/types.ts';
import { CortiSoulmate } from '../bots/corti-soulmate/persona/index.ts';
import { QQWorld } from '../src/worlds/qq/world.ts';
import { qqConfigGroup } from '../src/worlds/qq/config.ts';
import { ConsoleWorld } from '../src/worlds/console/world.ts';
import { WebSearchWorld } from '../src/worlds/websearch/world.ts';
import { LocalizedError, type Language } from '../src/core/language.ts';
import { webSearchConfigGroup, WEBSEARCH_DEFAULTS } from '../src/worlds/websearch/config.ts';
import { minecraftClientConfigGroup, minecraftConfigGroup, MINECRAFT_DEFAULTS, minecraftPlayerConfigGroup, minecraftRhythmConfigGroup, type MinecraftConfigSection } from '../src/worlds/minecraft/config.ts';
import { minecraftPanelDecls } from '../src/worlds/minecraft/world.ts';
import { flatPresets, levelTypeLabels } from '../src/worlds/minecraft/server-config.ts';
import { bilibiliConfigGroup, BILIBILI_DEFAULTS } from '../src/worlds/bilibili/config.ts';
import { bilibiliPanelDecls } from '../src/worlds/bilibili/world.ts';
import { BUILTIN_OVERLAY_STYLES, normalizeOverlayDesign } from '../src/worlds/bilibili/overlay/model.ts';
import { OverlayAssetStore } from '../src/worlds/bilibili/overlay/assets.ts';
import { BilibiliOverlayServer, OverlayEditorConflictError } from '../src/worlds/bilibili/overlay/server.ts';
import type { AgentAnnouncementState, BilibiliOverlayDesign, VideoQueueState } from '../src/worlds/bilibili/overlay/types.ts';
import { PromptRevisionConflict, WebApp, type ExtensionComment, type ExtensionDescribe, type ExtensionInfo, type ExtensionRating, type ExtensionSearchHit, type MarketTag, type OwnedStoragePart, type ToolOwner, type WebAppMarketDeps } from '../src/web/server.ts';
import { EXTENSION_API_VERSIONS, parseExtensionManifest } from '../src/extensions/manifest.ts';
import { PREVIOUS_CONTRACT_VERSIONS } from '../src/extensions/previous-contract.ts';
import { pageIdFor } from '../src/web/shared/webui-protocol.ts';
import { deriveWebUiPageSources, ioPageContribution } from '../src/bot.ts';
import { WorldAssembly } from '../src/world.ts';
import { WebUiFixtureWorld } from '../src/worlds/webui-fixture/world.ts';
import { CORE_CONFIG_GROUP } from '../src/core/config.ts';
import { PERSONA_CONFIG_GROUP } from '../bots/corti-soulmate/persona/config.ts';
import { readGroupValues, setByPath, type ConfigGroup } from '../src/core/config-schema.ts';
import { WorkspaceGit, AUTHOR_SELF, AUTHOR_OPERATOR } from '../bots/cormini/persona/workspaceGit.ts';
import { aggregateUsage } from '../src/core/cost.ts';
import { createUsageRates } from '../src/core/usage-rates.ts';
import { priceUsage, unknownMeters } from '../src/core/generation.ts';
import { snapshotPrice } from '../src/providers/pricebook.ts';
import { nullLogger, readTextFile } from '../src/core/util.ts';
import type {
  World, WorldWebUiDecl, ToolSchema, ToolTag, UsageRecord,
} from '../src/core/types.ts';
import type { BotConfig } from '../bots/corti-soulmate/assemble.ts';
import type { SessionStats } from '../src/core/sessions.ts';

/** CORTICO_DEV_MINIMAL=1 仅挂载控制台 World。 */
const MINIMAL = process.env.CORTICO_DEV_MINIMAL === '1';


const tmpDeploy = mkdtempSync(join(tmpdir(), 'devdeploy-'));
writeFileSync(join(tmpDeploy, 'config.json'), '{}\n', 'utf8');
const loaded = loadConfig(tmpDeploy);
const cfg = loaded.config;
const TZ = cfg.timezone;
const tmpData = mkdtempSync(join(tmpdir(), 'devweb-'));

const tmpPersona = mkdtempSync(join(tmpdir(), 'devpersona-'));
mkdirSync(join(tmpPersona, 'note'), { recursive: true });
mkdirSync(join(tmpPersona, 'people'), { recursive: true });
writeFileSync(join(tmpPersona, 'CONSTITUTION.md'), '# 宪法（示例）\n\n与世界相处的根本原则。\n第一版。\n', 'utf8');
writeFileSync(join(tmpPersona, 'WORLDVIEW.md'), '# 世界观（示例）\n\n由梦维护的长期世界模型。\n', 'utf8');
writeFileSync(join(tmpPersona, 'note', '第一篇笔记.md'), '一段示例笔记。\n', 'utf8');
writeFileSync(join(tmpPersona, 'people', '阿明.md'), '# 阿明\n\n群里常出现的人。\n', 'utf8');
const pg = new WorkspaceGit(tmpPersona);
pg.init();
writeFileSync(join(tmpPersona, 'CONSTITUTION.md'), '# 宪法（示例）\n\n与世界相处的根本原则。\n第二版：补了一条关于诚实的原则。\n', 'utf8');
pg.commitAll('本轮记忆改动', AUTHOR_SELF);
writeFileSync(join(tmpPersona, 'note', '第一篇笔记.md'), '一段示例笔记。\nWebUI 补了一行示例。\n', 'utf8');
pg.commitAll('WebUI 编辑 note/第一篇笔记.md', AUTHOR_OPERATOR);
pg.tag('里程碑-A', '第一个稳定存档点');

// 使用各模块声明的 ConfigGroup,仅修改临时部署的配置。
const devCfg = JSON.parse(JSON.stringify(cfg)) as BotConfig;

(devCfg.worlds as Record<string, unknown>).minecraft = JSON.parse(JSON.stringify(MINECRAFT_DEFAULTS));
(devCfg.worlds as Record<string, unknown>).bilibili = JSON.parse(JSON.stringify(BILIBILI_DEFAULTS));
const devConfigGroups: ConfigGroup[] = MINIMAL
  ? [CORE_CONFIG_GROUP]
  : [
      CORE_CONFIG_GROUP, PERSONA_CONFIG_GROUP, qqConfigGroup('zh'), webSearchConfigGroup('zh'),
      minecraftConfigGroup('zh'), minecraftRhythmConfigGroup('zh'), minecraftClientConfigGroup('zh'),
      minecraftPlayerConfigGroup('zh'),
      bilibiliConfigGroup('zh'),
    ];
function genUsage(): UsageRecord[] {
  const recs: UsageRecord[] = [];
  const roles: Array<[string, string, string]> = [
    ['main', '主意识', 'deepseek-v4-flash'], ['dream', '梦', 'deepseek-v4-pro'],
  ];
  let seed = 7;
  const rnd = () => { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return seed / 0x7fffffff; };
  const p2 = (n: number) => String(n).padStart(2, '0');

  const pickRole = () => roles[rnd() < 0.85 ? 0 : 1];
  const push = (day: string, hh: number, mm: number) => {
    const [role, label, model] = pickRole();
    const prompt = 8000 + Math.floor(rnd() * 6000);
    const hit = Math.floor(prompt * (0.85 + rnd() * 0.1));
    const comp = 200 + Math.floor(rnd() * 800);
    recs.push({
      ts: `${day}T${p2(hh)}:${p2(mm)}:00+08:00`,
      sessionId: role === 'main' ? 'main' : `${role}-${recs.length}`, role, label, model,
      promptTokens: prompt, completionTokens: comp, cacheHitTokens: hit, cacheMissTokens: prompt - hit,
      reasoningTokens: Math.floor(comp * 0.4),
      charges: priceUsage({ ...unknownMeters(), input: prompt, output: comp, cachedInput: hit, uncachedInput: prompt - hit }, [snapshotPrice({
        models: [model], currency: 'USD', basis: 'marginal', source: 'dev fake price',
        rules: [{ meter: 'cachedInput', perMillion: 0.02 }, { meter: 'uncachedInput', perMillion: 0.27 }, { meter: 'output', perMillion: 1.1 }],
      }, { startedAt: `${day}T${p2(hh)}:${p2(mm)}:00+08:00`, requestedServiceTier: null })]),
    });
  };
// 日期按今天的 +08:00 日历日生成,覆盖分钟、周、月等聚合粒度。

  const today = new Date(Date.now() + 8 * 3_600_000).toISOString().slice(0, 10);
  const END = new Date(`${today}T00:00:00Z`).getTime();
  for (let back = 40; back >= 0; back--) {
    const day = new Date(END - back * 86400000).toISOString().slice(0, 10);
    for (let hr = 8; hr < 24; hr++) {
      const n = Math.floor(rnd() * 4);
      for (let k = 0; k < n; k++) push(day, hr, Math.floor(rnd() * 60));
    }
  }

  for (let mm = 2; mm < 52; mm += 3) { const c = 1 + Math.floor(rnd() * 2); for (let k = 0; k < c; k++) push(today, 14, mm); }
  return recs;
}
const usageRecords = genUsage();
/** 汇率走真实的公开接口，断网时页面显示内置汇率。 */
const devRates = createUsageRates();

const qq = new QQWorld({ wsUrl: 'ws://127.0.0.1:0', groups: [424242, 998877], privates: [10086], token: '', timezone: TZ });
const consoleWorld = new ConsoleWorld({ timezone: TZ });
/** 页面上存的密钥只留在内存里，不写临时部署的 .env。 */
const devSecrets: Record<string, string> = {};
const websearch = new WebSearchWorld({
  cfg: (devCfg.worlds.websearch ??= { ...WEBSEARCH_DEFAULTS }),
  secret: (name) => devSecrets[name] ?? loaded.secret(name),
  storeSecret: (name, value) => { devSecrets[name] = value; },
});
/** 使用独立 World 声明验证 WebUI 自动发现。 */
const webUiFixture = new WebUiFixtureWorld();
const worlds = MINIMAL ? [consoleWorld] : [qq, consoleWorld, websearch, webUiFixture];
const persona = new CortiSoulmate({ memoryDir: loaded.memoryDir, cfg, worlds });

const prefix = await assembleSystem({
  persona,
  worlds,
  now: new Date('2026-07-19T15:20:00+08:00'),
  timezone: TZ,
});

const store = new JsonlEventStore({ dataDir: tmpData, run: 'r-dev', log: nullLogger() });
// 控制台消息与附件写入临时事件库,供回放和取图接口读取。

const devBlobs = new LogBlobStore(tmpData);
await consoleWorld.start({
  pushEvent: async (e) => {
    const blobs: BlobRef[] | undefined = e.blobs?.map((b) => 'bytes' in b
      ? { handle: devBlobs.put(b.bytes, b.mime), mime: b.mime, ...(b.name ? { name: b.name } : {}), fallbackText: b.fallbackText }
      : { handle: b.handle, mime: 'application/octet-stream', fallbackText: b.fallbackText });
    const { blobs: _inputs, ...rest } = e;
    return store.append({ ...rest, text: withBlobLines(e.text, blobs), ...(blobs?.length ? { blobs } : {}), origin: e.origin ?? 'external' });
  },
  pushDeferred: () => {},
  store,
  drainPendingEvents: async () => [],
  modelFacts: { model: () => 'dev-model', accepts: (mime) => mime.startsWith('image/'), contextWindow: () => undefined },
  blob: (handle) => devBlobs.read(handle),
  reportUsage: () => {},
  log: nullLogger(),
});
const seed = (type: string, source: string, text: string, meta?: Record<string, unknown>) =>
  store.append({ type, ts: '2026-07-19T15:1' + (store.latestCursor() % 10) + ':00+08:00', source, origin: 'external', text, ...(meta ? { meta } : {}) });
const G1 = { kind: 'group', id: 424242 }; // 深夜茶话会
const G2 = { kind: 'group', id: 998877 }; // 学习小组
const P1 = { kind: 'private', id: 10086 }; // 老王
seed('qq.message', 'qq', '[群「深夜茶话会」 15:10] 阿明(20001): 在吗', { conv: G1, sender_name: '阿明', user_id: 20001, message_id: 101 });
seed('qq.message', 'qq', '[群「深夜茶话会」 15:11] 小李(20002): 可能在忙', { conv: G1, sender_name: '小李', user_id: 20002, message_id: 102 });
seed('qq.self', 'qq', '[群「深夜茶话会」 15:12] 你: 在的，刚看到', { conv: G1, sender_name: 'bot' });
seed('qq.message', 'qq', '[群「深夜茶话会」 15:13] 阿明(20001): 那就好，帮我记个事', { conv: G1, sender_name: '阿明', user_id: 20001, message_id: 103 });
seed('console.message', 'console', '[15:15] 访客: 你好呀，测试一下');
seed('console.self', 'console', '[15:16] 你: 你好，我在');
seed('qq.message', 'qq', '[群「学习小组」 15:18] 王工(30001): 周五的资料谁整理下', { conv: G2, sender_name: '王工', user_id: 30001, message_id: 201 });
seed('qq.message', 'qq', '[私聊 15:19] 老王(10086): 在么，问你个事', { conv: P1, sender_name: '老王', user_id: 10086, message_id: 301 });

const fixtureSession: FixtureMessage[] = [
  { role: 'system', content: prefix },
  { role: 'user', content: '[system] 2 new events arrived.' },
  {
    role: 'assistant',
    reasoning_content: '',
    content: '',
    tool_calls: [{ id: 'c1', type: 'function', function: { name: 'external_event_frame', arguments: '{}' } }],
  } as FixtureMessage,
  { role: 'tool', tool_call_id: 'c1', content: '[2 new events]\n#3 [15:10] 阿明(20001): 在吗\n#4 [15:11] 小李(20002): 可能在忙' } as FixtureMessage,
  {
    role: 'assistant',
    reasoning_content: '就是阿明在叫我，回应一下，然后等他把事情说完。',
    content: '阿明找我，先应一声。',
    tool_calls: [
      { id: 'c2', type: 'function', function: { name: 'send_console', arguments: '{"text":"在的，刚看到，怎么啦"}' } },
    ],
  } as FixtureMessage,
  { role: 'tool', tool_call_id: 'c2', content: '[sent #5]' } as FixtureMessage,
  { role: 'assistant', content: '', reasoning_content: '' } as FixtureMessage,
];
// 带图的控制台消息与工具回执:时间线经 /api/blob 取图
const devImage = (width: number, height: number, from: [number, number, number], to: [number, number, number]): Buffer => {
  const raw = Buffer.alloc((width * 3 + 1) * height);
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const t = (x + y) / (width + height);
      for (let c = 0; c < 3; c++) raw[y * (width * 3 + 1) + 1 + x * 3 + c] = Math.round(from[c] + (to[c] - from[c]) * t);
    }
  }
  return encodePng(width, height, 2, raw);
};
const devImageRef = (bytes: Buffer, name: string, fallbackText: string): BlobRef =>
  ({ handle: devBlobs.put(bytes, 'image/png'), mime: 'image/png', name, fallbackText });
const userImage = devImageRef(devImage(320, 240, [240, 180, 120], [120, 160, 240]), 'sunset.png', 'image 1/1 from 阿明');
const shotImage = devImageRef(devImage(480, 270, [40, 60, 90], [200, 220, 240]), 'screen.png', '屏幕截图 480×270');
const session = [
  ...fixtureRecords(fixtureSession, 'dev-webui'),
  message('user', withBlobLines('[15:12] 阿明: 看我拍的', [userImage]), { blobs: [userImage] }),
  functionCall('c-shot', 'look_screen', '{}', { responseId: 'resp-dev-shot' }),
  functionResult('c-shot', withBlobLines('截到了', [shotImage]), { blobs: [shotImage] }),
  ...responseTimelineFixture().session.slice(1),
];


const worldLabels: Record<string, string> = {
  qq: 'QQ', console: '控制台对话', websearch: 'WebSearch',
  minecraft: 'Minecraft', bilibili: 'B 站直播间',
};

const devTemplateDir = mkdtempSync(join(tmpdir(), 'cortico-dev-tpl-'));

/** 读取 World 的环境模板作为预览数据。 */
function promptDocPathOf(mod: World): string {
  const doc = mod.webUi?.()?.promptDocs?.find((d) => d.role === 'envPrompt');
  if (!doc) throw new Error(`${mod.id} 没有环境提示词模板`);
  return doc.path;
}
const toolOwner = new Map<string, ToolOwner>();
for (const m of worlds) {
  for (const t of m.tools()) toolOwner.set(t.name, { kind: 'world', id: m.id, label: worldLabels[m.id] ?? m.id });
}
const toolSchemas: Array<ToolSchema & { owner: ToolOwner; tags: readonly ToolTag[] }> = [
  ...persona.declareSessions()[0].tools(),
].map((t) => ({
  name: t.name,
  description: t.description,
  parameters: t.parameters,
  tags: t.tags,
  owner: toolOwner.get(t.name) ?? (t.tags.includes('flow') ? { kind: 'core' } : { kind: 'persona' }),
}));

const sessionsList: SessionStats[] = [
  { id: 'main', role: 'main', label: '主意识', startedAt: '2026-07-19T09:00:00+08:00', endedAt: null, calls: 42, promptTokens: 358000, completionTokens: 12400, cacheHitTokens: 322000, cacheMissTokens: 36000, reasoningTokens: 5200, cacheHitRate: 322000 / 358000, messageCount: 96 } as SessionStats,
  { id: 'dream-1', role: 'dream', label: '梦', startedAt: '2026-07-19T04:00:00+08:00', endedAt: '2026-07-19T04:06:00+08:00', calls: 8, promptTokens: 61000, completionTokens: 3400, cacheHitTokens: 40000, cacheMissTokens: 21000, reasoningTokens: 1200, cacheHitRate: 40000 / 61000, messageCount: 18 } as SessionStats,
];

const storage: OwnedStoragePart[] = [
  { key: 'events', owner: 'core', label: '事件库(本次运行)', kind: 'disk', location: 'data/runs/r-dev/events.jsonl', danger: true, note: '清除本次运行的事件记录,保留此前记录;游标不回退', stat: () => `${store.latestCursor()}条 / 12.4KB`, clear: () => '(dev)不清除' },
  { key: 'session', owner: 'core', label: '主session(当前对话上下文)', kind: 'disk', location: 'data/session-main.jsonl', danger: true, order: 10, note: '清除对话上下文并重新开场,保留 Memory 和事件库', stat: () => `${session.length}条 / ~90k tok`, clear: () => '(dev)不清除' },
  { key: 'runlog', owner: 'core', label: '运行日志', kind: 'disk', location: 'data/runs/r-dev/log.jsonl', note: '运行日志不进入模型上下文', stat: () => '8.1KB', clear: () => '(dev)不清除' },
  { key: 'state', owner: 'core', label: 'Core 状态', kind: 'disk', location: 'data/core-state.json', note: '清除 Persona 状态、交接时间和模型连续失败记录,保留投递游标与 World 可见性', stat: () => 'Persona 状态1项 / 上次交接刚刚', clear: () => '(dev)不清除' },
  { key: 'wakes', owner: 'core', label: '定时唤醒', kind: 'disk', location: 'data/timers.json', note: '取消全部定时器,不产生通知', stat: () => '1个待触发', clear: () => '(dev)不清除' },
  { key: 'tracker', owner: 'core', label: 'session统计(usage/缓存)', kind: 'memory', note: '清零统计,保留正在运行的 session 条目', stat: () => `${sessionsList.length}个session`, clear: () => '(dev)不清除' },
  { key: 'pending', owner: 'core', label: '待投递事件', kind: 'memory', order: 9, note: '丢弃待投递的事件,保留事件库记录。延迟生成正文的队列项保留;已丢弃项不会在重启后补投', stat: () => '7条待投递', clear: () => '(dev)不清除' },

  { key: 'minecraft-log', label: 'World 日志(本次运行)', kind: 'disk', owner: 'world:minecraft', location: 'data/runs/r-dev/log.jsonl', note: '清除本次运行的 World 日志,保留此前运行的日志', stat: () => '1594条 / 612.0KB', clear: () => '(dev)不清除' },
];

let watched = {
  groups: [{ id: 424242, enabled: true }, { id: 998877, enabled: true }, { id: 112233, enabled: false }],
  privates: [{ id: 10086, enabled: true }],
};
let paused = false;
let devDreaming = false;
/** CORTICO_DEV_ONBOARDING=1 起一个带开场引导的 WebUI(真机上这个标记由自建部署写下)。 */
let onboardingPending = process.env.CORTICO_DEV_ONBOARDING === '1';

const devLogT0 = Date.now() - 10_000;

/** 扫描线须包含 PNG filter 字节;colorType 为 2(RGB)或 6(RGBA)。 */
function encodePng(width: number, height: number, colorType: number, raw: Buffer): Buffer {
  const crcTable: number[] = [];
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    crcTable[n] = c >>> 0;
  }
  const crc = (b: Buffer): number => {
    let c = 0xffffffff;
    for (const x of b) c = crcTable[(c ^ x) & 0xff] ^ (c >>> 8);
    return (c ^ 0xffffffff) >>> 0;
  };
  const chunk = (type: string, data: Buffer): Buffer => {
    const len = Buffer.alloc(4);
    len.writeUInt32BE(data.length, 0);
    const body = Buffer.concat([Buffer.from(type, 'latin1'), data]);
    const tail = Buffer.alloc(4);
    tail.writeUInt32BE(crc(body), 0);
    return Buffer.concat([len, body, tail]);
  };
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0); ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8; ihdr[9] = colorType;
  return Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
    chunk('IHDR', ihdr),
    chunk('IDAT', deflateSync(raw)),
    chunk('IEND', Buffer.alloc(0)),
  ]);
}

/** 64×64 皮肤夹具;头部正面位于 (8,8) 至 (15,15)。 */
function devSkinPng(shirt: [number, number, number], hair: [number, number, number]): Buffer {
  const N = 64;
  const stride = N * 4 + 1;
  const raw = Buffer.alloc(stride * N);
  const put = (x: number, y: number, rgb: [number, number, number], a = 255): void => {
    const i = y * stride + 1 + x * 4;
    raw[i] = rgb[0]; raw[i + 1] = rgb[1]; raw[i + 2] = rgb[2]; raw[i + 3] = a;
  };
  const skin: [number, number, number] = [235, 195, 165];
  for (let y = 0; y < N; y++) {
    raw[y * stride] = 0; // filter: none
    for (let x = 0; x < N; x++) put(x, y, shirt);
  }
  // 帽子层保持透明,以显示底层头部。
  for (let y = 0; y < 16; y++) for (let x = 32; x < 64; x++) put(x, y, shirt, 0);
  for (let y = 8; y < 16; y++) for (let x = 8; x < 16; x++) put(x, y, skin);
  for (let x = 8; x < 16; x++) { put(x, 8, hair); put(x, 9, hair); }
  put(10, 12, [40, 40, 60]); put(13, 12, [40, 40, 60]);
  put(11, 14, [170, 90, 90]); put(12, 14, [170, 90, 90]);
  return encodePng(N, N, 6, raw);
}


const devWorldVisible: Record<string, boolean> = {};
const devWorldDrift = new Set<string>();
const devPromptDocs = [
  { key: 'orientation', title: 'ORIENTATION', scope: 'persona' as const, description: 'Persona的存在方式与元认知说明。', content: persona.orientationText(), revision: 'dev-orientation-1' },
  { key: 'constitution', title: '宪法', scope: 'persona' as const, description: 'Persona的长期原则。', content: persona.constitutionText(), revision: 'dev-constitution-1' },
// 首轮对话字段按 firstTurn. 前缀识别。
  {
    key: 'firstTurn.user', title: '首轮·用户输入', scope: 'persona' as const,
    description: '合成首轮对话的 user 消息。与回复任一为空则整轮不注入。',
    content: '晚上好呀,今天过得怎么样?', revision: 'dev-ft-user-1',
  },
  {
    key: 'firstTurn.thinking', title: '首轮·思维链', scope: 'persona' as const,
    description: '合成首轮 assistant 的推理内容;为空时省略。',
    content: '普通的问候。放松地回,别端着。', revision: 'dev-ft-thinking-1',
  },
  {
    key: 'firstTurn.reply', title: '首轮·回复', scope: 'persona' as const,
    description: '合成首轮对话的 assistant 回复正文。',
    content: '晚上好——刚整理完今天的记事,你来得正好。', revision: 'dev-ft-reply-1',
  },
  {
    key: 'worlds.qq.envPrompt', title: 'QQ · 环境提示词', scope: 'world' as const,
    description: 'QQ 渠道的常驻事实。', revision: 'dev-qq-1', role: 'envPrompt' as const,
    content: '你在QQ上。\n\n下面是你正在参与的会话:\n{{qq.conversations | (还没有配置任何监听的群或私聊。)}}\n{{qq.identity | (与QQ的连接尚未建立,群名和你的账号信息暂时未知。)}}\n',
    vars: [
      { name: 'qq.conversations', description: '当前监听的群与私聊清单,每行一条。', multiline: true, value: '- 群「深夜食堂」(群号424242);你在这个群的昵称是「Yukima」' },
      { name: 'qq.identity', description: '你自己的 QQ 号;未连接时为空。', value: '你的QQ号是5000。' },
    ],
  },
  {
    key: 'persona.memory', title: '记忆', scope: 'persona' as const, revision: 'dev-memory-1',
    description: 'Memory 各层的标题、内容与空态文本。',
    content: '【MEMORY 0·地图】\nMemory 目录清单。\n{{memory.tree}}\n\n【MEMORY 4·当下】\n现在是 {{memory.now}}(时区 {{memory.timezone}})。\n',
    vars: [
      { name: 'memory.tree', description: 'persona/ 最外层目录清单。', multiline: true, value: 'persona/\n- note/\n- memo/' },
      { name: 'memory.now', description: '前缀构建时的时间,下次重建时更新。', value: '2026-08-16 17:45' },
      { name: 'memory.timezone', description: '时区名。', value: 'Asia/Shanghai' },
    ],
  },
  {
    key: 'persona.prefix', title: '前缀装配', scope: 'persona' as const, role: 'prefix' as const,
    description: '整份 system 前缀由哪几段、按什么顺序、用什么分隔线拼成。',
    revision: 'dev-prefix-1',
    content: '\n━━━ ORIENTATION ━━━\n{{persona.orientation}}\n\n━━━ 宪法 ━━━\n{{persona.constitution}}\n{{worlds.envPrompts}}\n\n━━━ Using your tools ━━━\n{{persona.toolUsage}}\n\n━━━ 记忆 ━━━\n{{memory.all}}\n',
    vars: [
      { name: 'persona.orientation', description: 'ORIENTATION.md 全文。', multiline: true },
      { name: 'persona.constitution', description: 'CONSTITUTION.md 全文。', multiline: true },
      { name: 'worlds.envPrompts', description: '各 World 的环境提示词,按 World id 序。', multiline: true },
      { name: 'persona.toolUsage', description: '代码生成的工具说明。', multiline: true },
      { name: 'memory.all', description: 'MEMORY 0~4 整块。', multiline: true },
    ],
  },
  { key: 'worlds.console.envPrompt', title: '控制台 · 环境提示词', scope: 'world' as const, description: '控制台对话环境的常驻事实。', content: readTextFile(promptDocPathOf(consoleWorld)), revision: 'dev-web-1' },
  { key: 'worlds.websearch.envPrompt', title: 'WebSearch · 环境提示词', scope: 'world' as const, description: '搜索工具 World 的可选常驻环境。', content: readTextFile(promptDocPathOf(websearch)), revision: 'dev-search-1' },
];

const port = Number(process.env.CORTICO_PORT || 8848);
/** 模拟 starting 到 running 的异步状态变化。 */
function devMount(
  fixed: () => Record<string, unknown>,
  derived: (phase: string) => Record<string, unknown>,
): { state(): Promise<unknown>; start(): Promise<unknown>; stop(): Promise<unknown> } {
  let phase = 'stopped';
  let readyAt = 0;
  const snap = () => {
    if (phase === 'starting' && Date.now() > readyAt) phase = 'running';
    return { phase, detail: phase === 'starting' ? '启动中(dev 假数据,几秒后就绪)' : null, pid: phase === 'stopped' ? null : 4242, ...fixed(), ...derived(phase) };
  };
  return {
    state: async () => snap(),
    start: async () => { phase = 'starting'; readyAt = Date.now() + 6_000; return snap(); },
    stop: async () => { phase = 'stopped'; return snap(); },
  };
}

/**
 * Minecraft「服务器」一行:按 devCfg 的 serverMode 分本地托管与外部服务器。外部服务器
 * 连接 3 秒后进入世界;端口为 25571 时模拟端口可达但被白名单拒绝。
 */
function devMinecraftServer(): { state(): Promise<unknown>; start(): Promise<unknown>; stop(): Promise<unknown>; reconnect(): Promise<unknown> } {
  const local = devMount(
    () => ({ address: '127.0.0.1:25565', serverDir: 'C:\\mc\\server', configured: true }),
    (phase) => ({ reachable: phase === 'running' }),
  );
  const mc = () => (devCfg.worlds as unknown as Record<string, MinecraftConfigSection>).minecraft;
  const targetOf = () => ({ host: mc().host, port: mc().port, username: mc().username, version: mc().version });
  let wanted = true;
  let applied = targetOf();
  let since = Date.now();
  const external = () => mc().serverMode === 'external';
  const link = (phase: string) => {
    if (!external()) {
      return { phase: phase === 'running' ? 'online' : 'stopped', target: '127.0.0.1:25565', username: applied.username, version: applied.version, attempt: 0, failure: null };
    }
    const blocked = applied.port === 25571;
    const settled = Date.now() - since > 3_000;
    return {
      phase: !wanted ? 'stopped' : !settled ? 'connecting' : blocked ? 'retrying' : 'online',
      target: `${applied.host}:${applied.port}`,
      username: applied.username,
      version: applied.version,
      attempt: wanted && settled && blocked ? 1 : 0,
      failure: wanted && settled && blocked ? '被服务器断开(白名单):multiplayer.disconnect.not_whitelisted' : null,
    };
  };
  const snap = async () => {
    const base = await local.state() as { phase: string } & Record<string, unknown>;
    const now = targetOf();
    const differs = now.host !== applied.host || now.port !== applied.port
      || now.username !== applied.username || now.version !== applied.version;
    if (!external()) return { ...base, mode: 'local', modeInferred: false, wanted: base.phase !== 'stopped', link: link(base.phase), pending: null };
    return {
      ...base, phase: 'stopped', pid: null, detail: null, reachable: true, configured: false,
      address: `${applied.host}:${applied.port}`, mode: 'external', modeInferred: false, wanted,
      link: link(base.phase),
      pending: wanted && differs ? `${now.host}:${now.port}(${now.username},${now.version})` : null,
    };
  };
  const connect = () => { wanted = true; applied = targetOf(); since = Date.now(); };
  return {
    state: snap,
    start: async () => { if (external()) { if (!wanted) connect(); } else await local.start(); return snap(); },
    stop: async () => { if (external()) wanted = false; else await local.stop(); return snap(); },
    reconnect: async () => { connect(); return snap(); },
  };
}


const devQqNames = (): unknown => ({
  groups: [
    { id: 424242, name: '深夜茶话会', card: 'bot' },
    { id: 998877, name: '学习小组', card: '午午' },
  ],
  privates: [{ id: 10086, name: '老王' }],
});

/** dev:B站 Overlay 使用真实回环渲染器，数据与操作仍全部是假数据。 */
let devBilibiliDesign: BilibiliOverlayDesign = structuredClone(BILIBILI_DEFAULTS.overlay.design);
let devBilibiliDesignRevision = 0;
let devBilibiliMutation: Promise<void> = Promise.resolve();
function runDevBilibiliMutation<T>(operation: () => Promise<T> | T): Promise<T> {
  const result = devBilibiliMutation.then(operation);
  devBilibiliMutation = result.then(() => undefined, () => undefined);
  return result;
}
devBilibiliDesign.groups.push({
  id: 'dev-guard',
  name: '舰队观众',
  enabled: true,
  priority: 10,
  rule: { op: 'leaf', field: 'guardLevel', compare: 'gte', value: 1 },
  username: { color: '#7dd3fcff', fontWeight: 800 },
  body: { color: '#f8fafcff' },
});
devBilibiliDesign.components.push(
  {
    id: 'dev-flying-danmaku',
    name: '横向弹幕机',
    kind: 'danmaku',
    styleId: 'builtin:minimal',
    axis: 'horizontal',
    admission: 'danmaku',
    showAvatar: false,
    speed: 150,
    gap: 12,
    maxItems: 8,
    usernameMaxChars: 24,
    bodyMaxChars: 80,
    edgeFadePx: 32,
  },
  {
    id: 'dev-scroll-notice',
    name: '横向公告',
    kind: 'scroll-notice',
    styleId: 'builtin:sky',
    axis: 'horizontal',
    text: '欢迎来到演示直播间\nOverlay 数据全部来自安全夹具\n多行公告会依次停留并切换',
    speed: 90,
    gap: 100,
    lineHoldMs: 1600,
    lineTransitionMs: 420,
    edgeFadePx: 32,
  },
  {
    id: 'dev-fixed-notice',
    name: '固定公告',
    kind: 'fixed-notice',
    styleId: 'builtin:white',
    text: '今日目标：完成 Overlay 联调',
  },
  {
    id: 'dev-video-queue',
    name: '视频排队',
    kind: 'video-queue',
    styleId: 'builtin:translucent',
    axis: 'vertical',
    gap: 8,
    showIndex: true,
    emptyText: '暂无排队视频',
    hideWhenEmpty: false,
  },
);
devBilibiliDesign.placements.push(
  {
    id: 'placement-dev-flying-danmaku', componentId: 'dev-flying-danmaku',
    x: 120, y: 420, width: 1000, height: 260, z: 12, visible: true, locked: false,
  },
  {
    id: 'placement-dev-scroll-notice', componentId: 'dev-scroll-notice',
    x: 120, y: 900, width: 1680, height: 100, z: 30, visible: true, locked: false,
  },
  {
    id: 'placement-dev-fixed-notice', componentId: 'dev-fixed-notice',
    x: 120, y: 220, width: 760, height: 120, z: 18, visible: true, locked: false,
  },
  {
    id: 'placement-dev-video-queue', componentId: 'dev-video-queue',
    x: 120, y: 690, width: 700, height: 190, z: 16, visible: true, locked: false,
  },
);
let devBilibiliAnnouncement: AgentAnnouncementState = {
  schemaVersion: 1,
  text: '正在测试新版直播 Overlay',
  revision: 1,
  updatedAt: new Date().toISOString(),
};
const devBilibiliVideoQueue: VideoQueueState = {
  schemaVersion: 1,
  items: [
    { bvid: 'BV1Ab4y1C7dE', note: '新番预告 · 观众点播', addedAt: new Date().toISOString() },
    { bvid: 'BV1Qx411m7Ks', note: '', addedAt: new Date().toISOString() },
  ],
  revision: 1,
  updatedAt: new Date().toISOString(),
};
const devBilibiliAssets = new OverlayAssetStore(join(tmpData, 'bilibili-overlay-assets'));
const devBilibiliOverlay: BilibiliOverlayServer = new BilibiliOverlayServer({
  preferredPort: 0,
  assets: devBilibiliAssets,
  snapshot: () => ({
    design: structuredClone(devBilibiliDesign),
    designRevision: devBilibiliDesignRevision,
    builtinStyles: structuredClone(BUILTIN_OVERLAY_STYLES),
    agentAnnouncement: { ...devBilibiliAnnouncement },
    videoQueue: structuredClone(devBilibiliVideoQueue),
  }),
  editor: {
    state: () => devBilibiliState(),
    saveDesign: (value, baseRevision) => runDevBilibiliMutation(
      () => devBilibiliOverlayPanel.saveDesign(value, baseRevision),
    ),
    importAsset: (value) => runDevBilibiliMutation(
      () => devBilibiliOverlayPanel.importAsset(String(value ?? '')),
    ),
    deleteAsset: (value) => runDevBilibiliMutation(
      () => devBilibiliOverlayPanel.deleteAsset(String(value ?? '')),
    ),
    setAgentAnnouncement: (value, expectedRevision) => runDevBilibiliMutation(
      () => devBilibiliOverlayPanel.setAgentAnnouncement(String(value ?? ''), expectedRevision),
    ),
  },
});
if (!MINIMAL) await devBilibiliOverlay.start(nullLogger());
const DEV_BILIBILI_OVERLAY_URL = MINIMAL ? null : devBilibiliOverlay.overlayUrl;

function devBilibiliState(): Record<string, unknown> {
  return {
    design: structuredClone(devBilibiliDesign),
    designRevision: devBilibiliDesignRevision,
    builtinStyles: structuredClone(BUILTIN_OVERLAY_STYLES),
    agentAnnouncement: { ...devBilibiliAnnouncement },
    videoQueue: structuredClone(devBilibiliVideoQueue),
    maxAnnouncementChars: BILIBILI_DEFAULTS.overlay.agentNoticeMaxChars,
    maxQueuedVideos: BILIBILI_DEFAULTS.overlay.maxQueuedVideos,
    assets: devBilibiliAssets.list(DEV_BILIBILI_OVERLAY_URL ? devBilibiliOverlay.baseUrl : null),
    url: DEV_BILIBILI_OVERLAY_URL,
    streamUp: !MINIMAL,
    error: null,
  };
}

const devBilibiliOverlayPanel = {
  state: () => devBilibiliState(),
  saveDesign: (value: unknown, baseRevision: unknown) => {
    if (!Number.isInteger(baseRevision) || Number(baseRevision) !== devBilibiliDesignRevision) {
      throw new OverlayEditorConflictError('Overlay 设计已被其他编辑会话更新');
    }
    devBilibiliDesign = normalizeOverlayDesign(value);
    devBilibiliDesignRevision += 1;
    devBilibiliOverlay.emitState();
    return { ...devBilibiliState(), message: 'Overlay 设计已保存并热更新 (dev,不真落盘)' };
  },
  importAsset: (base64: string): Record<string, unknown> => ({
    asset: devBilibiliAssets.import(base64),
    assets: devBilibiliAssets.list(devBilibiliOverlay.baseUrl),
  }),
  deleteAsset: (id: string) => ({
    deleted: devBilibiliAssets.delete(id),
    assets: devBilibiliAssets.list(devBilibiliOverlay.baseUrl),
  }),
  setAgentAnnouncement: (text: string, expectedRevision: unknown) => {
    if (!Number.isInteger(expectedRevision) || Number(expectedRevision) !== devBilibiliAnnouncement.revision) {
      throw new OverlayEditorConflictError('Agent 公告已被其他写入者更新');
    }
    const normalized = text.replace(/\r\n?/g, '\n');
    const chars = Array.from(normalized);
    const limit = BILIBILI_DEFAULTS.overlay.agentNoticeMaxChars;
    if (chars.length > limit) throw new Error(`公告最多 ${limit} 字，当前 ${chars.length} 字`);
    devBilibiliAnnouncement = {
      schemaVersion: 1,
      text: chars.join(''),
      revision: devBilibiliAnnouncement.revision + 1,
      updatedAt: new Date().toISOString(),
    };
    devBilibiliOverlay.emitAnnouncement(devBilibiliAnnouncement);
    return { ...devBilibiliAnnouncement };
  },
};

let devBilibiliLoginStartedAt: number | null = null;
function devBilibiliLoginState(): Record<string, unknown> {
  const base = { url: null, uid: null, error: null, configured: true, selfUid: 87654321 };
  if (devBilibiliLoginStartedAt === null) return { ...base, phase: 'idle' };
  if (Date.now() - devBilibiliLoginStartedAt < 4000) return { ...base, phase: 'waiting', url: 'about:blank#dev-bilibili-login' };
  return { ...base, phase: 'done', uid: 87654321 };
}

/** 按 World id、面板局部 id、方法名组织假数据,返回最终接口响应形状。 */
const devPanels: Record<string, Record<string, Record<string, (...args: never[]) => unknown>>> = {
  qq: {
    roster: {
      names: devQqNames,
      get: () => watched,
      set: (groups: Array<{ id: number; enabled: boolean }>, privates: Array<{ id: number; enabled: boolean }>) => {
        watched = { groups, privates };
        const gOn = groups.filter((e) => e.enabled).length;
        const pOn = privates.filter((e) => e.enabled).length;
        return {
          ok: true,
          result: `监听名单已更新:群${groups.length}个(启用${gOn})、私聊${privates.length}个(启用${pOn}) (dev)`,
          config: watched,
        };
      },
    },
    gate: {
      state: () => ({
        enabled: true,
        wsUrl: 'ws://127.0.0.1:3001',
        tokenSet: false,
        connected: true,
        selfId: 88886666,
        nickname: 'bot',
        groups: [
          { id: 424242, name: '深夜茶话会', card: 'bot' },
          { id: 998877, name: '学习小组', card: '午午' },
        ],
        privates: [{ id: 10086, name: '老王' }],
      }),
      setEnabled: (enabled: boolean) => ({ ok: true, restarting: true, enabled }), // dev:不真重启
      setConnection: () => ({ ok: true, restarting: true }), // dev:不真重启
    },
    events: {
      names: devQqNames,
      list: (opts?: { conv?: string; limit?: number }) => devQqEvents(opts),
    },
  } as never,
  bilibili: {
    login: {
      // dev:开始后 4 秒视为已在浏览器确认，不连 B 站。
      state: () => devBilibiliLoginState(),
      start: () => {
        devBilibiliLoginStartedAt = Date.now();
        return devBilibiliLoginState();
      },
      cancel: () => {
        devBilibiliLoginStartedAt = null;
        return devBilibiliLoginState();
      },
    },
    log: {
      state: () => ({
        status: {
          phase: 'connected', roomId: 42, realRoomId: 12345678,
          title: '演示直播间', living: true, selfUid: 87654321, lastError: null,
        },
        desensitized: false,
        aggregate: { enter: 7, like: 23, freeGift: 2, watched: 288429, online: 41, popularity: 1520, fans: 3187, likeTotal: 9042 },
        recent: [
          '[上舰|夜行的猫] 开通了舰长',
          '[SC|30元|阿明] 那个洞里有铁矿,往左挖',
          '[礼物|阿明] 送出 小花花 ×1',
          '[弹幕|夜行的猫] 别站在岩浆边上啊',
          '[弹幕|阿明] 在吗',
        ],
        total: 137,
        counts: [
          ['DANMU_MSG', 96], ['INTERACT_WORD_V2', 21], ['LIKE_INFO_V3_CLICK', 11],
          ['SEND_GIFT', 5], ['WATCHED_CHANGE', 3], ['SUPER_CHAT_MESSAGE', 1],
          ['GUARD_BUY', 1], ['SOME_NEW_CMD_2030', 1],
        ],
      }),
    },
  },
  minecraft: {
    log: {
      // 日志夹具覆盖类别过滤与任务号关联。
      entries: (after = 0) => {
        const rows: Array<[string, string, string, number | undefined]> = [
          ['tool', 'mc_do', 'mc_do → 已开始任务#1「采集 3 个橡木原木;合成 1 个木镐」', undefined],
          ['task', 'enqueue', '排进任务#2「去「工作台」」(前面还有 1 件)', 2],
          ['task', 'start', '开始任务#1「采集 3 个橡木原木;合成 1 个木镐」', 1],
          ['skill', 'begin', '第 1 步 采集 3 个橡木原木', 1],
          ['skill', 'done', '采集 3 个橡木原木: 挖了 3 块橡木原木,实际入包 3 个', 1],
          ['craft', 'plan', '合成 1 个木镐:3 步(附近没有工作台,要自己带一个)', 1],
          ['skill', 'place-vanished', '工作台放置没报错,回读 (5, 72, 24) 还是空气', 1],
          ['craft', 'table-fail', '工作台放置调用完成后,回读目标位置仍为空气', 1],
          ['landmark', 'resolve', '「工作台」→ 工作台 (-32, 64, 70),另有 2 条同名的没选', undefined],
          ['event', 'minecraft.task', '[执行器] 任务#1「去「工作台」」受阻于 走不过去: 路线算不出来', 1],
          ['reflex', 'drown-noland', '附近找不到能上去的岸,只能继续上浮换气', undefined],
        ];
        const entries = [];
        for (let seq = after + 1; seq <= rows.length; seq++) {
          const [lane, event, msg, taskId] = rows[seq - 1];
          entries.push({
            seq, lane, event, msg, taskId,
            ts: new Date(devLogT0 + seq * 2500).toISOString(),
            ...(lane === 'skill' && event === 'done' ? { durMs: 8420 } : {}),
          });
        }
        return { entries };
      },
    },
      // 面板方法的链路前缀与 MinecraftWorld.invokePanel 一致。

    server: devMinecraftServer(),
    client: devMount(
      () => ({
        enabled: true, gameDir: 'C:\\mc\\.minecraft', versionId: '1.20.1-fabric-iris',
        username: 'CortiCam', configured: true, command: 'java -Xmx4G ... net.minecraft.client.main.Main',
      }),
      (phase) => ({ windowReady: phase === 'running' }),
    ),
    player: (() => {
      const lane = devMount(
        () => ({
          enabled: false, gameDir: 'C:\\mc\\.minecraft', versionId: '1.20.1-fabric-iris',
          username: 'Player', configured: true, command: 'java -Xmx4G ... net.minecraft.client.main.Main',
        }),
        (phase) => ({ windowReady: phase === 'running' }),
      );
      return {
        ...lane,
        teleport: async () => ({
          ...(await lane.state() as Record<string, unknown>),
          detail: '已把 Player 传送到 CortiV 旁边(dev)',
        }),
      };
    })(),

    skin: (() => {
      const picked = new Map<string, { bytes: Buffer; at: string }>([
        ['bot', { bytes: devSkinPng([86, 116, 196], [64, 48, 72]), at: new Date(devLogT0).toISOString() }],
      ]);

      const sizeOf = (b: Buffer): { width: number; height: number } | null =>
        b.length >= 24 && b[0] === 0x89 && b[1] === 0x50
          ? { width: b.readUInt32BE(16), height: b.readUInt32BE(20) }
          : null;
      const gameDir = 'C:\mc\.minecraft';
      const account: Record<string, string> = { bot: 'CortiV', player: 'Phant' };
      const state = (detail: string | null = null) => ({
        roles: (['bot', 'player'] as const).map((role) => {
          const cur = picked.get(role);
          return {
            role,
            username: account[role],
            skin: cur ? { ...sizeOf(cur.bytes)!, bytes: cur.bytes.length, at: cur.at } : null,
            installed: { camera: Boolean(cur), player: Boolean(cur) },
          };
        }),
        dirs: { camera: gameDir, player: gameDir },
        mod: { camera: true, player: true },
        live: { camera: true, player: false },
        detail,
      });
      const asRole = (role: string): string => {
        if (role !== 'bot' && role !== 'player') throw new Error(`没有这个角色: ${role}`);
        return role;
      };
      return {
        state: async () => state(),
        set: async (role: string, base64: string) => {
          const bytes = Buffer.from(base64, 'base64');
          const size = sizeOf(bytes);
          if (!size) throw new Error('不是 PNG 图片');
          if (size.width !== 64 || (size.height !== 64 && size.height !== 32)) {
            throw new Error(`皮肤材质得是 64x64(或 1.8 之前的 64x32),这张是 ${size.width}x${size.height}`);
          }
          picked.set(asRole(role), { bytes, at: new Date().toISOString() });
          return state('皮肤已保存,摄像机重新连接后生效 (dev)');
        },
        clear: async (role: string) => {
          const had = picked.delete(asRole(role));
          return state(had ? '已移除自定义皮肤 (dev)' : '本来就没选');
        },
        file: async (role: string) => {
          const cur = picked.get(asRole(role));
          if (!cur) throw new Error('这个角色还没选皮肤');
          return { $binary: { mime: 'image/png', base64: cur.bytes.toString('base64') } };
        },
      };
    })(),
    world: (() => {
      const settings = {
        gamemode: 'survival', difficulty: 'easy', hardcore: false, pvp: true,
        spawnMonsters: true, levelSeed: '', levelName: 'world',
        levelType: 'minecraft:normal', generatorSettings: '', generateStructures: true,
        allowNether: true, spawnProtection: 16, viewDistance: 10,
        simulationDistance: 10, maxWorldSize: 29_999_984,
      };
      const day = 86_400_000;

      const known = new Map<string, { ago: number; size: number; gen: string; seed: string; ver: string }>([
        ['world', { ago: 0.2, size: 412_000_000, gen: 'normal', seed: '-8601234567890123', ver: '1.20.6' }],
        ['flat-test', { ago: 0.6, size: 7_300_000, gen: 'flat', seed: '0', ver: '1.20.6' }],
        ['old-savanna', { ago: 5, size: 1_240_000_000, gen: 'large_biomes', seed: '77123', ver: '1.20.4' }],
        ['creative-build', { ago: 12, size: 96_000_000, gen: 'flat', seed: '1', ver: '1.20.4' }],
        ['第一次试玩', { ago: 64, size: 220_000_000, gen: 'amplified', seed: '55', ver: '1.20.1' }],
      ]);
      let detail: string | null = null;
      const state = async () => ({
        configured: true, serverDir: 'C:\\mc\\server', live: false, hosted: false,
        worlds: [...known].map(([name, w]) => ({
          name,
          generated: true,
          modified: new Date(Date.now() - w.ago * day).toISOString(),
          sizeBytes: w.size,
          dimensions: w.gen === 'flat' ? [] : ['nether', 'the_end'],
          info: {
            levelName: name, lastPlayed: Date.now() - w.ago * day, seed: w.seed,
            gameType: name === 'creative-build' ? 1 : 0, difficulty: 2, hardcore: false,
            version: w.ver, generator: w.gen, dayTime: 24_000 * (30 - w.ago),
          },
        })).concat(known.has(settings.levelName) ? [] : [{
          name: settings.levelName, generated: false, modified: null as never,
          sizeBytes: 0, dimensions: [], info: null as never,
        }]),
        settings: { ...settings },
        flatPresets: flatPresets('zh'),
        levelTypes: levelTypeLabels('zh'),
        detail,
      });
      return {
        state,
        select: async (name: string) => { settings.levelName = name; detail = `下次启动进「${name}」(dev)`; return state(); },
        create: async (name: string, gen: Record<string, unknown>) => {
          settings.levelName = name;
          settings.levelSeed = String(gen.seed ?? '');
          settings.levelType = String(gen.levelType ?? 'minecraft:normal');
          settings.generatorSettings = String(gen.generatorSettings ?? '');
          settings.generateStructures = gen.generateStructures !== false;
          detail = `下次启动会生成新世界「${name}」(dev)`;
          return state();
        },
        apply: async (patch: Record<string, unknown>) => {
          Object.assign(settings, patch);
          detail = '已写入 server.properties(dev,不真落盘)';
          return state();
        },
      };
    })(),
    access: (() => {
      const settings = {
        opPermissionLevel: 4, enableCommandBlock: true, allowFlight: false,
        onlineMode: false, whiteList: false,
      };

      const ops = new Map<string, number>([['CortiCam', 4], ['朋友甲', 4]]);
      const roles: Array<[string, string]> = [
        ['CortiV', 'bot'], ['CortiCam', 'camera'], ['Player', 'player'],
      ];
      let detail: string | null = null;
      const state = async () => ({
        configured: true, serverDir: 'C:\\mc\\server', live: false, hosted: false, autoOp: true,
        members: [
          ...roles.map(([name, role]) => ({
            name, role, op: ops.has(name), level: ops.get(name) ?? 0,
          })),
          ...[...ops.keys()].filter((n) => !roles.some(([r]) => r === n))
            .map((name) => ({ name, role: 'other', op: true, level: ops.get(name)! })),
        ],
        settings: { ...settings },
        detail,
      });
      return {
        state,
        setOp: async (name: string, on: boolean) => {
          if (on) ops.set(name, 4);
          else ops.delete(name);
          detail = `${on ? '已授权' : '已收回'} ${name} 的作弊权限(dev,不真落盘)`;
          return state();
        },
        apply: async (patch: Record<string, unknown>) => {
          Object.assign(settings, patch);
          detail = '已写入 server.properties(dev,不真落盘)';
          return state();
        },
      };
    })(),
  } as never,
};

function devPanelSurface(id: string): { invoke(panel: string, method: string, args: unknown[]): Promise<unknown> } | null {
  const mod = devPanels[id];
  if (!mod) return null;
  return {
    invoke: async (panel, method, args) => {
      let p = panel;
      let m = method;
      // minecraft「挂载」的方法名带链路前缀,拆法与 MinecraftWorld.invokePanel 一致
      if (id === 'minecraft' && p === 'mount') {
        const dot = m.indexOf('.');
        const lane = dot < 0 ? '' : m.slice(0, dot);
        if (!['server', 'client', 'player'].includes(lane)) {
          throw new Error(`未知面板方法: ${panel}.${method}`);
        }
        p = lane;
        m = m.slice(dot + 1);
      }
      const fn = mod[p]?.[m];
      if (typeof fn !== 'function') throw new Error(`未知面板方法: ${panel}.${method}`);
      return (fn as (...a: unknown[]) => unknown)(...args);
    },
  };
}

/** 复用 World 的面板声明,以 devPanels 提供方法结果。 */
function devFakeWorld(
  id: string,
  panels: (language: Language) => WorldWebUiDecl['panels'],
  lamps: WorldWebUiDecl['lamps'],
  badges: WorldWebUiDecl['badges'],
  links: WorldWebUiDecl['links'],
  envPrompt: string,

  config: (language: Language) => NonNullable<WorldWebUiDecl['config']> = () => [],
): World {
  const surface = devPanelSurface(id);

  const templatePath = join(devTemplateDir, `${id}.md`);
  writeFileSync(templatePath, envPrompt, 'utf8');
  return {
    id,
    envPromptVars: () => ({}),
    tools: () => [],
    webUi: (language: Language = 'zh') => ({
      lamps,
      badges,
      panels: panels(language),
      links,
      config: config(language),
      promptDocs: [
        {
          key: `worlds.${id}.envPrompt`,
          title: `${worldLabels[id] ?? id} · 环境提示词`,
          description: '(dev) 假模板。',
          path: templatePath,
          role: 'envPrompt' as const,
        },
      ],
      ...(surface ? { invoke: (panel, method, args) => surface.invoke(panel, method, args) } : {}),
    }),
    start: async () => { /* dev:不连任何东西 */ },
    stop: async () => { /* dev:同上 */ },
  };
}

const devMinecraftBadges: WorldWebUiDecl['badges'] = [
  { label: '服务器', value: '127.0.0.1:25565', tone: 'on' },
  { label: '任务', value: '采集 5 个 oak_log', tone: 'on' },
  { label: '画面', value: '客户端主视角', tone: 'on' },
];
const devBilibiliBadges: WorldWebUiDecl['badges'] = [
  { label: '接入', value: '已接入', tone: 'on' },
  { label: '直播间', value: '7734200 · 直播中', tone: 'on' },
  { label: '身份', value: '可认人', tone: 'on' },
  { label: 'Overlay', value: '1 个订阅', tone: 'on' },
];
const devFakeWorlds: World[] = MINIMAL ? [] : [
  devFakeWorld(
    'minecraft', (language) => [...minecraftPanelDecls(language)], [
      { label: '服务器', state: 'online', hint: '127.0.0.1:25565' },
      { label: '任务', state: 'online', hint: '采集 5 个 oak_log' },
      { label: '画面', state: 'online', hint: '客户端主视角' },
    ], devMinecraftBadges,
    [{ label: '打开画面', href: 'http://127.0.0.1:3007' }],
    '(dev) Minecraft World 的环境提示词假数据。',
    (language) => [
      minecraftConfigGroup(language), minecraftRhythmConfigGroup(language), minecraftClientConfigGroup(language),
      minecraftPlayerConfigGroup(language),
    ],
  ),
  devFakeWorld(
    'bilibili', (language) => [...bilibiliPanelDecls(language)], [
      { label: '接入', state: 'online' },
      { label: '直播间', state: 'online', hint: '7734200 · 直播中' },
      { label: '身份', state: 'online', hint: '可认人' },
      { label: 'Overlay', state: 'online', hint: DEV_BILIBILI_OVERLAY_URL ?? undefined },
    ], devBilibiliBadges,
    DEV_BILIBILI_OVERLAY_URL
      ? [
          { label: '打开 Overlay 编辑器', href: devBilibiliOverlay.editorUrl, inheritTheme: true },
          { label: '打开 OBS Overlay', href: DEV_BILIBILI_OVERLAY_URL },
        ]
      : [],
    '(dev) B 站直播间的环境提示词假数据。',
    (language) => [bilibiliConfigGroup(language)],
  ),
];

const devFakeWorldTools: Record<string, string[]> = {
  minecraft: ['mc_do', 'mc_queue', 'mc_check', 'mc_stop', 'mc_escape'],
  bilibili: ['bilibili_set_announcement', 'bilibili_update_video_queue'],
};

/** QQ 事件面板(dev):按会话分组读假事件库 */
function devQqEvents(opts?: { conv?: string; limit?: number }): unknown {
  const all = store.range({ source: 'qq' });
  const convMap = new Map<string, { kind: string; id: number; count: number; lastTs: string }>();
  for (const e of all) {
    const c = e.meta?.conv as { kind?: string; id?: number } | undefined;
    if (!c || (c.kind !== 'group' && c.kind !== 'private') || c.id === undefined) continue;
    const key = `${c.kind}:${Number(c.id)}`;
    const cur = convMap.get(key);
    if (cur) { cur.count++; cur.lastTs = e.ts; } else convMap.set(key, { kind: c.kind, id: Number(c.id), count: 1, lastTs: e.ts });
  }
  const conversations = [...convMap.values()].sort((a, b) => (a.lastTs < b.lastTs ? 1 : -1));
  const m = opts?.conv ? /^(group|private):(\d+)$/i.exec(opts.conv.trim()) : null;
  let events = all;
  if (opts?.conv && !m) events = [];
  else if (m) {
    const kind = m[1].toLowerCase();
    const id = Number(m[2]);
    events = all.filter((e) => {
      const c = e.meta?.conv as { kind?: string; id?: number } | undefined;
      return !!c && c.kind === kind && Number(c.id) === id;
    });
  }
  const limit = Math.max(1, Math.min(2000, Number(opts?.limit) || 300));
  if (events.length > limit) events = events.slice(events.length - limit);
  return {
    conversations,
    events: events.map((e) => ({
      cursor: e.cursor, type: e.type, ts: e.ts, text: e.text, senderKey: e.senderKey,
      senderName: (e.meta?.sender_name as string | undefined) ?? '', conv: e.meta?.conv ?? null,
    })),
    total: all.length,
  };
}


/**
 * A stand-in llama-server in router mode for the `local` endpoint: `/models` with one loaded
 * and one unloaded model, `POST /models` starting a download that finishes on its own, load and
 * unload, `/health` and `/props`. Nothing runs a model.
 */
const fakeLlamaModels: Array<{ id: string; status: string; path: string | null; failed?: boolean; progress?: { done: number; total: number } }> = [
  { id: 'ggml-org/Qwen3-8B-GGUF:Q4_K_M', status: 'loaded', path: 'C:/models/Qwen3-8B-Q4_K_M.gguf' },
  { id: 'unsloth/gemma-3-4b-it-GGUF:Q8_0', status: 'unloaded', path: 'C:/models/gemma-3-4b-it-Q8_0.gguf' },
];
const fakeLlama = createServer((req, res) => {
  const url = new URL(req.url ?? '/', 'http://fake');
  const json = (body: unknown) => { res.setHeader('Content-Type', 'application/json'); res.end(JSON.stringify(body)); };
  if (req.method === 'GET' && url.pathname === '/health') return json({ status: 'ok' });
  if (req.method === 'GET' && url.pathname === '/props') return json({ default_generation_settings: { n_ctx: 16384 } });
  if (req.method === 'GET' && url.pathname === '/models') return json({ data: fakeLlamaModels.map((model) => ({ id: model.id, path: model.path, status: { value: model.status, failed: model.failed === true, ...(model.progress ? { progress: { file: model.progress } } : {}) }, architecture: { input_modalities: ['text'] } })) });
  if (req.method === 'GET' && url.pathname === '/models/sse') { res.setHeader('Content-Type', 'text/event-stream'); res.write(':\n\n'); return; }
  let body = '';
  req.on('data', (chunk) => { body += chunk; });
  req.on('end', () => {
    const { model } = JSON.parse(body || '{}') as { model?: string };
    const found = fakeLlamaModels.find((item) => item.id === model);
    if (url.pathname === '/models' && model && !found) {
      const row: (typeof fakeLlamaModels)[number] = { id: model, status: 'downloading', path: null, progress: { done: 0, total: 4_000_000_000 } };
      fakeLlamaModels.push(row);
      const tick = setInterval(() => {
        row.progress!.done = Math.min(row.progress!.total, row.progress!.done + 250_000_000);
        if (row.progress!.done >= row.progress!.total) { clearInterval(tick); row.status = 'unloaded'; row.path = 'C:/models/' + model.replace(/[/:]/g, '_') + '.gguf'; delete (row as { progress?: unknown }).progress; }
      }, 1000);
      return json({ ok: true });
    }
    if (url.pathname === '/models/load' && found) { found.status = 'loaded'; return json({ ok: true }); }
    if (url.pathname === '/models/unload' && found) {
      if (found.status === 'downloading') fakeLlamaModels.splice(fakeLlamaModels.indexOf(found), 1); else found.status = 'unloaded';
      return json({ ok: true });
    }
    res.statusCode = 404; json({ error: 'not found' });
  });
});
await new Promise<void>((resolve) => fakeLlama.listen(0, '127.0.0.1', resolve));
const fakeLlamaUrl = `http://127.0.0.1:${(fakeLlama.address() as { port: number }).port}/v1`;
devCfg.providers={
 deepseek:{kind:'openai-responses-compat',baseUrl:'https://api.deepseek.com',secret:'DEEPSEEK_API_KEY',spec:{model:'deepseek-v4-pro',thinking:true,reasoningEffort:'low',temperature:1},pricing:[]},
 openrouter:{kind:'openai-responses-compat',baseUrl:'https://openrouter.ai/api/v1',secret:'OPENROUTER_API_KEY',multimodal:true,spec:{model:'anthropic/claude-sonnet-5',thinking:true,reasoningEffort:'medium',contextWindow:200000},
  pricing:[{models:['*'],currency:'USD',basis:'marginal',source:'webui',rules:[{meter:'cachedInput',perMillion:0.3},{meter:'uncachedInput',perMillion:3},{meter:'output',perMillion:15}]}]},
 custom:{kind:'openai-responses-compat',baseUrl:'http://127.0.0.1:8090/v1',spec:{model:'local',thinking:false},options:{extraBody:{service_tier:'flex'}},pricing:[]},
 local:{kind:'llamacpp',baseUrl:fakeLlamaUrl,spec:{model:'ggml-org/Qwen3-8B-GGUF:Q4_K_M',thinking:true},
  options:{runtime:{release:'b10930',backend:'cuda-13.3'},launch:{contextSize:16384,nGpuLayers:99,parallel:1,extraArgs:''},autoStart:false},pricing:[]},
 external:{kind:'llamacpp',baseUrl:'http://127.0.0.1:8080/v1',pricing:[]},
};
devCfg.activeProvider='deepseek';
const devProvidersDir=join(tmpData,'providers');
const devRegistry = new ProviderRegistry(()=>devCfg.providers,{stateRoot:devProvidersDir,readBlob:()=>null,keepThinking:()=>true,log:nullLogger()});
for (const [name, entry] of Object.entries(devCfg.providers)) {
  mkdirSync(join(devProvidersDir, name), { recursive: true });
  writeFileSync(join(devProvidersDir, name, 'config.json'), JSON.stringify(entry));
}
writeFileSync(join(tmpData, 'config.json'), JSON.stringify({ activeProvider: devCfg.activeProvider }));
const devProviders=new ProviderSettings(devCfg, devRegistry,join(tmpData,'config.json'),devProvidersDir);
const devHub = new ProviderHub(devCfg, devRegistry, devProviders, join(tmpData, 'config.json'), devProvidersDir);

function devWebUiPageSources(){return devProviders.sources();}

/**
 * Persona 页与 Memory 页。World 那几页在下面按夹具单独造,所以这里给一张空槽位表:
 * 走的是产线那条装配,页标题、Memory 名与工具表页签才与真跑起来的一样。
 */
const devPersonaPageSources = deriveWebUiPageSources(
  { worldVisibility: () => ({ visibility: {}, driftedWorlds: [] }) },
  { assembly: WorldAssembly.ofInstances([]), persona },
  // bot id 就是这个人格的目录名:面板产物按它查(`assetKeyForPage`),换个名字就找不到产物。
  { id: 'corti-soulmate', label: devCfg.displayName, memoryName: 'GitMem' },
);

/** 扩展页 npm 源输入框写下的值;只存在内存里。 */
let devNpmRegistry: string | null = null;

/** 上一版契约的包在扩展页上带的那条 warning。 */
const previousContractWarnings = parseExtensionManifest({
  type: 'module', keywords: ['cortico-world'], cortico: { kind: 'world', api: PREVIOUS_CONTRACT_VERSIONS.world },
}).warnings;

/** 扩展页的假清单(见下面 `extensions` 依赖)。kind 缺了会被归进「未识别」组。 */
const devExtensions: ExtensionInfo[] = [
  { name: 'cortico-world-almanac', spec: '^0.4.0', version: '0.4.2', description: '按上一版契约写的黄历 World (dev 假数据)', kind: 'world', api: PREVIOUS_CONTRACT_VERSIONS.world, webUiClient: false, loaded: true, worldId: 'almanac', label: '黄历', state: 'loaded', enabled: true, author: 'someone', warnings: previousContractWarnings, metadata: { dependencies: [], links: {} } },
  {
    name: '@acme/cortico-world-discord', spec: '^0.3.0', version: '0.3.1', description: 'Discord 频道接入 (dev 假数据)', kind: 'world', webUiClient: false, loaded: true, worldId: 'discord', label: 'Discord 频道', state: 'loaded', enabled: true, author: 'acme',
    metadata: { displayName: 'Discord', license: 'MIT', dependencies: ['ws'], links: { repository: 'https://github.com/acme/cortico-world-discord', bugs: 'https://github.com/acme/cortico-world-discord/issues' } },
  },
  { name: 'cortico-provider-example', spec: '^1.0.0', version: '1.0.2', description: '示例模型通信协议 (dev 假数据)', kind: 'provider', webUiClient: false, loaded: true, worldId: 'example', label: 'Example', state: 'loaded', enabled: true, author: 'someone', metadata: { license: 'MIT', dependencies: [], links: {} } },
  { name: 'cortico-bot-example', spec: '^0.2.0', version: '0.2.0', description: '示例 bot 模板 (dev 假数据)', kind: 'bot', webUiClient: false, loaded: false, worldId: 'example-bot', label: 'Example Bot', state: 'idle', enabled: false, author: 'someone', metadata: { displayName: 'Example Bot', dependencies: [], links: {} } },
  { name: 'mystery-package', spec: '^1.0.0', version: '1.0.0', webUiClient: false, loaded: false, reason: 'package.json 缺少 cortico 块(至少要 kind 与 api)。', state: 'failed' },
  { name: 'cortico-world-broken', spec: '^0.1.0', version: '0.1.4', kind: 'world', webUiClient: true, loaded: false, reason: '默认导出不是 WorldDefinition(需要 id / label / defaults() / create())。', state: 'failed' },
  { name: 'cortico-world-weather', spec: 'link:../cortico-world-weather', version: '0.0.1', kind: 'world', description: '本机开发中的天气播报 (dev 假数据)', webUiClient: false, loaded: false, state: 'pending-restart' },
];

/**
 * 扩展搜索的假命中表。条数超过一页,下载量、发布时间、许可证、发布者各不相同:
 * 筛选、排序、分页在这张表上能各自看出效果。下载量的数是近 30 天,累计与近 7 天由它推出;
 * 契约版本对不上的那个包装作 npm 下载统计没答上来,只有近 30 天。
 */
const devSearchHits: ExtensionSearchHit[] = [
  ['@acme/cortico-world-discord', '0.3.2', 'Discord 频道接入', 'acme', 412, 3, 'MIT', '2026-08-30', ['chat']],
  ['cortico-world-rss', '1.0.0', 'RSS 订阅轮询,按源分栏投递', 'feedworks', 38, 0, 'MIT', '2026-09-11', ['feed']],
  ['cortico-world-matrix', '0.7.2', 'Matrix 房间接入,支持端到端加密房', 'kyoka', 1240, 12, 'Apache-2.0', '2026-09-18', ['chat']],
  ['cortico-world-telegram', '2.1.0', 'Telegram bot 接入', 'acme', 8800, 41, 'MIT', '2026-09-02', ['chat']],
  ['cortico-world-obs', '0.2.0', 'OBS 场景切换与录制控制', 'streamkit', 96, 1, 'MIT', '2026-07-21', ['stream']],
  ['cortico-world-home', '1.4.3', 'Home Assistant 实体读写', 'hausen', 520, 5, 'GPL-3.0', '2026-06-14', ['iot']],
  ['cortico-world-console-plus', '0.9.0', '本机控制台增强:多标签与会话录制', 'phantivia', 77, 0, 'MIT', '2026-09-19', ['tool']],
  ['cortico-world-calendar', '1.1.1', '日历读写与提醒投递', 'hausen', 205, 2, 'MIT', '2026-05-30', ['tool']],
  ['cortico-world-minecraft-lite', '0.4.0', '精简版 Minecraft 接入,只做观察不做操作', 'blockish', 640, 0, 'MIT', '2026-08-02', ['game']],
  ['cortico-world-webhook', '1.0.2', '收发 webhook,把外部事件变成事件帧', 'feedworks', 310, 7, 'ISC', '2026-09-15', ['tool']],
  ['cortico-world-broken', '0.1.4', '契约版本对不上的包', 'someone', 4, 0, 'MIT', '2025-11-08', ['broken']],
  ['cortico-world-weather', '0.0.1', '天气播报', 'phantivia', 12, 0, 'MIT', '2026-09-20', ['tool']],
  ['cortico-world-notion', '0.6.0', 'Notion 数据库读写', 'kyoka', 1502, 9, 'MIT', '2026-04-27', ['docs']],
  ['cortico-world-shell-sandbox', '0.3.3', '受限 shell 沙箱', 'blockish', 58, 0, 'BSD-3-Clause', '2026-03-19', ['tool']],
].map(([name, version, description, publisher, downloads, dependents, license, date, tags]) => ({
  name: name as string,
  version: version as string,
  description: `${description as string} (dev 假数据)`,
  publisher: publisher as string,
  downloads: name === 'cortico-world-broken'
    ? { month: downloads as number }
    : { total: (downloads as number) * 3 + 17, month: downloads as number, week: Math.floor((downloads as number) / 4) },
  dependents: dependents as number,
  license: license as string,
  date: `${date as string}T09:00:00.000Z`,
  keywords: ['cortico-world', ...(tags as string[])],
  kind: 'world' as const,
  links: {
    npm: `https://www.npmjs.com/package/${name as string}`,
    repository: `https://github.com/${publisher as string}/${(name as string).replace(/^@[^/]+\//, '')}`,
  },
  installed: false,
}));

/** 随框架提供的条目:两个 World 挂着、一个没挂、一个构造失败,外加两个 provider。 */
const devBuiltins: ExtensionInfo[] = [
  ...([['console', '控制台', true], ['websearch', '网页搜索', true], ['qq', 'QQ', false]] as const).map(([id, label, enabled]) => ({
    name: `builtin:world:${id}`, spec: 'builtin', version: '0.1.4', installedVersion: '0.1.4', kind: 'world' as const, worldId: id, label,
    webUiClient: false, loaded: true, state: 'loaded' as const, builtin: true, enabled, author: 'phantivia', location: 'C:/dev/cortico',
  })),
  {
    name: 'builtin:world:minecraft', spec: 'builtin', version: '0.1.4', installedVersion: '0.1.4', kind: 'world', worldId: 'minecraft', label: 'Minecraft',
    webUiClient: false, loaded: false, state: 'failed', builtin: true, enabled: false, author: 'phantivia', location: 'C:/dev/cortico', reason: '构造失败:找不到 Java 21 (dev 假数据)',
  },
  ...([['llamacpp', 'llama.cpp'], ['openai-responses-compat', 'OpenAI Compatible']] as const).map(([id, label]) => ({
    name: `builtin:provider:${id}`, spec: 'builtin', version: '0.1.4', installedVersion: '0.1.4', kind: 'provider' as const, worldId: id, label,
    webUiClient: false, loaded: true, state: 'loaded' as const, builtin: true, enabled: true, author: 'phantivia', location: 'C:/dev/cortico',
  })),
];
devSearchHits.push(
  { name: 'cortico-provider-example', version: '1.0.3', description: '示例模型通信协议 (dev 假数据)', publisher: 'someone', downloads: { total: 301, month: 88, week: 19 }, dependents: 0, license: 'MIT', date: '2026-09-10T09:00:00.000Z', keywords: ['cortico-provider'], kind: 'provider', links: { npm: 'https://www.npmjs.com/package/cortico-provider-example' }, installed: false },
  { name: 'cortico-bot-example', version: '0.2.0', description: '示例 bot 模板 (dev 假数据)', publisher: 'someone', downloads: { total: 20, month: 20, week: 20 }, dependents: 0, license: 'MIT', date: '2026-09-12T09:00:00.000Z', keywords: ['cortico-bot'], kind: 'bot', links: { npm: 'https://www.npmjs.com/package/cortico-bot-example' }, installed: false },
);

/**
 * 扩展市场的假数据:词表只有几个标签,keywords 命中即贴;GitHub 账号、票与评论都在内存里。
 * 没登录时投票与评论回 428,登录码申请后第二次查询账号就算登上。
 */
const devMarketTags: Record<string, MarketTag> = {
  chat: { label: '即时通讯', hint: '接入聊天平台。(dev 假数据)' },
  game: { label: '游戏', hint: '接入、观察和操作游戏。(dev 假数据)' },
  tool: { label: '工具', hint: '通用工具。(dev 假数据)' },
  experimental: { label: '实验性', hint: '作者标明还在测试。(dev 假数据)', style: 'notice' },
  unsafe: { label: '不安全', hint: '能在本机执行任意命令。(dev 假数据)', style: 'warning' },
};
let devGithubLogin: string | null = null;
/** 扩展页索引源输入框写下的值;只存在内存里。 */
let devIndexBase: string | null = null;
let devLoginPolls = -1;
const devVotes = new Map<string, 'up' | 'down'>();
const devComments = new Map<string, ExtensionComment[]>();
const devLoginRequired = () => new LocalizedError((language) => `${language === 'en' ? 'Sign in with GitHub first.' : '需要先登录 GitHub。'} (dev)`, 428);
const devRating = (name: string): ExtensionRating => {
  const hit = devSearchHits.find((h) => h.name === name);
  const mine = devVotes.get(name);
  const base = Math.round((hit?.downloads.month ?? 0) / 100);
  return { up: base + (mine === 'up' ? 1 : 0), down: (mine === 'down' ? 1 : 0), comments: devComments.get(name)?.reduce((n, c) => n + 1 + (c.replies?.length ?? 0), 0) ?? 0, discussion: `https://github.com/Pal-AI-Lab/cortico-extensions/discussions/${devSearchHits.indexOf(hit!) + 1}`, ...(mine ? { mine } : {}) };
};
/** 图标与截图用内联 SVG,不取网络。 */
const devSvg = (width: number, height: number, color: string, text: string) => `data:image/svg+xml,${encodeURIComponent(
  `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}"><rect width="100%" height="100%" rx="${Math.min(width, height) / 8}" fill="${color}"/><text x="50%" y="55%" fill="#fff" font-family="sans-serif" font-size="${Math.min(width, height) / 3}" text-anchor="middle">${text}</text></svg>`)}`;
/** catalog.json 里列表要用的字段,按包名;没列出的包就是索引里没有这几项。 */
const devCatalog: Record<string, Partial<ExtensionSearchHit>> = {
  '@acme/cortico-world-discord': {
    displayName: 'Discord', author: 'Acme Labs', icon: devSvg(64, 64, '#5865f2', 'D'),
    screenshots: [devSvg(320, 180, '#3b4252', '频道列表'), devSvg(320, 180, '#434c5e', '消息投递')],
    summary: { tools: 6, events: 9, toolTokens: 1820, envPromptTokens: 640 },
    changelog: { versions: ['0.3.2', '0.3.1', '0.3.0'], url: 'https://github.com/acme/cortico-world-discord/blob/HEAD/CHANGELOG.md' },
  },
  'cortico-world-matrix': { displayName: 'Matrix', author: 'Kyoka', os: ['!darwin'], summary: { tools: 14, events: 2, toolTokens: 3150, envPromptTokens: 1420 } },
  'cortico-world-obs': { author: 'StreamKit', os: ['win32'], icon: devSvg(64, 64, '#302e31', 'OBS'), summary: { tools: 3, events: 0, toolTokens: 7230, envPromptTokens: 12600 } },
  'cortico-provider-example': { summary: { protocols: ['openai-chat'], auth: ['api-key', 'oauth'], input: ['text', 'image'], local: false } },
  'cortico-bot-example': { displayName: 'Example Bot', summary: { worlds: 3, memory: 'workspace' } },
};
/** packages/<包名>.json 里的自描述(已按语言取好)与更新日志正文。 */
const devPackageFiles: Record<string, { describe?: ExtensionDescribe; changelog?: Record<string, string> }> = {
  '@acme/cortico-world-discord': {
    describe: {
      tools: [
        { name: 'discord_send_message', description: 'Send a message to a channel. Long text is split at 2000 characters.', summary: '往频道发一条消息', tags: ['speak'] },
        { name: 'discord_read_history', description: 'Read the latest messages of a channel.', tags: ['read'] },
        { name: 'discord_add_reaction', description: 'React to a message with an emoji.', summary: '给消息加表情回应', tags: ['act'] },
        { name: 'discord_list_channels', description: 'List the channels the bot can see.', tags: ['read'] },
        { name: 'discord_join_voice', description: 'Join a voice channel.', tags: ['act'] },
        { name: 'discord_leave_voice', description: 'Leave the current voice channel.', tags: ['act'] },
      ],
      events: ['message', 'mention', 'reaction', 'join', 'leave', 'voice', 'typing', 'edit', 'delete'].map((type) => ({ type: `discord.${type}`, description: `频道里的 ${type} (dev 假数据)` })),
      prompts: [{ key: 'worlds.discord.envPrompt', title: '环境提示词', role: 'envPrompt', content: '你在 Discord 上。\n\n下面是你所在的频道:\n{{channels}}' }],
    },
    changelog: {
      '0.3.2': '- 修复长消息被截断\n- 频道列表按分类分组',
      '0.3.1': '- 新增 `discord_add_reaction`',
      '0.3.0': '### 语音\n\n- 可以加入与离开语音频道',
    },
  },
  'cortico-provider-example': {
    describe: { provider: { protocols: ['openai-chat'], auth: ['api-key', 'oauth'], local: false, input: ['text', 'image'] } },
  },
  'cortico-bot-example': {
    describe: {
      bot: { worlds: ['console', 'qq', 'websearch'], memory: { name: 'workspace', form: '文件工作区,按目录分主题 (dev 假数据)' } },
      tools: [{ name: 'memory_read', description: 'Read a file from the workspace.', summary: '读工作区里的文件', tags: ['read'] }],
      prompts: [{ key: 'persona.constitution', title: '宪法', role: 'prefix', content: '你是一个陪伴型 bot。(dev 假数据)' }],
    },
  },
};
const devMarket: WebAppMarketDeps = {
  mergePackage: async (name, detail) => {
    const info = await detail;
    const file = devPackageFiles[name];
    return { ...info, ...(file?.describe && info.version === devSearchHits.find((h) => h.name === name)?.version ? { describe: file.describe } : {}), ...(file?.changelog ? { changelog: file.changelog } : {}) };
  },
  merge: async (search) => ({
    hits: (await search).map((hit) => ({
      ...hit,
      ...devCatalog[hit.name],
      tags: [...(hit.keywords ?? []).filter((k) => devMarketTags[k]), ...(hit.name === 'cortico-world-shell-sandbox' ? ['unsafe'] : []), ...(hit.name === 'cortico-world-weather' ? ['experimental'] : [])],
      ...(hit.publisher === 'phantivia' ? { official: true } : {}),
      ...(hit.name === 'cortico-world-matrix' ? { certified: true } : {}),
      ...(hit.date && Date.now() - Date.parse(hit.date) < 14 * 86_400_000 ? { isNew: true } : {}),
      rating: devRating(hit.name),
    })),
    index: { tags: devMarketTags, newDays: 14 },
  }),
  blocked: () => undefined,
  indexBase: () => ({ configured: devIndexBase, base: devIndexBase ?? 'https://raw.githubusercontent.com/Pal-AI-Lab/cortico-extensions/main' }),
  setIndexBase: (url) => {
    const value = url.trim().replace(/\/+$/, '');
    if (value && !/^https?:\/\/\S+$/i.test(value)) throw new LocalizedError(() => `索引源要填 http:// 或 https:// 开头的地址,现在是 ${value} (dev)`, 400);
    devIndexBase = value || null;
    return devMarket.indexBase();
  },
  account: () => {
    if (!devGithubLogin && devLoginPolls >= 0 && devLoginPolls-- === 0) devGithubLogin = 'dev-user';
    return devGithubLogin ? { login: devGithubLogin } : {};
  },
  login: async () => { devLoginPolls = 1; return { userCode: 'DEVC-0DE1', verificationUri: 'https://github.com/login/device', expiresIn: 900, interval: 2 }; },
  logout: () => { devGithubLogin = null; devLoginPolls = -1; devVotes.clear(); },
  vote: async (name, vote) => {
    if (!devGithubLogin) throw devLoginRequired();
    if (vote) devVotes.set(name, vote); else devVotes.delete(name);
    return devRating(name);
  },
  comments: async (name, cursor) => {
    const all = devComments.get(name) ?? [];
    const from = Number(cursor ?? 0);
    return { comments: all.slice(from, from + 5), total: all.length, ...(from + 5 < all.length ? { next: String(from + 5) } : {}), ...(all.length ? { discussion: devRating(name).discussion } : {}) };
  },
  comment: async (name, body, replyTo) => {
    if (!devGithubLogin) throw devLoginRequired();
    const comment: ExtensionComment = { id: `dev-${Date.now()}`, author: devGithubLogin, body, createdAt: new Date().toISOString() };
    const all = devComments.get(name) ?? [];
    const top = replyTo ? all.find((c) => c.id === replyTo) : undefined;
    if (top) top.replies = [...(top.replies ?? []), comment]; else devComments.set(name, [comment, ...all]);
    return comment;
  },
};

const app = new WebApp({
  store,
  memoryDir: tmpPersona,
  dataDir: tmpData,
  botDir: tmpPersona,
  blob: (handle) => devBlobs.read(handle),
  password: process.env.CORTICO_DEV_PASSWORD ?? '',
  defaultScheme: cfg.web.theme,
  getStatus: () => ({
    modelConnection: devHub.current(devCfg.language ?? 'zh'),
    loop: { estTokens: 90200, messageCount: session.length, roundsLastBatch: 3, batchesHandled: 37, paused, truncating: false, softNoticeSent: false, lastUsage: { promptTokens: 358000, cacheHitTokens: 322000, cacheMissTokens: 36000, completionTokens: 420, reasoningTokens: 180 } },
    chips: devDreaming ? [{ label: '梦中', tone: 'accent' }] : [],
    consoleOnline: consoleWorld.onlineCount(),
    latestEventCursor: store.latestCursor(),
    onboardingPending,
    memo: { residentCap: cfg.memo.residentCap, activeCap: cfg.memo.activeCap },
    context: { maxTokens: cfg.context.maxTokens, softRatio: cfg.context.softRatio, keepPastThinking: cfg.context.keepPastThinking },
    displayName: devCfg.displayName,
    startedAt: '2026-07-19T09:00:00+08:00',
  }),
  sessions: { list: () => sessionsList, messages: (id) => (id === 'main' ? session : sessionsList.some((s) => s.id === id) ? session.slice(0, 4) : null), onChange: () => {} },
  storage: () => storage,
  usage: {
    aggregate: async (opts) => {
      const { rates, sources } = await devRates.resolve();
      return { ...aggregateUsage(usageRecords, { ...opts, timezone: TZ, rates }), rateSources: sources };
    },
  },

  config: {
    groups: () => [...devConfigGroups,...devProviders.groups()].map((group) => ({ group, values: group.owner.startsWith('provider:') ? devProviders.values(group.id) : readGroupValues(devCfg, group) })),
    set: (groupId, values) => {
      if(devProviders.groups().some(group=>group.id===groupId))return devProviders.setConfig(groupId,values);
      const root = devCfg as unknown as Record<string, unknown>;
      for (const [path, v] of Object.entries(values)) setByPath(root, path, v);
      return `${devConfigGroups.find((g) => g.id === groupId)?.schema.title ?? groupId}已更新 (dev,仅本次)`;
    },
  },
  // 通过 World 声明适配页面,invoke 使用假数据。
  webUiPageSources: () => [...devWebUiPageSources(), ...devPersonaPageSources(), ...[...worlds, ...devFakeWorlds].map((m) => ({
    id: pageIdFor('world', m.id),
    contribute: (language: Language) => {
      const c = ioPageContribution(m.id, worldLabels[m.id] ?? m.id, {
        id: m.id,
        status: 'active',
        declared: true,
        workspace: `worlds/${m.id}`,
        tools: [],
        visible: devWorldVisible[m.id] !== false,
        prefixDrifted: devWorldDrift.has(m.id),
      }, m, language);
      if (m.id === 'bilibili') c.undeclared = { tools: [], events: ['bilibili.devprobe'] };
      const dev = devPanelSurface(m.id);
      if (dev) c.invoke = (panel, method, args) => dev.invoke(panel, method, args);
      return c;
    },
  }))],
  providers: devHub,
  worlds: async () => [
    ...(await Promise.all([...worlds, ...devFakeWorlds].map(async (m) => {
      const decl = m.webUi?.();
      return {
        id: m.id,
        status: 'active' as const,
        label: worldLabels[m.id] ?? m.id,
        declared: true,
        envPrompt: (await renderWorldEnvPrompt(m)).text,
        workspace: `worlds/${m.id}`,
        tools: m.tools().map((t) => t.name).concat(devFakeWorldTools[m.id] ?? []),
        visible: devWorldVisible[m.id] !== false,
        prefixDrifted: devWorldDrift.has(m.id),
        ...(decl?.lamps ? { lamps: decl.lamps } : {}),
        ...(decl?.badges ? { badges: decl.badges } : {}),
      };
    }))),
// 模拟已安装但未激活的 World:启动期 start() 抛错后回到未激活,带理由。
    {
      id: 'sandbox',
      status: 'inactive' as const,
      label: '沙盒 World',
      declared: false,
      reason: '启动失败: listen EADDRINUSE: address already in use 127.0.0.1:7797 (dev 假数据)',
    },
    // 截图夹具覆盖Persona已声明但未安装的 World 状态。
    {
      id: 'phantom',
      status: 'missing' as const,
      label: '幻影 World',
      declared: true,
      reason: '本地没有找到 cortico-world-phantom 的实现 (dev 假数据)',
    },
  ],
  worldActivation: {
    set: async (id, enabled) => `worlds.${id}.enabled=${enabled} 已写回 config.json (dev,不真挂载)`,
    restart: async (id) => `${id} 已重启 (dev,不真重启)`,
  },
  worldVisibility: {
    state: () => ({ visibility: { ...devWorldVisible }, driftedWorlds: [...devWorldDrift] }),
    set: (id, visible) => {
      devWorldVisible[id] = visible;

      if (visible) devWorldDrift.add(id); else devWorldDrift.add(id);
      return `${id} 已${visible ? '对 agent 可见' : '对 agent 隐藏'} (dev)`;
    },
  },
  prompts: {
    list: () => devPromptDocs.map((doc) => ({ ...doc })),

    prefix: async () => [
      { title: 'ORIENTATION', text: '\n━━━ ORIENTATION ━━━\n' + persona.orientationText().trim(), sourceKey: 'orientation' },
      { title: '宪法', text: '\n\n━━━ 宪法 ━━━\n' + persona.constitutionText().trim(), sourceKey: 'constitution' },
      { title: '环境:qqWorld', text: '\n\n━━━ 环境:qqWorld ━━━\n你在QQ上。\n\n下面是你正在参与的会话:\n- 群「深夜食堂」(群号424242);你在这个群的昵称是「Yukima」\n你的QQ号是5000。', sourceKey: 'worlds.qq.envPrompt' },
      { title: 'Using your tools', text: '\n\n━━━ Using your tools ━━━\n(各工具的 usage,来自代码)', },
      { title: '记忆', text: '\n\n━━━ 记忆 ━━━\n【MEMORY 0·地图】\npersona/ 的最外层目录。…', sourceKey: 'persona.memory' },
    ],
    write: (key, content, baseRevision) => {
      const doc = devPromptDocs.find((item) => item.key === key);
      if (!doc) throw new Error(`未知提示词模板: ${key}`);
      if (baseRevision && baseRevision !== doc.revision) throw new PromptRevisionConflict(`${doc.title} 已在别处被修改，请重新载入后再保存`);
      doc.content = content; doc.revision = createHash('sha256').update(content).digest('hex');
      return `已保存 ${doc.title} (dev)`;
    },
  },
  toolSchemas: {
    list: () => toolSchemas,
  },
  sessionControl: {
    reloadPrefix: async () => {
      devWorldDrift.clear();
      return '系统前缀与工具表已重载，保留当前session的既有消息 (dev)';
    },
  },
  market: devMarket,
  // 扩展面的假数据:四种状态各一;装卸只改这张表,不跑 pnpm。
  extensions: {
    list: () => ({ dir: 'C:/dev/cortico/extensions', extensions: [...devExtensions.map((p) => ({ ...p })), ...devBuiltins] }),
    updates: async () => ({
      updates: devExtensions.some((p) => p.name === '@acme/cortico-world-discord' && p.state !== 'removed' && p.installedVersion !== '0.3.2')
        ? [{ name: '@acme/cortico-world-discord', installedVersion: '0.3.1', latestVersion: '0.3.2', problems: [] }] : [],
      errors: [],
    }),
    search: async (kind) => {
      await new Promise((r) => setTimeout(r, 300));
      return devSearchHits.filter((hit) => hit.kind === (kind ?? 'world')).map((hit) => ({
        ...hit,
        installed: devExtensions.some((p) => p.name === hit.name && p.state !== 'removed'),
      }));
    },
    searchPartial: () => false,
    npmRegistry: async () => devNpmRegistry ?? 'https://registry.npmjs.org',
    configuredRegistry: () => devNpmRegistry,
    setRegistry: (url) => {
      const value = url.trim();
      if (value && !/^https?:\/\/\S+$/i.test(value)) throw new LocalizedError(() => `npm 源要填 http:// 或 https:// 开头的地址,现在是 ${value} (dev)`);
      devNpmRegistry = value || null;
    },
    check: async (target, kind) => {
      await new Promise((r) => setTimeout(r, 300));
      if ('path' in target) return { name: `local-${target.path.split(/[\\/]/).filter(Boolean).pop() ?? 'module'}`, version: '0.0.1', kind: kind ?? 'world' };
      const hit = devSearchHits.find((h) => h.name === target.name);
      if (!hit) throw new Error(`registry 没有给出 ${target.name} 的 ${target.version ?? 'latest'} 版本 (dev)`);
      if (kind && hit.kind !== kind) throw new Error(`扩展实际类型为 ${hit.kind}，请切换到对应分类。(dev)`);
      return { name: hit.name, version: target.version ?? hit.version, kind: hit.kind ?? 'world' };
    },
    packageInfo: async (name) => {
      await new Promise((r) => setTimeout(r, 400));
      const hit = devSearchHits.find((h) => h.name === name);
      if (!hit) throw new Error(`registry 没有给出 ${name} 的 latest 版本 (dev)`);
      // 一个契约版本对不上、一个已弃用:详细页的两种警示态在 dev 里也能看见
      const broken = name === 'cortico-world-broken';
      const stale = name === 'cortico-world-calendar';
      return {
        name,
        version: hit.version,
        ...(name === '@acme/cortico-world-discord' ? { displayName: 'Discord' } : {}),
        description: hit.description,
        license: hit.license,
        keywords: hit.keywords,
        published: hit.date,
        created: '2025-10-01T00:00:00.000Z',
        versionCount: 7,
        history: [
          { version: hit.version, date: hit.date ?? '' },
          { version: '0.9.0', date: '2026-03-02T00:00:00.000Z' },
          { version: '0.8.0', date: '2026-01-19T00:00:00.000Z', warnings: previousContractWarnings },
        ],
        ...(stale ? { deprecated: '不再维护,改用 cortico-world-webhook (dev 假数据)' } : {}),
        ...(broken
          ? { problems: [`扩展要求 world 契约 v9,本框架的 world 契约只到 v${EXTENSION_API_VERSIONS.world}:框架需要升级。`] }
          : {
              manifest: { kind: hit.kind ?? 'world', api: EXTENSION_API_VERSIONS[hit.kind ?? 'world'], webUiClient: 'dist/webui.js' },
              frameworkApi: EXTENSION_API_VERSIONS[hit.kind ?? 'world'],
            }),
        warnings: [],
        engines: '>=22',
        unpackedSize: 184074,
        fileCount: 41,
        dependencies: ['ws', 'undici'],
        maintainers: [hit.publisher ?? 'someone'],
        author: devCatalog[name]?.author ?? devExtensions.find(p => p.name === name)?.author ?? 'example-author',
        publisher: hit.publisher,
        links: { ...hit.links, npm: hit.links.npm ?? `https://www.npmjs.com/package/${name}`, bugs: `${hit.links.repository ?? ''}/issues` },
        installed: devExtensions.some((p) => p.name === name && p.state !== 'removed'),
      };
    },
    install: async (target) => {
      await new Promise((r) => setTimeout(r, 500));
      const name = 'name' in target ? target.name : `local-${target.path.split(/[\\/]/).filter(Boolean).pop() ?? 'module'}`;
      const spec = 'name' in target ? (target.version ?? '^1.0.0') : `link:${target.path}`;
      const existing = devExtensions.find((p) => p.name === name);
      if (existing) Object.assign(existing, { spec, installedVersion: 'name' in target ? target.version ?? existing.version : existing.version, state: 'pending-restart' });
      else devExtensions.push({ name, spec, version: '1.0.0', webUiClient: false, loaded: false, state: 'pending-restart' });
      return `已安装 ${name}@${spec}。重启进程后加载。\nProgress: resolved 12, reused 12, downloaded 0\n+ ${name} 1.0.0\nDone in 1.8s (dev,没真跑 pnpm)`;
    },
    uninstall: async (name) => {
      const p = devExtensions.find((item) => item.name === name);
      if (!p) throw new Error(`没有安装这个包: ${name}`);
      if (p.loaded) p.state = 'removed'; else devExtensions.splice(devExtensions.indexOf(p), 1);
      return `已卸载 ${name}。重启进程后生效。(dev)`;
    },
  },
  onboarding: { dismiss: () => { onboardingPending = false; } },

  run: {
    pause: () => { paused = true; },
    resume: () => { paused = false; },
    isPaused: () => paused,

    restart: async () => {
      await new Promise((r) => setTimeout(r, 400));
      return {
        complete: true,
        steps: [
          { label: '暂停事件投递', ok: true, elapsedMs: 3 },
          { label: '停止 World', ok: true, elapsedMs: 1200 },
          { label: '保存 Core 状态', ok: true, elapsedMs: 5 },
        ],
      };
    },
    supervised: true,
// 返回关机报告,保留开发 WebUI 进程。
// 模拟一个停止超时的步骤。
    shutdown: async () => {
      await new Promise((r) => setTimeout(r, 600));
      return {
        complete: false,
        steps: [
          { label: '暂停事件投递', ok: true, elapsedMs: 3 },
          { label: '停止 World', ok: true, elapsedMs: 4210 },
          { label: '托管 LLM server 停机', ok: false, elapsedMs: 3000, detail: '托管 LLM server 停机超时(3秒)' },
          { label: '保存 Core 状态', ok: true, elapsedMs: 6 },
        ],
      };
    },
  },
  debug: {
    sessionMessages: () => session,
    onSessionAppend: () => {},
    onSessionReset: () => {},
    onEvent: () => {},
    onRunlog: () => {},
    toolSchemas: () => toolSchemas,
  },
  log: nullLogger(),
});

const actual = await app.start(port);
app.markReady();
console.log(`\n[dev-webui] 假数据面板已启动: http://127.0.0.1:${actual}/`);
console.log('[dev-webui] Ctrl-C 退出。数据全是假的,不连真 API/core。\n');
