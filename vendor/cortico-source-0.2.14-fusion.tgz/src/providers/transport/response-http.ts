import type { Logger } from '../../core/types.ts';
import type { Request, Response, StreamEvent } from '../../protocol/open-responses/index.ts';
import type { ItemOrigin } from '../../protocol/open-responses/context.ts';
import { GenerationError, priceUsage, unknownMeters, type GenerateOptions, type Generation, type ProviderAttempt, type PriceSnapshot, type TokenMeters } from '../../core/generation.ts';
import { ResponseProtocolError } from '../../protocol/open-responses/stream.ts';
import { LLMError, StreamErrorEvent, abortError, parseRetryAfter, retryDelay, reqIdSuffix, upstreamText } from './errors.ts';
import type { ResponseAssembly } from './response-assembly.ts';

export interface ResponseTransport {
  url: string;
  body: Record<string, unknown>;
  headers(): Record<string, string> | Promise<Record<string, string>>;
  refresh(): Promise<boolean>;
  assembly(): ResponseAssembly;
  parse(raw: unknown): { response: Response; meters: TokenMeters; serviceTier: string | null };
  failure(info: { model: string; role?: string; elapsedMs: number; status: number; requestId: string | null; body: string; message: string }, record: (attempts: ProviderAttempt[]) => void): Promise<boolean>;
  succeeded(): void;
  log: Logger;
}

const LONE_SURROGATE = /[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?<![\uD800-\uDBFF])[\uDC00-\uDFFF]/g;

/**
 * Serializes a request body with every lone surrogate replaced by U+FFFD; upstream parsers reject
 * the \uXXXX escape JSON.stringify writes for one.
 */
export function requestJson(body: unknown): string {
  return JSON.stringify(body, (_key, value: unknown) =>
    typeof value === 'string' ? value.replace(LONE_SURROGATE, '\uFFFD') : value);
}

/**
 * SSE framing is independent of packet and line boundaries. Each character is searched for a line end once,
 * so a long line sent in many chunks costs time in proportion to its length.
 */
export class EventDecoder {
  private buffer = '';
  /** The part of `buffer` already searched: it holds no line end. */
  private scanned = 0;
  private data: string[] = [];
  feed(text: string): string[] {
    this.buffer += text;
    const events: string[] = [];
    let start = 0;
    for (;;) {
      const newline = this.buffer.indexOf('\n', Math.max(start, this.scanned));
      if (newline < 0) break;
      const line = this.buffer.slice(start, newline).replace(/\r$/, '');
      start = newline + 1;
      if (line === '') {
        if (this.data.length) events.push(this.data.join('\n'));
        this.data = [];
      } else if (line.startsWith('data:')) {
        this.data.push(line.slice(5).replace(/^ /, ''));
      }
    }
    this.buffer = this.buffer.slice(start);
    this.scanned = this.buffer.length;
    return events;
  }
}

function irreversible(event: StreamEvent): boolean {
  return event.type === 'response.output_text.delta' || event.type === 'response.refusal.delta'
    || event.type === 'response.function_call_arguments.delta'
    || (event.type === 'response.output_item.added' && event.item?.type === 'function_call');
}

/** 带内容的事件:增量,或输出项的开合。keepalive 帧与空事件不算。 */
function carriesContent(event: StreamEvent): boolean {
  return 'delta' in event || event.type === 'response.output_item.added' || event.type === 'response.output_item.done';
}

/** 首包等待上限：流式 300 秒，非流式 120 秒。 */
const FIRST_RESPONSE_MS = { streaming: 300_000, unary: 120_000 } as const;
/** 帧空闲:连续这么久一个字节都没来。 */
const FRAME_IDLE_MS = 120_000;
/**
 * 内容事件的空闲期限；keepalive 和空 delta 不重置它。
 * 该计时器独立于字节接收计时，以覆盖持续收到空帧的响应。
 */
const CONTENT_IDLE_MS = 300_000;

/**
 * 错误文本:`<错误> (<cause 的错误码>: <cause 的说明>)`。undici 的错误文本固定是 `fetch failed`,
 * 证书不符、DNS 解析失败、连接被重置只在 cause 里。
 */
function errorText(error: unknown): string {
  const message = error instanceof Error ? error.message : String(error);
  const cause = error instanceof Error ? error.cause : undefined;
  const code = (cause as { code?: unknown } | undefined)?.code;
  const detail = cause instanceof Error ? [typeof code === 'string' ? code : '', cause.message].filter(Boolean).join(': ') : '';
  return `${message}${detail ? ` (${detail})` : ''}`;
}

/** Every fetch attempt produces its own immutable metering and price snapshot. */
export async function generate(request: Request, options: GenerateOptions, origin: ItemOrigin, transport: ResponseTransport): Promise<Generation> {
  const generationId = crypto.randomUUID();
  const attempts: ProviderAttempt[] = [];
  let lastError: unknown;
  let partial: Response | null = null;
  let authRetried = false;
  // 上一次尝试的 `Retry-After`;没有头或解析不成形时按固定间隔退避。
  let retryAfterMs: number | null = null;
  const delays = options.diagnostic ? [] : [1000, 4000, 10000];
  const fail = (error: unknown): GenerationError => new GenerationError(errorText(error) + reqIdSuffix(attempts.filter(attempt => attempt.purpose !== 'diagnostic').at(-1)?.requestId), attempts,
    partial, origin, error instanceof LLMError ? error.status : 0, error instanceof LLMError ? error.body : '', { cause: error });
  for (let ordinal = 0; ordinal <= delays.length; ordinal++) {
    try {
      if (options.signal?.aborted) throw abortError(options.signal);
      if (ordinal) await retryDelay(retryAfterMs ?? delays[ordinal - 1], options.signal);
    } catch (error) { throw fail(error); }
    retryAfterMs = null;
    const attempt: ProviderAttempt = {
      id: crypto.randomUUID(), generationId, ordinal, origin: structuredClone(origin), startedAt: new Date().toISOString(), elapsedMs: 0,
      requestId: null, responseId: null, outcome: 'failed', status: null, serviceTier: null, requestedServiceTier: typeof transport.body.service_tier === 'string' ? transport.body.service_tier : request.service_tier ?? null, purpose: options.diagnostic ? 'diagnostic' : 'generation', meters: unknownMeters(), charges: [],
    };
    let quotes: readonly PriceSnapshot[] = [];
    const started = Date.now();
    const controller = new AbortController();
    const signal = options.signal ? AbortSignal.any([options.signal, controller.signal]) : controller.signal;
    const streaming = Boolean(options.onEvent);
    let timer = setTimeout(() => controller.abort(new Error('Provider first response timeout')), streaming ? FIRST_RESPONSE_MS.streaming : FIRST_RESPONSE_MS.unary);
    let contentTimer: ReturnType<typeof setTimeout> | null = null;
    const touchContent = (): void => {
      if (contentTimer) clearTimeout(contentTimer);
      contentTimer = setTimeout(() => controller.abort(new Error('Provider stream content idle timeout')), CONTENT_IDLE_MS);
    };
    let committed = false;
    let characters = 0;
    let runaway = false;
    let observed = false;
    const assembly = transport.assembly();
    let reader: ReadableStreamDefaultReader<Uint8Array> | undefined;
    let sent = false;
    let finishedAt: number | null = null;
    /** The characters of output a request may produce. */
    const outputMax = (request.max_output_tokens ?? 32768) * 12;
    const diagnostics: ProviderAttempt[] = [];
    partial = null;
    const forward = (event: StreamEvent): void => {
      observed = true;
      if (carriesContent(event)) touchContent();
      if ('delta' in event && typeof event.delta === 'string') characters += event.delta.length;
      if (irreversible(event)) committed = true;
      if (!options.signal?.aborted) options.onEvent?.(event);
      if (characters > outputMax) {
        runaway = true;
        controller.abort();
        throw new LLMError('Provider exceeded the output character limit', 0, '');
      }
    };
    try {
      const headers = await transport.headers();
      if (options.signal?.aborted) throw abortError(options.signal);
      attempt.startedAt = new Date().toISOString();
      quotes = structuredClone(options.quote?.({ startedAt: attempt.startedAt, requestedServiceTier: attempt.requestedServiceTier ?? null }) ?? []);
      sent = true;
      // a redirect fails the attempt: the key headers a vendor uses besides Authorization would follow it to the new address
      const response = await fetch(transport.url, { method: 'POST', body: requestJson(transport.body), headers, signal, redirect: 'error' });
      attempt.status = response.status;
      attempt.requestId = response.headers.get('x-request-id');
      if (!response.ok) {
        const body = await response.text();
        const error = new LLMError(`LLM API ${response.status}${body.trim() ? `: ${upstreamText(body)}` : ''}`, response.status, body);
        retryAfterMs = parseRetryAfter(response.headers.get('retry-after'));
        if (!options.diagnostic && (response.status === 401 || response.status === 403) && !authRetried && await transport.refresh()) {
          authRetried = true;
          lastError = error;
          continue;
        }
        throw error;
      }
      if (streaming) {
        if (!response.body) throw new LLMError('Streaming response has no body', response.status, '');
        reader = response.body.getReader();
        const decoder = new TextDecoder();
        const frames = new EventDecoder();
        touchContent();
        stream: for (;;) {
          const chunk = await reader.read();
          clearTimeout(timer);
          timer = setTimeout(() => controller.abort(new Error('Provider stream idle timeout')), FRAME_IDLE_MS);
          if (chunk.done) break;
          for (const payload of frames.feed(decoder.decode(chunk.value, { stream: true }))) {
            if (payload === '[DONE]') break stream;
            assembly.feed(JSON.parse(payload), forward);
          }
        }
        partial = assembly.finish(forward);
        attempt.meters = assembly.meters();
        attempt.serviceTier = assembly.serviceTier();
      } else {
        const parsed = transport.parse(JSON.parse(await response.text()));
        partial = parsed.response;
        attempt.meters = parsed.meters;
        attempt.serviceTier = parsed.serviceTier;
      }
      attempt.responseId = partial.id;
      if (partial.status === 'failed') throw new LLMError(partial.error?.message ?? partial.error?.code ?? 'Response failed', 0, JSON.stringify(partial.error));
      if (partial.status !== 'completed' && partial.status !== 'incomplete') throw new LLMError(`Response has no terminal status: ${partial.status}`, 0, '');
      attempt.outcome = options.signal?.aborted ? 'discarded' : partial.status;
      transport.succeeded();
      return { response: partial, origin, attempts };
    } catch (error) {
      finishedAt = Date.now();
      if (streaming) {
        partial = assembly.snapshot();
        attempt.meters = assembly.meters();
      }
      attempt.responseId = partial?.id ?? null;
      if (options.signal?.aborted) {
        attempt.outcome = 'aborted';
        lastError = abortError(options.signal);
        break;
      }
      lastError = error;
      if (!sent || committed || runaway || error instanceof StreamErrorEvent || (!streaming && error instanceof ResponseProtocolError)) break;
      const status = error instanceof LLMError ? error.status : 0;
      if (status !== 0 && status !== 408 && status !== 429 && status < 500) break;
      if (!options.diagnostic && observed && Date.now() - started >= 20000 && !await transport.failure({
        model: request.model ?? '', role: options.role, elapsedMs: Date.now() - started, status,
        requestId: attempt.requestId, body: error instanceof LLMError ? error.body : '', message: errorText(error),
      }, values => diagnostics.push(...values))) break;
      transport.log.warn('Provider attempt failed; retrying', { ordinal, err: errorText(error) });
    } finally {
      clearTimeout(timer);
      if (contentTimer) clearTimeout(contentTimer);
      if (reader) { try { await reader.cancel(); } catch { /* The failed transport may already be closed. */ } reader.releaseLock(); }
      attempt.elapsedMs = (finishedAt ?? Date.now()) - started;
      attempt.charges = priceUsage(attempt.meters, quotes, attempt.serviceTier);
      if (sent) attempts.push(attempt);
      attempts.push(...diagnostics);
    }
  }
  throw fail(lastError);
}
