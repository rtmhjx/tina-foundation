<!-- Owner: src/providers/base.ts, src/providers/webui/hub.ts, src/providers/hub-api.ts, src/providers/name.ts, src/providers/registry.ts, src/providers/webui/settings.ts, src/providers/webui/config.ts, src/providers/openai-responses-compat/config.ts, src/providers/transport/responses-input.ts, src/providers/transport/history.ts, src/providers/llamacpp/native.ts -->

# src/providers

`ProviderModule` 实现一种模型通信协议,`ProviderInstance` 对应一个端点,
`ProviderHost` 提供实例所需的配置、密钥、资源与日志接口。Core 通过 `ProviderRegistry.bind(name)`
获取带报价与来源信息的客户端,Persona 通过 Core 调用模型。

## 文件

| 文件 | 管什么 |
|---|---|
| `base.ts` | 三个接口与 `BaseProvider`(抽象 `respond`) |
| `registry.ts` | 目录扫描发现内建模块、`registerProviderModules()` 收扩展、`removeProviderModule()` 撤下扩展、实例缓存与 `bind()` |
| `configuration.ts` | `validateSpec` / `validateEntry`:外部配置校验 |
| `pricebook.ts` | 价目定义、快照、报价合并 |
| `webui/` | provider 页的服务端:`ProviderSettings`(落盘、密钥状态、探活) |
| `openai-responses-compat/` | 内建模块:Responses 协议客户端与模型目录 |
| `llamacpp/` | 内建模块:llama-server 的 Chat 客户端、router 目录、官方 release 的下载安装与进程托管 |
| `transport/` | HTTP/SSE 引擎、Chat 与 Responses 请求转换、事件装配、计量、错误 |

## ProviderModule

`id` 必须等于目录名(扩展包里则是包声明的 id)。必填:`title`、`reasoningTiers`(空表 = 开放,
effort 收任意非空串)、`serviceTiers`、`create(name, entry, host)`。可选:`description`、`defaultBaseUrl` 与
`baseUrlSuggestions`、`effortSuggestions`、`temperatureNote`、`localize()`、`normalize()`、
`validateEntry()`、`validateModel()`、`accepts()`(多模态判定)、`config()` 与 `webUi()`
(附加配置组与面板)、`prices()`、`estimateTokens()`、`contextOverflow()`、`describe`(自描述:协议、登录方式、是否本机、输入类型,
见 [docs/extensions.md](../../docs/extensions.md)「自描述」)。

地址、密钥变量名与图像开关不归模块:框架在 `webui/config.ts` 里为每个端点声明这一组,
扩展来的模块照样有。模块自己的 `options.*` 走 `config()` 的配置组,模块的面板作为端点编辑页的段落
用 WebUI 的 schema 渲染器画同一份声明、经 `ctx.setConfig` 暂存到连接草稿——内建 llamacpp 的运行时与启动
两段走的是这条。段落顺序由 `webUi()` 的 `panels` 定:编辑页自带的四块(`webui/config.ts` 的
`connectionBlocks`)与模块自己的面板排成一列。`webUi()` 显式给空 `config` 表示这一页不另开配置页签,
声明仍参与服务端校验。启停与模型操作这类动作走面板 invoke。

`create()` 返回 `ProviderInstance`:`client`(实现 `respond`)、`listModels?`、`control?`、
`compatibilityKey?`、`start?` / `stop?`、`contextWindow?(model)`。`listModels()` 返回 `ListedModel[]`:
`id` 必有,`displayName`、`contextWindow`、`maxOutputTokens`、`inputImages` 只在上游给出时才有。

`ProviderHost` 给实例:`stateDir`(`<部署根>/providers/<端点名>/`,归实例独占)、`repoRoot`、
`resource()`、`currentEntry()`、`secret(name)`(进程环境优先,否则现读 `stateDir/.env`)、
`readBlob()`、`keepThinking()`、`log`。

## 注册与解析

内建模块由 `providers/<module>/index.ts` 的默认导出自动发现。扩展模块由启动器在 `createBot`
之前通过 `registerProviderModules()` 注册,id 重复时抛错。卸载扩展时 `removeProviderModule(id, remove)` 先撤下注册
再执行 `remove`,失败则放回原位;`ProviderHub.removeModule` 在端点表写锁内确认没有供应实例引用该模块后调用它。
撤下后 `ProviderSettings.sources()` 里该模块的 `contribute()` 返回 null,已打开面板的 `invoke` 抛错。

`ProviderRegistry.resolve(name)`:按 `entry.kind` 找模块,`normalize`,以去掉 `pricing` 与
`spec` 的条目 JSON 加端点 `.env` 的内容指纹为缓存键(改模型或价格不重建实例,密钥文件变更后
下一次解析重建),填 `stateDir` 与 `secret`。
`bind(name)` 在实例外包一层:注入 `quote`(报价快照)与 `origin`(实例、模块、模型、
`compatibilityDomain` = sha256(kind + baseUrl + `compatibilityKey()`))。Responses 历史推理仅在实例、
模块、兼容域与模型均匹配时回传。`invalidate()` 清除缓存,WebUI 保存端点后调用;`.env` 变更经缓存键在下一次解析生效。

## 配置形状

`LLMProviderEntry`:`kind`、`baseUrl`、`secret?`、`multimodal?`、`serviceTier?`、`pricing?`、
`options?`、`spec?: ModelSpec`。`ModelSpec`:`model`、`thinking`、`reasoningEffort?`、
`temperature?`、`maxTokens?`、`contextWindow?`。`providerSchemaVersion` 现在是 3。

Core 侧:`activeProviderEntry()` / `activeSpec()` 每次现读;`contextWindowOf()` 取上游探到值与
手填 `contextWindow` 的较小者;`contextFacts()` 优先用模块的 `estimateTokens` /
`contextOverflow`,没有则回落到 Core 的字符比估算。

## transport

`response-http.ts` 处理 HTTP/SSE:一次生成可包含多次请求尝试,重试间隔为 `[1s, 4s, 10s]`;超时
四档(流式首包 300s、非流式 120s、帧空闲 120s、内容空闲 300s);只对状态 0 / 408 / 429 / 5xx
重试,流内 `error` 事件不重试,响应带 `Retry-After` 时按它退避,401 / 403 先 `transport.refresh()`
一次;非 2xx 的错误消息带状态码和 `upstreamText()` 取出的上游说明;已提交不可逆增量后不再重试;输出字符超过
`max_output_tokens × 12` 时终止请求并报告超限;终态只接受 `completed` / `incomplete`,`failed` 抛
`LLMError`;每次请求尝试记录 `meters` 与 `charges`。

`GenerateOptions.onEvent` 在场即流式请求:Chat 带 `stream: true` 与 `stream_options.include_usage`,Responses 带
`stream: true`。生成与连接探测总是带它；只有适配器诊断流内失败时发的对照请求不带。流里没有用量时，该次尝试的
`meters` 各项为 null;单价非零的计量列进 `charges` 的 `missing`,金额为 null。上游不能流式时由 provider 扩展处理。

`responses-input.ts` 是原生 Responses 的无状态重放(system / developer 上提为
`instructions`;思维链按 `reasoningReplay` 以签名块或 `reasoning_text` 回传,明文形态下没有记录来源
的调用前补一项合成推理,`sendSyntheticReasoning` 为 false 时不补;来源实例、模块或兼容域与本次请求不同的 message /
function_call / function_call_output 出线时去掉可选的 `id`,`call_id` 不动,没有来源的项照带 `id`);`chat.ts` + `native-input.ts` / `history.ts` 转换 Chat Completions 请求(历史
思维链回不回传由模块定:`renderMessagesWithMedia` 的 `keepReasoning` 决定出不出线,`dropPastThinking`
把合成开头之外的每条抹空);
`response-assembly.ts` 把两种流归一成 Open Responses 的 Item 流,
`finish_reason` 的 `length` / `content_filter` 落成 `incomplete_details.reason`;
`response-meters.ts` 把两种 usage 归一成 `TokenMeters`,缺项保持 null。

线协议类型在 `src/protocol/open-responses/`(规范 2026-04-24 生成),`ResponseAccumulator`
逐事件强校验:序号递增、终态自洽、已关闭的 Item 不得再变。

## pricebook

`PriceDefinition`:`models`、`currency`、`basis`(`marginal` | `equivalent`)、`rules`、
`inputBands`、`serviceTiers`、`source`。`quotePrices()` 在同一 basis 下让实例的 `pricing` 覆盖
模块默认,快照带 sha256 id 与 `capturedAt`。计量键:`input` / `output` / `total` /
`cachedInput` / `uncachedInput` / `reasoning` 与 `detail:*`,单价按每百万 token。实际扣费在
`src/core/generation.ts` 的 `priceUsage()`,缺计量记 `amount: null`。

## 端点配置接口

`webui/hub.ts` 的 `ProviderHub` 是 WebUI 改端点的唯一入口,`hub-api.ts` 把它接到
`/api/providers`(聚合、按名读取、保存、删除、设为当前、测试、模型列表)与
`/api/provider-modules`(已注册模块)。列表保留 `kind` 没有对应模块的端点,active 与可用性
分别报告;状态帧的 `modelConnection` 带当前端点的名称、模型、模块与地址。

新名称由 `name.ts` 校验:英文字母、数字、`-` 或 `_`,首字符是字母或数字,不收空格与 Windows
设备名——名字就是 `<部署根>/providers/` 下的目录名。已在磁盘上的名字不改就继续有效。保存带
读取时的 revision(端点 `config.json` 与 `.env` 的 sha256),对不上返回 409。共享目录上的写锁
`.write-lock` 串行化各进程的写入。改名同时改目录和部署根内各 `deployment.json` 的
`activeProvider`,中途失败回滚已动过的文件和目录;还被引用的端点不能删。

保存一次校验模型、连接与模块配置,再写 `config.json` 和可选密钥;密钥进该端点的 `.env`,读取
接口不返回密钥值。写完清掉本进程的实例缓存,已绑定的请求与 fork 保持原客户端;其他进程在下次
重读共享配置时跟上。

`ProviderWebUiHost.editing` 表示这个实例来自还没保存的表单,模块据此拒绝运行时副作用,
`host.save` 把配置交回浏览器暂存。`ProviderRegistry.previewRegistry` 按一份条目造注册表,实例不进
运行实例缓存,浏览器刚输入的密钥作为覆盖值排在进程环境与端点 `.env` 之前;测试与模型列表带
`{ entry, secretValue }` 时走它。

已保存端点与表单草稿共用 `ProviderSettings.probeClient`。探测与正式生成一样带 `onEvent`,请求流式响应；
客户端消费并校验响应后，回执返回用量、费用或错误。

连接列表的 usage 包含其他部署的选用记录及运行锁状态，排除当前部署。运行状态按部署配置的 paths.data（缺省使用 Core 默认值）检查实例锁，不代表供应商正在处理请求，也不建立供应商独占锁。
