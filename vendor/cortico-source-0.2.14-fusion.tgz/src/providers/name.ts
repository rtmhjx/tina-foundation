/** New connection names are portable directory names; unchanged historical keys are exempt. */
export function validateProviderName(name: string): 'shape' | 'reserved' | null {
  if (!/^[A-Za-z0-9][A-Za-z0-9_-]*$/.test(name)) return 'shape';
  if (/^(con|prn|aux|nul|com[0-9]|lpt[0-9])$/i.test(name)) return 'reserved';
  return null;
}

/** 密钥变量名缺省时的默认名:按端点名派生,`-` 折成 `_`,与 validateEntry 的环境变量名格式一致。 */
export function defaultSecretName(name: string): string {
  return `CORTICO_KEY_${name.toUpperCase().replace(/-/g, '_')}`;
}
