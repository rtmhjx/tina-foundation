import { pick, type Language } from '../core/language.ts';
import { text as zhHant } from './strings.zh-Hant.ts';
import { text as ja } from './strings.ja.ts';
import { text as ko } from './strings.ko.ts';
import { text as fr } from './strings.fr.ts';
import { text as de } from './strings.de.ts';
import { text as es419 } from './strings.es-419.ts';
import { text as ptBR } from './strings.pt-BR.ts';
import { text as it } from './strings.it.ts';
import { text as ru } from './strings.ru.ts';

/** Validation errors that reach the WebUI as `{ error }` from the provider settings. */
const zh = {
  profileObject: '模型配置必须是对象',
  modelRequired: '模型名不能为空',
  thinkingBoolean: '推理开关必须是布尔值',
  tierUnsupported: (title: string) => `${title} 不支持该推理档位`,
  effortString: '推理强度必须是非空字符串',
  effortWithoutThinking: '思维链关闭时不能带推理强度',
  temperatureRange: 'temperature 必须在 0–2 之间',
  positiveInteger: (field: string) => `${field} 必须为正整数`,
  contextWindowAboveOutput: (window: number, output: number) =>
    `contextWindow 必须大于 maxTokens(当前 ${window} ≤ ${output})`,
  optionsObject: '原生参数必须是对象',
  kindChange: '实例不能改变 Provider 模块类型',
  baseUrlFormat: '供应地址需要不含凭据的 HTTP(S) URL',
  secretName: '密钥引用必须是环境变量名',
  multimodalBoolean: '多模态开关必须是布尔值',
  serviceTierString: '服务档必须是字符串',
  serviceTierUnsupported: (title: string, tier: string) => `${title} 不支持服务档 ${tier}`,
  pricingArray: '报价必须是数组',
  rulesArray: '报价规则必须是数组',
  ruleShape: '报价规则需要计量维度和非负单价',
  unitRequired: '计量单位不能为空',
  tokenUnit: '标准 token 计量必须使用 token 单位',
  bandsArray: '输入阶梯必须是数组',
  bandsIncreasing: '输入阶梯阈值必须严格递增且大于 0',
  modelsRequired: '报价需要明确模型名或 *',
  currencyRequired: '报价币种不能为空',
  basisValue: '报价口径必须为 marginal 或 equivalent',
  sourceRequired: '报价需要来源',
  tiersObject: '服务档报价必须是对象',
  tierNameRequired: '服务档名不能为空',
  tierRules: '服务档报价需要规则对象',
  timeWindowsUnsupported: '分时段价目由 provider 扩展在模块价目里声明,端点价目不接受 timeWindows',
  noModel: '未选模型',
  noSecret: (name: string) => `缺少密钥 ${name}`,
};
export const en: typeof zh = {
  profileObject: 'Model configuration must be an object',
  modelRequired: 'Model name cannot be empty',
  thinkingBoolean: 'Reasoning switch must be a boolean',
  tierUnsupported: (title: string) => `${title} does not support this reasoning tier`,
  effortString: 'Reasoning effort must be a non-empty string',
  effortWithoutThinking: 'Reasoning effort cannot be set while reasoning is off',
  temperatureRange: 'temperature must be between 0 and 2',
  positiveInteger: (field: string) => `${field} must be a positive integer`,
  contextWindowAboveOutput: (window: number, output: number) =>
    `contextWindow must be greater than maxTokens (now ${window} ≤ ${output})`,
  optionsObject: 'Native options must be an object',
  kindChange: 'An instance cannot change its provider module type',
  baseUrlFormat: 'Provider URL must be an HTTP(S) URL without credentials',
  secretName: 'Secret reference must be an environment variable name',
  multimodalBoolean: 'Multimodal switch must be a boolean',
  serviceTierString: 'Service tier must be a string',
  serviceTierUnsupported: (title: string, tier: string) =>
    `${title} does not support service tier ${tier}`,
  pricingArray: 'Pricing must be an array',
  rulesArray: 'Pricing rules must be an array',
  ruleShape: 'A pricing rule needs a meter and a non-negative rate',
  unitRequired: 'Unit cannot be empty',
  tokenUnit: 'Standard token meters must use the token unit',
  bandsArray: 'Input bands must be an array',
  bandsIncreasing: 'Input band thresholds must be strictly increasing and greater than 0',
  modelsRequired: 'A quote needs explicit model names or *',
  currencyRequired: 'Quote currency cannot be empty',
  basisValue: 'Quote basis must be marginal or equivalent',
  sourceRequired: 'A quote needs a source',
  tiersObject: 'Service tier pricing must be an object',
  tierNameRequired: 'Service tier name cannot be empty',
  tierRules: 'Service tier pricing needs a rules object',
  timeWindowsUnsupported: 'Time-of-day pricing is declared by a provider extension in its module quote; endpoint pricing does not accept timeWindows',
  noModel: 'No model selected',
  noSecret: (name: string) => `Missing secret ${name}`,
};
export const text = (language: Language) => pick(language, {
  zh, en, 'zh-Hant': zhHant, ja, ko, fr, de, 'es-419': es419, 'pt-BR': ptBR, it, ru,
});
