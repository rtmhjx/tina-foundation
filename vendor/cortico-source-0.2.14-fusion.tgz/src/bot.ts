/** 装配 Core、Persona、World 与 WebUI；具体 bot 的配置和行为由 BotDefinition 提供。 */
import { existsSync, mkdirSync, renameSync, statSync, unlinkSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { dirname, join } from 'node:path';
import type {
  ConfigGroup,
  CoreConfig,
  DescribeText,
  ToolDescribe,
  World,
  Logger,
  WorldLifecycleEvent,
  WorldPanelDecl,
  Persona,
  PromptDocDecl,
  ShutdownExternalCheck,
  ToolSchema,
} from './core/types.ts';
import type { LoadedConfig } from './core/config.ts';
import { coreConfigGroup } from './core/config.ts';
import { pick, resolveLanguage, type Language } from './core/language.ts';
import { botText } from './strings.ts';
import { updateJsonObject } from './config-file.ts';
import { ONBOARDING_FLAG_FILE } from './deploy.ts';
import { announceShutdown, isSupervised, requestRestart, startsPaused } from './boot.ts';
import { ExtensionManager, packageMetadata, type ExtensionSet } from './extensions.ts';
import type { ExtensionPackageJson } from './extensions/manifest.ts';
import { ExtensionMarket } from './extensions/market.ts';
import { WorldAssembly, type WorldDefinition, type WorldDeclaration, type WorldSection } from './world.ts';
import { Core, type CoreDeps, type WorldStopFailure } from './core/core.ts';
import { UndeclaredNames } from './undeclared-names.ts';
import { RESERVED_FRAME_NAMES } from './core/loop.ts';
import type { ResponseClient } from './core/generation.ts';
import { acquireInstanceLock, type InstanceLock } from './core/instance-lock.ts';
import { assembleSystemSegments, envPromptOverridePath, envPromptTemplateSource, renderWorldEnvPrompt, type EnvPromptDirs, type EnvPromptOrigin } from './core/prefix.ts';
import { aggregateUsage } from './core/cost.ts';
import { createUsageRates } from './core/usage-rates.ts';
import { DeadlineError, nowIso, withDeadline, readTextFile } from './core/util.ts';
import { closeRun } from './core/run.ts';
import { ProviderHub } from './providers/webui/hub.ts';
import { ProviderSettings } from './providers/webui/settings.ts';
import { providerModules } from './providers/registry.ts';
import { repoRoot } from './paths.ts';
import { isConfigGroup, personaConfigGroups, readGroupValues, setByPath as setConfigPath } from './core/config-schema.ts';
import type { ConfigValues, PersonaConfigGroups } from './core/config-schema.ts';
import {
  PromptRevisionConflict,
  WebApp,
  type WebUiWorldInfo,
  type ExtensionInfo,
  type WorldInfo,
  type PromptDocument,
  type OwnedStoragePart,
  type StoragePart,
  type ToolOwner,
  type WebAppPromptDeps,
} from './web/server.ts';
import type { WebUiPageSource } from './web/webui-pages.ts';
import {
  pageIdFor,
  type WebUiPageContribution,
} from './web/shared/webui-protocol.ts';

/** WebUI 访问密码的密钥名;进程环境或部署 .env 里非空时优先于 web.password。 */
export const WEB_PASSWORD_SECRET = 'CORTICO_WEB_PASSWORD';

/** 启动器使用的 bot 包装配契约。 */
export interface BotDefinition<C extends CoreConfig = CoreConfig> {
  /** WebUI 页 id `persona:<id>` 与产物键取它;仓内包的 id 与目录同名。 */
  id: string;
  /** Memory 系统的名字,作 Memory 页的标题;缺省回落到 persona.memory 的类名,再缺省是 Memory。 */
  memoryName?: string;
  /** 框架默认值与 Persona 默认值；World 默认段由 withWorlds() 补充。 */
  defaults(): C;
  /** 由 withWorlds() 注入的内建及扩展 World 定义；按 worlds.<id>.enabled 挂载。 */
  worlds?: readonly WorldDefinition<WorldSection>[];
  /** 默认启用的 World id；缺失实现时显示不可用。对象声明可附缺失原因，未声明的 World 默认关闭。 */
  declares?: readonly WorldDeclaration[];
  /** 配置已完成合并；worlds 与 Core 共用数组，激活和停用会就地更新，Persona 应在使用时读取。 */
  build(loaded: LoadedConfig<C>, worlds: World[]): BotParts<C>;
  /**
   * 自描述,给人和扩展市场看:Persona 提供的全部工具与 Memory 的形式。默认启用的 World 取 `declares`,
   * Memory 的名字取 `memoryName`;`pnpm describe:extension` 一并导出成 describe.json。
   */
  describe?: BotDescribe;
}

/** Bot 的自描述。 */
export interface BotDescribe {
  tools: readonly ToolDescribe[];
  /** Memory 是什么形式,如「工作区里的 Markdown 文件,git 记版本」。 */
  memory: { form: DescribeText };
}

export interface BotStartContext<C extends CoreConfig> {
  core: Core<C>;
  loaded: LoadedConfig<C>;
  /** WebUI 实际监听的端口;不起 WebUI 时为 null */
  port: number | null;
}

export interface BotParts<C extends CoreConfig = CoreConfig> {
  persona: Persona;
  /** 预建实例替换同 id 的定义实例，初始挂载；重启复用该实例，停用后不能通过 activate 重新挂载。 */
  worlds?: World[];
  llm?: ResponseClient;
  webUi?: WebUiContribution;
  onStart?(ctx: BotStartContext<C>): void | Promise<void>;
  onStop?(): void | Promise<void>;
}

/** bot 提供的 WebUI 声明，补充 Core 与 World 的通用页面。 */
export interface WebUiContribution {
  /** false = 完全不起 WebUI(无头运行) */
  enabled?: boolean;
  /**
   * 追加的可调配置组(Persona那组;core 与各 World 的由框架收拢)。给函数时按请求语言生成标题与说明;
   * 各语言的 id 与取值范围须相同。
   */
  configGroups?: PersonaConfigGroups;
  /** 动态下拉选项；固定选项的文案使用请求语言。 */
  configOptions?(kind: string, language: Language): Array<{ value: string; label: string }>;
  /** 合并进状态快照的实现特有字段(框架给的基础字段在前,这里覆盖) */
  status?(): Record<string, unknown>;
  /** 以 persona 作用域展示的提示词文件，框架负责读写。 */
  promptDocs?: PromptDocDecl[];
  /**
   * 非主循环 session 的额外工具 schema。
   * 每个 session 的声明方负责在此补充其工具。
   */
  extraToolSchemas?(): ToolSchema[];
  /** 需要部署配置或跨模块操作的 WebUI 页；Persona.webUi() 声明 Persona 自身的操作。 */
  webUiPages?(ctx: WebUiPageBuildContext): WebUiPageContribution[];
}

/** 装配层向 bot WebUI 声明函数提供的共享数据。 */
export interface WebUiPageBuildContext {
  /** 与 /api/storage 共用同一批对象的存储清单，文案使用请求语言。 */
  storage: readonly OwnedStoragePart[];
  /** 发起这次请求的浏览器的界面语言。 */
  language: Language;
}

/** 关机步骤；ok=false 时 detail 说明异常或超时。 */
export interface ShutdownStep {
  key: string;
  label: string;
  ok: boolean;
  elapsedMs: number;
  detail?: string;
}

/** complete 要求本地关机步骤完成且外部状态核验通过。 */
export interface ShutdownReport {
  reason: string;
  localComplete: boolean;
  complete: boolean;
  steps: ShutdownStep[];
  externalChecks: ShutdownExternalCheck[];
}

/** WebUI 请求关闭运行实例后，由宿主决定进程的退出方式。 */
export interface BotExitRequest {
  kind: 'shutdown' | 'restart';
  code: number;
  report: ShutdownReport;
}

export interface Bot<C extends CoreConfig = CoreConfig> {
  readonly providerHub?: ProviderHub;
  core: Core<C>;
  parts: BotParts<C>;
  /** World 槽位表:挂载表、未激活槽位与缺失声明。 */
  assembly: WorldAssembly;
  /** 运行中出现、不在 World 定义与 bot 定义自描述里的工具与事件。 */
  undeclared: UndeclaredNames;
  webApp: WebApp | null;
  /** 启动全部;返回 WebUI 端口(未起 WebUI=null) */
  start(): Promise<{ port: number | null }>;
  stop(): Promise<void>;
  /** 分步关机并返回结果。步骤失败或超时后继续，不调用 process.exit。 */
  shutdown(reason?: string): Promise<ShutdownReport>;
}

/**
 * 每一步超时只推进编排，不会取消外部 promise。等装卸至多 60 秒，超时后 pnpm 子进程留着跑完，
 * 回滚不再执行；`extensions` 之后的步骤合计 31 秒。
 */
const SHUTDOWN_BUDGET_MS = {
  pause: 2_000,
  extensions: 60_000,
  worlds: 22_000,
  core: 1_000,
  llm: 3_000,
  flush: 2_000,
  web: 3_000,
} as const;

/** 全部关机步骤的上限之和。 */
export const SHUTDOWN_TOTAL_MS = Object.values(SHUTDOWN_BUDGET_MS).reduce((sum, ms) => sum + ms, 0);

const fileSize = (dir: string, rel: string, noFile: string): string => {
  const p = join(dir, rel);
  if (!existsSync(p)) return noFile;
  try {
    return `${(statSync(p).size / 1024).toFixed(1)}KB`;
  } catch {
    return '?';
  }
};

function deriveStorage<C extends CoreConfig>(core: Core<C>, dataDir: string, language: Language): StoragePart[] {
  const t = botText(language);
  const size = (dir: string, rel: string): string => fileSize(dir, rel, t.noFile);
  const s = t.storage;
  return [
    {
      key: 'events',
      label: s.events.label,
      kind: 'disk',
      location: `data/runs/${core.run.id}/events.jsonl`,
      danger: true,
      note: s.events.note,
      stat: () => s.events.stat(core.store.currentCount(), core.store.latestCursor(), size(core.run.dir, 'events.jsonl')),
      clear: () => s.events.cleared(core.store.clear()),
    },
    {
      key: 'session',
      label: s.session.label,
      kind: 'disk',
      location: 'data/session-main.jsonl',
      danger: true,
      // 最后重建 session 前缀和开场，使其读取清理后的状态。
      order: 10,
      note: s.session.note,
      stat: () =>
        s.session.stat(core.session.records.length, Math.round(core.session.estTokens() / 1000), size(dataDir, 'session-main.jsonl')),
      clear: async () => {
        await core.loop.clearSession();
        return s.session.cleared;
      },
    },
    {
      key: 'runlog',
      label: s.runlog.label,
      kind: 'disk',
      location: `data/runs/${core.run.id}/log.jsonl`,
      note: s.runlog.note,
      stat: () => size(core.run.dir, 'log.jsonl'),
      clear: () => {
        core.runlog.clear();
        return s.runlog.cleared;
      },
    },
    {
      key: 'usage',
      label: s.usage.label,
      kind: 'disk',
      location: 'data/usage.jsonl',
      note: s.usage.note,
      stat: () => s.usage.stat(core.usageLog.count(), size(dataDir, 'usage.jsonl')),
      clear: () => s.usage.cleared(core.usageLog.clear()),
    },
    {
      key: 'toolcalls',
      label: s.toolcalls.label,
      kind: 'disk',
      location: `data/runs/${core.run.id}/toolcalls.jsonl`,
      note: s.toolcalls.note,
      stat: () => core.toolLog.stat(),
      clear: () => {
        core.toolLog.clear();
        return s.toolcalls.cleared;
      },
    },
    {
      key: 'state',
      label: s.state.label,
      kind: 'disk',
      location: 'data/core-state.json',
      note: s.state.note,
      stat: () =>
        s.state.stat(Object.keys(core.state.data.persona).length, core.state.data.lastTruncateAt ?? s.state.never),
      clear: () => {
        core.state.clear();
        return s.state.cleared;
      },
    },
    {
      key: 'wakes',
      label: s.wakes.label,
      kind: 'disk',
      location: 'data/timers.json',
      note: s.wakes.note,
      stat: () => s.wakes.stat(core.timers.list().length),
      clear: () => s.wakes.cleared(core.timers.clearAll()),
    },
    {
      key: 'tracker',
      label: s.tracker.label,
      kind: 'memory',
      note: s.tracker.note,
      stat: () => s.tracker.stat(core.sessions.list().length),
      clear: () => {
        core.sessions.reset();
        return s.tracker.cleared;
      },
    },
    {
      // 在 session 重建前清除积压事件。

      key: 'pending',
      label: s.pending.label,
      kind: 'memory',
      order: 9,
      note: s.pending.note,
      stat: () => s.pending.stat(core.bus.pending()),
      // 保留延迟渲染项，其回调还负责复位 World 的排队状态。
      clear: () => s.pending.cleared(core.discardPendingEvents()),
    },
    {
      key: 'media',
      label: s.media.label,
      kind: 'disk',
      location: 'data/media/',
      danger: true,
      note: s.media.note,
      stat: () => {
        const { count, bytes } = core.logBlobs.stat();
        return s.media.stat(count, `${(bytes / 1024).toFixed(1)}KB`);
      },
      clear: () => s.media.cleared(core.logBlobs.clear()),
    },
  ];
}

/**
 * 环境提示词按 World、bot 包、部署的顺序覆盖，WebUI 只写部署覆盖文件。
 * Persona 声明 deploymentPath 时写该路径，否则读写 path；扩展包中的模板只读，避免修改 pnpm store 的硬链接。
 */
function derivePrompts<C extends CoreConfig>(
  parts: BotParts<C>,
  assembly: WorldAssembly,
  contribution: WebUiContribution,
  timezone: string,
  dirs: EnvPromptDirs,
  packageReadOnly: boolean,
): WebAppPromptDeps | undefined {
  // 同 key 采用第一个声明；装配层优先于 Persona。
  // 标题与说明按请求语言读取；key 与路径必须保持一致。
  const docsOf = (language: Language) => {
    const seen = new Set<string>();
    return [
      ...(contribution.promptDocs ?? []).map((d) => ({ ...d, scope: 'persona' as const })),
      ...(parts.persona.webUi?.(language)?.promptDocs ?? []).map((d) => ({ ...d, scope: 'persona' as const })),

      ...assembly.instances()
        .flatMap((m) => (m.webUi?.(language)?.promptDocs ?? []).map((d) => ({ ...d, scope: 'world' as const, worldId: m.id }))),
    ].filter((d) => (seen.has(d.key) ? false : (seen.add(d.key), true)));
  };
  type Doc = ReturnType<typeof docsOf>[number];
  if (docsOf('zh').length === 0) return undefined;
  const docOf = (key: string, language: Language): Doc => {
    const doc = docsOf(language).find((d) => d.key === key);
    if (!doc) throw new Error(botText(language).prompts.unknown(key));
    return doc;
  };
  const revisionOf = (content: string): string => createHash('sha256').update(content).digest('hex');

  const sourceOf = (d: Doc): { readPath: string; writePath: string; origin?: EnvPromptOrigin } => {
    if (d.scope === 'world' && d.role === 'envPrompt') {
      const { path, origin } = envPromptTemplateSource(d, d.worldId, dirs);

      const writeDir = dirs.deploymentDir;
      return { readPath: path, writePath: writeDir ? envPromptOverridePath(writeDir, d.worldId) : d.path, origin };
    }
    // path 由声明方解析为当前读取源。
    if (d.deploymentPath) {
      return {
        readPath: d.path,
        writePath: d.deploymentPath,
        origin: d.path === d.deploymentPath ? 'deployment' : 'package',
      };
    }
    return { readPath: d.path, writePath: d.path };
  };

  const varValues = async (): Promise<Record<string, string>> => {
    const out: Record<string, string> = {};
    try {
      Object.assign(out, await parts.persona.promptVarValues?.({
        now: new Date(),
        timezone,
      }) ?? {});
    } catch { /* 忽略单个来源的变量读取错误。 */ }
    for (const m of assembly.instances()) {
      try {
        Object.assign(out, (await m.envPromptVars()) ?? {});
      } catch { /* 忽略单个来源的变量读取错误。 */ }
    }
    return out;
  };

  const readSource = (path: string): string => (existsSync(path) ? readTextFile(path) : '');

  const readDoc = (d: Doc, values: Record<string, string>): PromptDocument => {
    const { readPath, origin } = sourceOf(d);
    const content = readSource(readPath);
    return {
      ...(d.role ? { role: d.role } : {}),
      ...(origin ? { origin } : {}),
      ...(d.vars?.length
        ? {
            vars: d.vars.map((v) => ({
              ...v,
              ...(Object.prototype.hasOwnProperty.call(values, v.name) ? { value: values[v.name] } : {}),
            })),
          }
        : {}),
      key: d.key,
      title: d.title,
      scope: d.scope,
      description: d.description,
      content,
      revision: revisionOf(content),
    };
  };
  return {
    list: async (language) => {
      const values = await varValues();
      return docsOf(language).map((d) => readDoc(d, values));
    },
    prefix: () => assembleSystemSegments({
      persona: parts.persona,
      worlds: assembly.mounted,
      now: new Date(),
      timezone,
      dirs,
    }),
    write: (key, content, baseRevision, language) => {
      const t = botText(language).prompts;
      const doc = docOf(key, language);
      if (packageReadOnly && doc.scope === 'persona' && !doc.deploymentPath) {
        throw new Error(t.packageReadOnly(doc.title));
      }
      const { readPath, writePath, origin } = sourceOf(doc);
      if (baseRevision) {
        const cur = revisionOf(readSource(readPath));
        if (cur !== baseRevision) throw new PromptRevisionConflict(t.conflict(doc.title));
      }
      mkdirSync(dirname(writePath), { recursive: true });
      const tmp = `${writePath}.tmp-${Math.random().toString(36).slice(2, 10)}`;
      try {
        writeFileSync(tmp, content, 'utf8');
        renameSync(tmp, writePath);
      } catch (error) {
        try { if (existsSync(tmp)) unlinkSync(tmp); } catch { /* 保留原始写入错误 */ }
        throw error;
      }
      return origin ? t.savedOverride(doc.title) : t.saved(doc.title);
    },
    reset: (key, language) => {
      const t = botText(language).prompts;
      const doc = docOf(key, language);
      const { writePath, origin } = sourceOf(doc);
      if (!origin) throw new Error(t.notEnvPrompt(doc.title));
      if (origin === 'module') return t.alreadyDefault(doc.title);
      unlinkSync(writePath);
      return t.reset(doc.title);
    },
  };
}

type WorldVisibilityFacts = Pick<Core<CoreConfig>, 'worldVisibility'>;

/** WebUI 状态清单不渲染环境模板；需要环境正文的调用方使用 deriveWorldInfo。 */
export type WorldFacts =
  | Omit<WorldInfo, 'envPrompt'>
  | Extract<WebUiWorldInfo, { status: 'inactive' | 'missing' }>;

/** 挂载为 active，有实例但未挂载为 inactive，无法建立可用实例为 missing。 */
export function deriveWorldFacts(
  core: WorldVisibilityFacts,
  assembly: WorldAssembly,
  language: Language,
): WorldFacts[] {
  const { visibility, driftedWorlds } = core.worldVisibility();
  const slots: WorldFacts[] = assembly.slots.map((slot) => {
    const m = slot.instance;

    let decl;
    try {
      decl = m.webUi?.(language);
    } catch {
      decl = undefined;
    }
    const label = decl?.label ?? assembly.labelIn(slot.id, language);
    if (!slot.mounted) {
      return {
        id: slot.id,
        status: 'inactive' as const,
        label,
        declared: slot.declared,
        ...(slot.failure ? { reason: slot.failure(language) } : {}),
      };
    }
    return {
      id: m.id,
      status: 'active' as const,
      label,
      declared: slot.declared,
      workspace: `worlds/${m.id}`,
      tools: m.tools().map((t) => t.name),
      visible: visibility[m.id] !== false,
      prefixDrifted: driftedWorlds.includes(m.id),
      ...(decl?.lamps?.length ? { lamps: decl.lamps } : {}),
      ...(decl?.badges ? { badges: decl.badges } : {}),
      ...(decl?.links ? { links: decl.links } : {}),
    };
  });
  const missing: WorldFacts[] = assembly.missing.map((m) => ({
    id: m.id,
    status: 'missing' as const,
    label: assembly.labelIn(m.id, language),
    declared: m.declared ?? true,
    reason: m.reason(language),
  }));
  return [...slots, ...missing];
}

export async function deriveWorldInfo(
  core: WorldVisibilityFacts,
  assembly: WorldAssembly,
  dirs: EnvPromptDirs,
  language: Language,
): Promise<WebUiWorldInfo[]> {
  return Promise.all(deriveWorldFacts(core, assembly, language).map(async (facts) => {
    if (facts.status !== 'active') return facts;
    try {
      return { ...facts, envPrompt: (await renderWorldEnvPrompt(assembly.slot(facts.id).instance, dirs)).text };
    } catch (error) {
      return { ...facts, envPrompt: '', envPromptError: error instanceof Error ? error.message : String(error) };
    }
  }));
}

/** 内建条目的作者:框架维护者。 */
const BUILTIN_AUTHOR = 'phantivia';

/**
 * 随框架提供的 World 与 provider 在扩展页的条目:装配里不来自扩展的 World 定义与预建实例,
 * 以及不来自扩展的 provider 模块。World 的状态取本进程的装配。
 */
export function builtinExtensions(assembly: WorldAssembly, set: ExtensionSet, language: Language): ExtensionInfo[] {
  const pkg = JSON.parse(readTextFile(join(repoRoot(), 'package.json'))) as ExtensionPackageJson;
  const version = pkg.version ?? null;
  const common = {
    spec: 'builtin', version, installedVersion: version, webUiClient: false, builtin: true,
    author: BUILTIN_AUTHOR, metadata: packageMetadata(pkg, language), location: repoRoot(),
  } as const;
  const external = new Set(set.worlds.map((world) => world.id));
  const candidates = [...assembly.definitions, ...assembly.slots.filter((slot) => !slot.definition)];
  const worlds = candidates.filter((world) => !external.has(world.id)).flatMap((world): ExtensionInfo[] => {
    const slot = assembly.slots.find((item) => item.id === world.id);
    const missing = assembly.missing.find((item) => item.id === world.id);
    const base = { ...common, name: `builtin:world:${world.id}`, kind: 'world' as const, worldId: world.id, label: assembly.labelIn(world.id, language) };
    if (slot) return [{ ...base, loaded: true, state: 'loaded' }];
    if (missing) return [{ ...base, loaded: false, state: 'failed', reason: missing.reason(language) }];
    return [];
  });
  const externalProviders = new Set(set.providers.map((module) => module.id));
  const providers = providerModules.filter((module) => !externalProviders.has(module.id)).map((module): ExtensionInfo => {
    const description = module.localize?.(language).description ?? module.description;
    return {
      ...common, name: `builtin:provider:${module.id}`, kind: 'provider', worldId: module.id, label: module.localize?.(language).title ?? module.title,
      ...(description ? { description } : {}), loaded: true, state: 'loaded',
    };
  });
  return [...worlds, ...providers];
}

/**
 * 扩展条目在本进程的运行状态：World 看挂载与对 agent 是否可见，provider 看端点引用，bot 看加载状态。
 * 已卸载的条目不算生效。有实例的 World 名按 `language` 现取,外部扩展的名字因此也跟界面语言走。
 */
export function extensionRuntimeState(
  assembly: WorldAssembly,
  isWorldVisible: (id: string) => boolean,
  isProviderUsed: (id: string) => boolean,
): (item: ExtensionInfo, language: Language) => ExtensionInfo {
  return (item, language) => {
    if (item.state === 'removed' || !item.loaded) return { ...item, enabled: false };
    if (item.kind === 'world' && item.worldId) {
      const slot = assembly.slots.find((s) => s.id === item.worldId);
      const mounted = slot?.mounted ?? false;
      return {
        ...item,
        ...(slot ? { label: assembly.labelIn(slot.id, language) } : {}),
        enabled: mounted,
        ...(mounted && !isWorldVisible(item.worldId) ? { hidden: true } : {}),
      };
    }
    return { ...item, enabled: item.kind === 'provider' && item.worldId ? isProviderUsed(item.worldId) : item.loaded };
  };
}

/**
 * 存储清单在装配期固定；stat/clear 按 key 访问当前实例，以支持定义实例重建。
 */

function deriveSlotStorage(assembly: WorldAssembly, language: Language): OwnedStoragePart[] {
  return assembly.slots.flatMap((slot) =>
    (slot.instance.webUi?.(language)?.storage ?? []).map((part): OwnedStoragePart => {
      const current = (): StoragePart => {
        const found = slot.instance.webUi?.(language)?.storage?.find((p) => p.key === part.key);
        if (!found) throw new Error(botText(language).storagePartGone(slot.id, part.key));
        return found;
      };
      return { ...part, owner: `world:${slot.id}`, stat: () => current().stat(), clear: () => current().clear() };
    }),
  );
}

// 面板 id 在各页内唯一，转发时保持声明方提供的局部 id。
// WebUI 声明异常由 WebUiPageRegistry 按来源隔离。
function normalizePanelDecls(
  panels: readonly WorldPanelDecl[],
): Array<{ id: string; title: string; description?: string; getMethods?: readonly string[] }> {
  return panels.map((p) => ({
    id: p.id,
    title: p.title,
    ...(p.description ? { description: p.description } : {}),
    ...(p.getMethods ? { getMethods: [...p.getMethods] } : {}),
  }));
}

export function ioPageContribution(
  worldId: string,
  label: string,
  info: WorldFacts | undefined,
  mod: World | undefined,
  language: Language = 'zh',
): WebUiPageContribution {
  const decl = mod?.webUi?.(language);
  const declaredPanels = decl?.panels ?? [];
  const out: WebUiPageContribution = {
    id: pageIdFor('world', worldId),
    kind: 'world',
    label: decl?.label ?? label,
    availability: info?.status ?? 'inactive',
  };
  if (decl?.lamps?.length) out.lamps = decl.lamps;
  if (decl?.badges?.length) out.badges = decl.badges;
  if (declaredPanels.length) out.panels = normalizePanelDecls(declaredPanels);
  if (decl?.links?.length) out.links = decl.links;
  if (decl?.config?.length) out.config = decl.config;
  if (decl?.promptDocs?.length) out.promptDocs = decl.promptDocs;
  if (decl?.storage?.length) out.storage = decl.storage.map((p) => ({ ...p, owner: `world:${worldId}` }));
  if (info?.declared !== undefined) out.declared = info.declared;
  if (info?.status === 'missing') out.reason = info.reason;
  if (info?.status === 'active') {
    if (info.visible !== undefined) out.agentVisible = info.visible;
    if (info.prefixDrifted !== undefined) out.prefixDrifted = info.prefixDrifted;
  }
  const invoke = decl?.invoke;
  if (invoke) {
    out.invoke = (panel, method, args) =>
      invoke(panel, method, args);
  }

  const stream = decl?.stream;
  if (stream) {
    out.stream = (panel, socket) =>
      stream(panel, socket);
  }
  return out;
}

export function personaPageContribution(
  botId: string,
  label: string,
  core: Persona,
  language: Language = 'zh',
): WebUiPageContribution | null {
  const decl = core.webUi?.(language);
  if (!decl) return null;
  const declaredPanels = decl.panels ?? [];
  const out: WebUiPageContribution = {
    id: pageIdFor('persona', botId),
    kind: 'persona',
    label,
    availability: 'active',
  };
  if (decl.badges?.length) out.badges = decl.badges;
  if (declaredPanels.length) out.panels = normalizePanelDecls(declaredPanels);
  if (decl.config?.length) out.config = decl.config;
  if (decl.promptDocs?.length) out.promptDocs = decl.promptDocs;
  if (decl.storage?.length) out.storage = decl.storage.map((p) => ({ ...p, owner: 'persona' }));
  const invoke = decl.invoke;
  if (invoke) {
    out.invoke = (panel, method, args) =>
      invoke(panel, method, args);
  }
  return out;
}

/** Persona 的 memory 子声明成为 memory:<bot> 页;面板、模板与存储项三项皆空时没有这一页。invoke 与 Persona 页共用。 */
export function memoryPageContribution(
  botId: string,
  label: string,
  persona: Persona,
  language: Language = 'zh',
): WebUiPageContribution | null {
  const decl = persona.webUi?.(language)?.memory;
  if (!decl) return null;
  const panels = decl.panels ?? [];
  const promptDocs = decl.promptDocs ?? [];
  const storage = decl.storage ?? [];
  if (!panels.length && !promptDocs.length && !storage.length) return null;
  const out: WebUiPageContribution = {
    id: pageIdFor('memory', botId),
    kind: 'memory',
    label,
    availability: 'active',
  };
  if (panels.length) out.panels = normalizePanelDecls(panels);
  if (promptDocs.length) out.promptDocs = promptDocs;
  if (storage.length) out.storage = storage.map((p) => ({ ...p, owner: 'memory' }));
  const invoke = persona.webUi?.(language)?.invoke;
  if (invoke) out.invoke = (panel, method, args) => invoke(panel, method, args);
  return out;
}

/** Memory 实例的类名;没有实例或只是个普通对象时为 null。 */
function memoryClassName(persona: Persona): string | null {
  const name = persona.memory?.constructor?.name;
  return name && name !== 'Object' ? name : null;
}

/** Persona 实例的类名;只是个普通对象时为 null。 */
function personaClassName(persona: Persona): string | null {
  const name = persona.constructor?.name;
  return name && name !== 'Object' ? name : null;
}

/** 合并同 id 的 Persona 页面，按面板归属分派 invoke 和 stream；重复面板由 validateContributions 拒绝。 */
export function mergePersonaContributions(
  id: string,
  label: string,
  core: WebUiPageContribution | null,
  extras: readonly WebUiPageContribution[],
  language: Language = 'zh',
): WebUiPageContribution | null {
  const parts = [core, ...extras].filter((c): c is WebUiPageContribution => !!c);
  if (parts.length === 0) return null;
  if (parts.length === 1 && parts[0]) return parts[0];

  const out: WebUiPageContribution = {
    id,
    kind: 'persona',
    label: parts.find((p) => p.label)?.label ?? label,
    availability: 'active',
  };
  const badges = parts.flatMap((p) => p.badges ?? []);
  if (badges.length) out.badges = badges;
  const links = parts.flatMap((p) => p.links ?? []);
  if (links.length) out.links = links;
  const config = parts.flatMap((p) => p.config ?? []);
  if (config.length) out.config = config;
  const promptDocs = parts.flatMap((p) => p.promptDocs ?? []);
  if (promptDocs.length) out.promptDocs = promptDocs;
  const storage = parts.flatMap((p) => p.storage ?? []);
  if (storage.length) out.storage = storage;

  const panels = parts.flatMap((p) => p.panels ?? []);
  if (panels.length) out.panels = panels;

  const owner = new Map<string, WebUiPageContribution>();
  for (const p of parts) {
    for (const panel of p.panels ?? []) {
      if (!owner.has(panel.id)) owner.set(panel.id, p);
    }
  }
  if (parts.some((p) => p.invoke)) {
    out.invoke = async (panel, method, args) => {
      const target = owner.get(panel);
      if (!target?.invoke) throw new Error(botText(language).panelNoInvoke(panel));
      return target.invoke(panel, method, args);
    };
  }
  if (parts.some((p) => p.stream)) {
    out.stream = (panel, socket) => {
      const target = owner.get(panel);
      if (!target?.stream) throw new Error(botText(language).panelNoStream(panel));
      target.stream(panel, socket);
    };
  }
  return out;
}

export function deriveWebUiPageSources(
  core: WorldVisibilityFacts,

  /** `undeclared` 给出不在自描述里的工具与事件,标在 World 页与 Persona 页上。 */
  parts: { assembly: WorldAssembly; persona?: Persona; undeclared?: UndeclaredNames },
  /**
   * bot 标识、展示名、Memory 名与配置组;配置组归入 Persona 页面。
   * 展示名是这一台 bot 的名字(底栏头像旁边那个),Persona 页的标题另取 Persona 的类名。
   */
  bot?: { id: string; label: string; memoryName?: string; configGroups?: PersonaConfigGroups },

  extra?: (language: Language) => WebUiPageContribution[],
): () => WebUiPageSource[] {
  const { assembly } = parts;
  return () => {
    // 每次枚举按语言缓存状态，供同一批 contribute() 调用共享。
    const once = new Map<Language, Map<string, WorldFacts>>();
    const infos = (language: Language): Map<string, WorldFacts> => {
      let facts = once.get(language);
      if (!facts) {
        facts = new Map(deriveWorldFacts(core, assembly, language).map((i) => [i.id, i]));
        once.set(language, facts);
      }
      return facts;
    };
    const instances = new Map<string, World>(assembly.slots.map((s) => [s.id, s.instance]));
    const ids = [...assembly.slots.map((s) => s.id), ...assembly.missing.map((m) => m.id)];
    const sources: WebUiPageSource[] = ids.map((id) => ({
      id: pageIdFor('world', id),
      contribute: (language) => {
        const info = infos(language).get(id);
        const page = ioPageContribution(id, info?.label ?? id, info, instances.get(id), language);
        const undeclared = parts.undeclared?.of(`worlds.${id}`);
        return undeclared ? { ...page, undeclared } : page;
      },
    }));

    const persona = parts.persona;
    const selfId = bot ? pageIdFor('persona', bot.id) : null;

    const extrasByLanguage = new Map<Language, WebUiPageContribution[]>();
    const extrasOf = (language: Language): WebUiPageContribution[] => {
      let list = extrasByLanguage.get(language);
      if (!list) {
        list = extra?.(language) ?? [];
        extrasByLanguage.set(language, list);
      }
      return list;
    };
    const extras = extrasOf('zh');

    // 同 id 的贡献共用页面与构建产物。
    if (bot && selfId) {
      // Persona 页写 Persona 的名字:一台 bot 的展示名是部署给的,类名才是这一层的身份。
      const personaLabel = (persona && personaClassName(persona)) || bot.label;
      const botConfig = (language: Language): WebUiPageContribution[] => {
        const claimedGroups = [...personaConfigGroups(bot.configGroups, language)];
        return claimedGroups.length ? [{ id: selfId, kind: 'persona', label: personaLabel, config: claimedGroups }] : [];
      };
      sources.push({
        id: selfId,
        contribute: (language) => {
          const page = mergePersonaContributions(
            selfId,
            personaLabel,
            persona ? personaPageContribution(bot.id, personaLabel, persona, language) : null,
            [...extrasOf(language).filter((c) => c.id === selfId), ...botConfig(language)],
            language,
          );
          const undeclared = parts.undeclared?.of('persona');
          return page && undeclared ? { ...page, undeclared } : page;
        },
      });
      if (persona) {
        const memoryLabel = bot.memoryName ?? memoryClassName(persona) ?? 'Memory';
        sources.push({
          id: pageIdFor('memory', bot.id),
          contribute: (language) => memoryPageContribution(bot.id, memoryLabel, persona, language),
        });
      }
    }
    // 页面 id 不随语言变化；各来源异常由 registry 分别处理。

    for (const c of extras) {
      if (selfId && c.id === selfId) continue;
      sources.push({ id: c.id, contribute: (language) => extrasOf(language).find((x) => x.id === c.id) ?? c });
    }
    return sources;
  };
}

export function createBot<C extends CoreConfig>(
  loaded: LoadedConfig<C>,
  definition: BotDefinition<C>,
  /** 启动时加载的扩展集；未提供时不显示扩展页。扩展 bot 的包内模板只读。 */
  opts: {
    extensions?: ExtensionSet;
    createLoop?: CoreDeps['createLoop'];
    session?: CoreDeps['session'];
    worldLifecycle?: CoreDeps['worldLifecycle'];
    prompts?: WebAppPromptDeps;
    decoratePrompts?(original: WebAppPromptDeps): WebAppPromptDeps;
    onProvidersChanged?(): void | Promise<void>;
    onExit?(request: BotExitRequest): void | Promise<void>;
  } = {},
): Bot<C> {
  const cfg = loaded.config;
  // 环境模板允许包和部署覆盖，WebUI 仅写部署层。
  const promptDirs: EnvPromptDirs = {
    packageDir: loaded.packageDir ?? loaded.rootDir,
    deploymentDir: loaded.rootDir,
  };
  // 默认语言用于 HTML 和未指定语言的请求。

  const language = resolveLanguage(cfg.language);
  const assembly = new WorldAssembly(loaded, definition.worlds ?? [], definition.declares ?? []);
  const parts = definition.build(loaded, assembly.mounted);
  if (parts.worlds?.length) assembly.addPrebuilt(parts.worlds);
  const contribution = parts.webUi ?? {};

  const undeclared = new UndeclaredNames((area) => core.runlog.logger(area));
  const checkWorldTools = (mod: World): void => {
    const describe = assembly.slots.find((slot) => slot.instance === mod)?.definition?.describe;
    undeclared.tools(`worlds.${mod.id}`, describe?.tools, mod.tools().map((t) => t.name));
  };
  const core = new Core<C>(loaded, {
    persona: parts.persona,
    worlds: assembly.mounted,
    llm: parts.llm,
    ...(opts.createLoop ? { createLoop: opts.createLoop } : {}),
    ...(opts.session ? { session: opts.session } : {}),
    ...(opts.worldLifecycle ? { worldLifecycle: opts.worldLifecycle } : {}),
    onWorldPush: (worldId, type) => {
      const slot = assembly.slots.find((item) => item.id === worldId);
      undeclared.event(`worlds.${worldId}`, slot?.definition?.describe?.events, type);
    },
    onWorldFailed: (failure) => assembly.failed(failure),
    onWorldDetached: (world, options) => assembly.detached(world, options),
    onWorldRestored: (world) => assembly.restored(world),
  });
  undeclared.tools('persona', definition.describe?.tools, parts.persona.ownToolNames?.() ?? []);

  // 运行中读取失败的事件从主循环建前缀时发出,钩子的异常不能穿过主循环
  const notifyLifecycle = (event: WorldLifecycleEvent): void => {
    try {
      parts.persona.onWorldLifecycle?.(event);
    } catch (error) {
      core.runlog.logger('persona').warn('onWorldLifecycle 失败', { kind: event.kind, id: event.id, err: error instanceof Error ? error.message : String(error) });
    }
  };
  assembly.bind({
    mount: async (mod) => {
      await core.mountWorld(mod);
      if (assembly.mounted.includes(mod)) checkWorldTools(mod);
    },
    unmount: async (id) => { await core.unmountWorld(id); },
    lifecycle: notifyLifecycle,

    reservedToolNames: () => [...RESERVED_FRAME_NAMES, ...(parts.persona.ownToolNames?.() ?? [])],
  });
  for (const mod of assembly.mounted) checkWorldTools(mod);

  // 未激活实例也提供配置；组 id、owner 和配置键不随语言变化。
  // bot 包、World、provider 交来的形状不完整的组跳过,并记在交来方的日志名下;其余组照常列出和保存。
  const wellFormedGroups = (source: string, groups: readonly ConfigGroup[]): ConfigGroup[] => {
    const malformed = groups.filter((g) => !isConfigGroup(g));
    if (malformed.length) {
      core.runlog.logger(source).error('配置组缺 id、owner 或 schema.properties,已跳过', {
        fields: malformed.map((g) => (g && typeof g === 'object' ? Object.keys(g) : typeof g)),
      });
    }
    return groups.filter(isConfigGroup);
  };

  const configGroups = (language: Language): ConfigGroup[] => [
    coreConfigGroup(language),
    ...wellFormedGroups('persona', personaConfigGroups(contribution.configGroups, language)),
    ...assembly.instances().flatMap((m) => wellFormedGroups(`worlds.${m.id}`, m.webUi?.(language)?.config ?? [])),
  ];

  // 共享端点配置位于部署根的 providers/；activeProvider 属于当前部署。
  const providerSettings = new ProviderSettings(cfg,core.providers,join(loaded.rootDir,'config.json'),loaded.providersDir ?? join(loaded.rootDir,'providers'));
  const providerHub = new ProviderHub(cfg, core.providers, providerSettings, join(loaded.rootDir, 'config.json'), loaded.providersDir ?? join(loaded.rootDir, 'providers'));
  const unsubscribeProviders = opts.onProvidersChanged
    ? providerHub.onChange(() => opts.onProvidersChanged?.())
    : () => {};
  const allConfigGroups = (language: Language) => [...configGroups(language),...wellFormedGroups('provider', providerSettings.groups(language))];
  const llmManagers = new Map<string,{stop():Promise<unknown>}>([['providers',{stop:()=>core.providers.stopAll()}]]);

  let webApp: WebApp | null = null;
  const extensions = opts.extensions ? new ExtensionManager(loaded.repoRoot ?? loaded.rootDir, opts.extensions, {
    builtins: (language) => builtinExtensions(assembly, opts.extensions!, language),
    decorate: extensionRuntimeState(assembly, (id) => core.isWorldVisible(id),
      (id) => Object.values(loaded.config.providers).some((entry) => entry.kind === id)),
    removeWorld: (id, remove) => assembly.removeDefinition(id, remove),
    removeProvider: (id, remove) => providerHub.removeModule(id, remove),
  }) : undefined;

  /** WebUI 与启动器共用一次关机操作，重复调用返回同一 Promise。 */
  let shutdownOnce: Promise<ShutdownReport> | null = null;
  let coreStopOnce: Promise<void> | null = null;
  const stopCore = (): Promise<void> => {
    coreStopOnce ??= (async () => {
      try { await parts.onStop?.(); }
      finally { unsubscribeProviders(); }
    })();
    return coreStopOnce;
  };
  // start() 在启动 WebUI、Provider 和 World 之前获取单实例锁。
  let instanceLock: InstanceLock | null = null;

  const beginShutdown = (
    reason: string,
    shutdownOptions: { closeWeb: boolean; exit: boolean; kind?: 'shutdown' | 'restart'; language?: Language },
  ): Promise<ShutdownReport> => {
    shutdownOnce ??= runShutdown({
      reason,
      core,
      extensions,
      worlds: () => [...assembly.mounted],
      stopCore,
      llmManagers,
      webApp: shutdownOptions.closeWeb ? webApp : null,
      log: core.runlog.logger('shutdown'),
      language: shutdownOptions.language ?? language,
    }).then((report) => {
      instanceLock?.release();
      instanceLock = null;
      if (shutdownOptions.exit) {
        // 先发送关机结果，再关闭 WebUI 并退出进程。
        setTimeout(() => {
          void Promise.resolve().then(() => webApp?.stop()).then(async () => {
            const code = report.complete ? 0 : 1;
            if (opts.onExit) await opts.onExit({ kind: shutdownOptions.kind ?? 'shutdown', code, report });
            else process.exit(code);
          }).catch(() => {
            core.runlog.logger('shutdown').error('Host exit operation failed.');
            if (!opts.onExit) process.exit(1);
          });
        }, 300);
      }
      return report;
    }).finally(unsubscribeProviders);
    return shutdownOnce;
  };

  if (contribution.enabled !== false) {
    const startedAt = new Date().toISOString();
    const originalPrompts = derivePrompts(parts, assembly, contribution, cfg.timezone, promptDirs, opts.extensions?.bot !== undefined);
    const prompts = opts.decoratePrompts
      ? opts.decoratePrompts(originalPrompts ?? {
        list: () => [],
        write: () => { throw new Error('Unknown prompt document.'); },
      })
      : opts.prompts ?? originalPrompts;
    /**
     * 可清除存储清单在装配期生成一次，/api/storage 与 bot 的 webUiPages 共用这些对象;归属按来源盖章。
     * 贡献方须在 webUi().storage 中声明全部项目；stat 和 clear 可延迟执行，子进程代理也须在装配期提供完整声明。
     */
    const webUiStorage = (language: Language): OwnedStoragePart[] => {
      const decl = parts.persona.webUi?.(language);
      return [
        ...deriveStorage(core, loaded.dataDir, language).map((p): OwnedStoragePart => ({ ...p, owner: 'core' })),
        ...(decl?.storage ?? []).map((p): OwnedStoragePart => ({ ...p, owner: 'persona' })),
        ...(decl?.memory?.storage ?? []).map((p): OwnedStoragePart => ({ ...p, owner: 'memory' })),
        ...deriveSlotStorage(assembly, language),
      ];
    };
    const liveRates = createUsageRates();
    webApp = new WebApp({
      store: core.store,
      memoryDir: loaded.memoryDir,
      dataDir: loaded.dataDir,
      botDir: loaded.rootDir,
      blob: (handle) => core.resolveBlob(handle),
      language,
      ...(cfg.web.host ? { host: cfg.web.host } : {}),
      allowedHosts: cfg.web.allowedHosts ?? [],
      password: loaded.secret(WEB_PASSWORD_SECRET) || (cfg.web.password ?? ''),
      defaultScheme: cfg.web.theme,
      sessions: core.sessions,
      storage: webUiStorage,
      usage: {
        aggregate: async (opts) => {
          const { rates, sources } = await liveRates.resolve();
          return { ...aggregateUsage(core.usageLog.readAll(), { ...opts, timezone: core.config.timezone, rates }), rateSources: sources };
        },
        status: () => core.usageLog.status(),
      },
      config: {
        groups: (language) => allConfigGroups(language).map((group) => ({ group, values: group.owner.startsWith('provider:') ? providerSettings.values(group.id, language) : readGroupValues(cfg, group) })),
        set: (groupId: string, values: ConfigValues, language) => {
          const group = allConfigGroups(language).find((g) => g.id === groupId);
          if (group?.owner.startsWith('provider:')) return providerSettings.setConfig(groupId,values,language);
          if (!group) return botText(language).config.unknownGroup(groupId);
          const root = cfg as unknown as Record<string, unknown>;
          for (const [path, v] of Object.entries(values)) setConfigPath(root, path, v);
          return botText(language).config.updated(group.schema.title, persistConfig(loaded, values));
        },

        options: (kind, language) => {
          const own = contribution.configOptions?.(kind, language);
          if (own?.length) return own;
          for (const def of assembly.definitions) {
            const opts = def.configOptions?.(kind, language);
            if (opts?.length) return opts;
          }
          return [];
        },
      },
      worlds: async (language) => deriveWorldInfo(core, assembly, promptDirs, language),

      webUiPageSources: () => [...deriveWebUiPageSources(
        core,
        { assembly, persona: parts.persona, undeclared },
        {
          id: definition.id,
          label: cfg.displayName || definition.id,
          ...(definition.memoryName ? { memoryName: definition.memoryName } : {}),

          ...(contribution.configGroups ? { configGroups: contribution.configGroups } : {}),
        },
        contribution.webUiPages
          ? (language) => contribution.webUiPages!({ storage: webUiStorage(language), language })
          : undefined,
      )(),...providerSettings.sources()],
      providers: providerHub,
      worldVisibility: {
        state: () => core.worldVisibility(),
        set: (id, visible, language) => {
          core.setWorldVisible(id, visible);
          notifyLifecycle({ kind: 'visibility', id, label: assembly.labelOf(id) ?? id, visible });
          const t = botText(language).visibility;
          const label = assembly.labelIn(id, language);
          return visible ? t.shown(label) : t.hidden(label);
        },
      },
      sessionControl: {
        reloadPrefix: async (language) => {
          await core.loop.reloadSystemPrefix();
          if (prompts?.application === 'next-turn') return pick(language, {
            zh: '已保存，下次组装时生效。',
            en: 'Saved; takes effect at the next assembly.',
          });
          return botText(language).visibility.prefixReloaded(Math.max(0, core.session.records.length - 1));
        },
      },
      run: {
        pause: () => core.bus.setPaused(true),
        resume: () => core.bus.setPaused(false),
        isPaused: () => core.bus.isPaused(),

        shutdown: (language) => beginShutdown('WebUI 关机键', { closeWeb: false, exit: true, language }),
    // 重启请求先于关机写入，供监督进程在子进程退出后读取。
        restart: (language) => {
          requestRestart(loaded.dataDir);
          return beginShutdown('WebUI 重启键', { closeWeb: false, exit: true, kind: 'restart', language });
        },
        supervised: isSupervised(),
        startsPaused: startsPaused(),
      },
      onboarding: {
        dismiss: () => { try { unlinkSync(join(loaded.rootDir, ONBOARDING_FLAG_FILE)); } catch { /* 已经删过 */ } },
      },
      ...(extensions ? { extensions, market: new ExtensionMarket({ dir: opts.extensions!.dir, log: core.runlog.logger('market') }) } : {}),
      debug: {
        sessionMessages: () => core.session.records,
        sessionHead: () => core.loop.sessionHead(),
        onSessionAppend: (cb) => core.session.onAppend(cb),
        onSessionReset: (cb) => core.session.onReset(cb),
        onStatusChange: (cb) => core.bus.onDeliveryStateChange(cb),
        onEvent: (cb) => core.store.onAppend(cb),
        onRunlog: (cb) => core.runlog.onWrite(cb),
        onRunPhase: (cb) => core.loop.onRunPhase(cb),
        runId: () => core.run.id,
        toolSchemas: () => core.loop.getToolSchemas(),
        activeEndpoint: () => {
          const entry = cfg.providers[cfg.activeProvider];
          if (!entry) return null;
          const spec = entry.spec;
          // 只取 ModelSpec 的已知字段;值为 undefined 的键写出 JSON 时省略。
          return { name: cfg.activeProvider, kind: entry.kind, spec: spec ? {
            model: spec.model, thinking: spec.thinking, reasoningEffort: spec.reasoningEffort,
            temperature: spec.temperature, maxTokens: spec.maxTokens, contextWindow: spec.contextWindow,
          } : null };
        },
      },
      toolSchemas: {
        list: (language) => {

          const byWorld = new Map<string, ToolOwner>();
          for (const m of assembly.mounted) {
            const owner: ToolOwner = { kind: 'world', id: m.id, label: assembly.labelIn(m.id, language) };
            for (const t of m.tools()) byWorld.set(t.name, owner);
          }
          const extras = (contribution.extraToolSchemas?.() ?? []).map((s) => ({ ...s, tags: [] }));
          const byName = new Map<string, ToolSchema & { owner: ToolOwner }>();
          for (const s of [...core.loop.getToolSchemas(), ...extras]) {
            if (byName.has(s.name)) continue;
            const owner = byWorld.get(s.name) ?? { kind: 'persona' as const };
            byName.set(s.name, {
              name: s.name, description: s.description, parameters: s.parameters, owner,
            });
          }
          return [...byName.values()];
        },
      },
      getStatus: () => ({
        displayName: cfg.displayName,
        modelConnection: providerHub.current(language),
        startedAt,
        loop: core.loop.getStatus(),
        latestEventCursor: core.store.latestCursor(),
        onboardingPending: existsSync(join(loaded.rootDir, ONBOARDING_FLAG_FILE)),
        ...(contribution.status?.() ?? {}),
      }),
      log: core.runlog.logger('webui'),
      prompts,

      worldActivation: {
        set: (id, enabled, language) => (enabled ? assembly.activate(id, language) : assembly.deactivate(id, language)),
        restart: (id, language) => assembly.restart(id, language),
      },
    });
  }

  const app = webApp;
  return {
    core,
    parts,
    assembly,
    providerHub,
    undeclared,
    webApp,
    async start() {
      instanceLock ??= acquireInstanceLock(loaded.dataDir, {
        force: process.argv.includes('--force-second-instance'),
        log: core.runlog.logger('boot'),
      });

      const port = app ? await app.start(cfg.web.port) : null;
      // 启动 Provider 不等待健康检查完成；健康轮询由托管器执行。

      const orphans = Object.entries(cfg.providers).filter(([, entry]) => !providerModules.some((m) => m.id === entry.kind)).map(([name, entry]) => `${name}(kind=${entry.kind})`);
      if (orphans.length) core.runlog.logger('provider').warn('端点条目没有对应的 Provider 模块,不可用', { orphans });
      if (cfg.activeProvider && cfg.providers[cfg.activeProvider]) void core.providers.start(cfg.activeProvider).catch(error=>core.runlog.logger('provider').error('Provider 启动失败',{error:String(error)}));
      await parts.onStart?.({ core, loaded, port });
      for (const failure of await core.start()) assembly.startFailed(failure.worldId, failure.detail);
      app?.markReady();
      return { port };
    },
    async stop() {
      try {
        if (extensions) {
          await withDeadline(extensions.close(), SHUTDOWN_BUDGET_MS.extensions, 'extensions')
            .catch(() => core.runlog.logger('shutdown').warn('扩展装卸没在时限内结束，照常停止'));
        }
        await core.stop();
        await stopCore();
        await Promise.all([...llmManagers.values()].map((m) => m.stop()));
        if (app) await app.stop();
        instanceLock?.release();
        instanceLock = null;
      } finally {
        unsubscribeProviders();
      }
    },
    shutdown: (reason?: string) =>
      beginShutdown(reason ?? '外部请求', { closeWeb: true, exit: false }),
  };
}

/** 按序执行关机步骤并记录结果；失败或超时后继续下一步。 */
async function runShutdown<C extends CoreConfig>(ctx: {
  reason: string;
  core: Core<C>;
  extensions?: ExtensionManager;
  /** 停止 World 那一步开始时取的挂载表快照 */
  worlds: () => readonly World[];
  stopCore: () => Promise<void>;
  llmManagers: Map<string, {stop():Promise<unknown>}>;
  webApp: WebApp | null;
  log: Logger;
  /** 步骤名和总结使用 WebUI 请求语言。 */
  language: Language;
}): Promise<ShutdownReport> {
  const t = botText(ctx.language).shutdown;
  const steps: ShutdownStep[] = [];
  let externalChecks: ShutdownExternalCheck[] = [];
  let modulesSettled = false;
  let moduleFailures: WorldStopFailure[] = [];
  const run = async (
    key: string,
    label: string,
    budgetMs: number,
    work: () => Promise<unknown> | unknown,
  ): Promise<void> => {
    const t0 = Date.now();
    try {
      await withDeadline(Promise.resolve().then(work), budgetMs, label);
      steps.push({ key, label, ok: true, elapsedMs: Date.now() - t0 });
      ctx.log.info(`关机 ✓ ${label}`, { elapsedMs: Date.now() - t0 });
    } catch (err) {
      const detail = err instanceof DeadlineError && err.what === label ? t.stepTimedOut(Math.round(err.ms / 1000))
        : err instanceof Error ? err.message : String(err);
      steps.push({ key, label, ok: false, elapsedMs: Date.now() - t0, detail });
      ctx.log.warn(`关机步骤失败: ${label}`, { detail });
    }
  };

  ctx.log.warn(`开始关机(${ctx.reason})`);
  announceShutdown('waiting-extensions');
  await run('pause', t.pause, SHUTDOWN_BUDGET_MS.pause, () => {
    ctx.core.bus.setPaused(true);
  });
  const extensions = ctx.extensions;
  if (extensions) await run('extensions', t.extensions, SHUTDOWN_BUDGET_MS.extensions, () => extensions.close());
  announceShutdown('stopping');
  const worlds = ctx.worlds();
  await run('worlds', t.worlds, SHUTDOWN_BUDGET_MS.worlds, async () => {
    moduleFailures = await ctx.core.stop();
    modulesSettled = true;
    if (moduleFailures.length > 0) {
      throw new Error(moduleFailures.map((failure) => `${failure.worldId}:${failure.detail}`).join('；'));
    }
  });
  await run('core', t.core, SHUTDOWN_BUDGET_MS.core, ctx.stopCore);
  externalChecks = worlds.flatMap((module) => {
    if (!module.shutdownVerification) return [];
    const stopFailure = !modulesSettled
      ? t.modulesTimedOut
      : moduleFailures.find((failure) => failure.worldId === module.id)?.detail;
    if (stopFailure) {
      return [{
        key: `${module.id}.shutdown-verification`,
        label: t.externalState(module.id),
        status: 'unknown' as const,
        detail: t.stopIncomplete(stopFailure),
        manualAction: t.manualCheck,
      }];
    }
    try {
      return module.shutdownVerification(ctx.language).map((check) => ({ ...check }));
    } catch (error) {
      return [{
        key: `${module.id}.shutdown-verification`,
        label: t.externalState(module.id),
        status: 'unknown' as const,
        detail: t.cacheReadFailed(error instanceof Error ? error.message : String(error)),
        manualAction: t.manualCheck,
      }];
    }
  });
  await run('llm', t.llm, SHUTDOWN_BUDGET_MS.llm, () =>
    Promise.all([...ctx.llmManagers.values()].map((m) => m.stop())));
  await run('flush', t.flush, SHUTDOWN_BUDGET_MS.flush, () => {
    ctx.core.state.save();
  });
  const app = ctx.webApp;
  if (app) await run('web', t.web, SHUTDOWN_BUDGET_MS.web, () => app.stop());

  const localComplete = steps.every((s) => s.ok);
  const externalComplete = externalChecks.every((check) => check.status === 'verified-ended');
  const complete = localComplete && externalComplete;
  for (const check of externalChecks) {
    if (check.status === 'verified-ended') continue;
    ctx.log.error(`[P0] 外部状态未确认结束:${check.label}`, {
      status: check.status,
      detail: check.detail,
      manualAction: check.manualAction,
    });
  }

  const unverified = externalChecks.filter((check) => check.status !== 'verified-ended');
  const summary = !localComplete
    ? t.summarySkipped
    : complete
      ? t.summaryComplete
      : t.summaryUnverified(unverified.map((check) => `${check.label}=${check.status}`));
  ctx.log.emit('warn', summary, {
    event: 'shutdown-summary',
    data: {
      steps: steps.map((s) => `${s.label}=${s.ok ? 'ok' : s.detail}`),
      externalChecks: externalChecks.map((check) => `${check.label}=${check.status}`),
    },
  });
  const indexError = closeRun(ctx.core.run, {
    endedAt: nowIso(ctx.core.config.timezone),
    lastCursor: ctx.core.store.latestCursor(),
    complete,
    reason: ctx.reason,
  });
  if (indexError) ctx.log.emit('error', '关机记录没写进 runs/index.jsonl', { event: 'run-index', data: { error: indexError } });
  return { reason: ctx.reason, localComplete, complete, steps, externalChecks };
}

function persistConfig<C extends CoreConfig>(loaded: LoadedConfig<C>, values: ConfigValues): string {
  const cfgPath = join(loaded.rootDir, 'config.json');
  updateJsonObject(cfgPath, (raw) => {
    for (const [path, v] of Object.entries(values)) setConfigPath(raw, path, v);
  });
  return 'config.json';
}
