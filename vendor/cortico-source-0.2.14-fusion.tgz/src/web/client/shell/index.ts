/**
 * WebUI 外壳管理左栏导航和品牌区域；host 与 feature 管理右侧内容。
 * 框架页来自 FrameworkFeature[]，贡献方的页来自 manifest；只展示可用 feature 与 availability 为 active 的页，不内置具体 World 或 bot 名称。
 * 外壳不探测整站可达性，单个接口失败不代表整站状态。DOM 复用 WebUi 与现存样式，窄屏折叠交给 CSS。
 */

import { get, post, setConfig } from '../core/api.ts';
import { buildHash, type Route, type Router } from '../core/router.ts';
import { featureAvailable, type FrameworkFeature } from '../features/feature.ts';
import { PROVIDER_ROUTE } from '../webui-pages/host.ts';
import { icon, wordmark, type WebUiIconName } from '../ui/icons.ts';
import { lampRow, paintLamps } from '../ui/lamp.ts';
import type { WebUi } from '../../shared/client-panel.ts';
import type { WebUiLamp, WebUiPageManifest } from '../../shared/webui-protocol.ts';
import { createAvatarControl } from './avatar.ts';
import { S } from './strings.ts';
import { prefersStill, steadiest } from '../core/motion.ts';
import { inNavOrder, navHidden, NAV_HIDDEN_EVENT } from '../core/world-nav.ts';
import { notice } from '../ui/index.ts';
import { createPersonaSwitch } from '../ui/persona-switch.ts';

const NATIVE_ENGINE_PAGE_ID = 'world:native-engine';

const DEFAULT_BRAND = 'bot';
const FRAMEWORK_NAME = 'Cortico';

const GROUP_PERSONAS = S.groupPersonas;
const GROUP_WORLDS = S.groupWorlds;



export interface ShellDeps {
  doc: Document;
  /** UI 原语。DOM 只经它造，外壳不手搓 class。 */
  ui: WebUi;
  /** 跳转经它——`location.hash` 只有 router 能写。 */
  router: Router;
  /** WebUI 自己的页面。顺序即左栏顺序。 */
  features?: readonly FrameworkFeature[];
  /** 框架级表面的挂载情况。晚到就先传空，之后 `setCapabilities` 补。 */
  capabilities?: Record<string, boolean>;
  /** WebUI 页清单（`/api/webui/manifest`）。晚到就之后 `setPages` 补。 */
  pages?: readonly WebUiPageManifest[];
  /** 外壳的生命周期。abort 等同于 `dispose()`。 */
  signal?: AbortSignal;
  onError?(err: unknown): void;
}

export interface WebUiShell {
  /** 整个左栏（`#rail`）。调用方把它插进 `body` 的最前面。 */
  readonly el: HTMLElement;
  /** 当前路由变了。驱动高亮，不做别的。 */
  setRoute(route: Route): void;
  /** 展示名。空值退回中性缺省。 */
  setBrand(name: string | null | undefined): void;
  /** 能力清单到齐/变了，重排框架页那一段。 */
  setCapabilities(capabilities: Record<string, boolean>): void;
  /** manifest 到齐/变了，重排贡献方那一段。 */
  setPages(pages: readonly WebUiPageManifest[]): void;
  /**
   * 灯的新读数（`/api/webui/lamps` 的一拍）。只改灯，不碰导航结构——
   * 这是每秒两次的调用，重排一次 DOM 就是每秒两次重排。
   */
  setLamps(lamps: Record<string, WebUiLamp[]>): void;
  /** 后台推送的运行状态；所有路由共用，不能只相信本地按钮的回包。 */
  setRunStatus(status: unknown): void;
  dispose(): void;
}

/**
 * 一条导航项。`segments` 既用来跳转，也用来判高亮；`lamp` 是那颗灯的节点
 * （灯变了只改它的 class 与 title，不重建导航——那是每秒两次的操作）。
 */
interface NavEntry {
  el: HTMLElement;
  segments: readonly string[];
  /** 贡献方那一行才有：灯按这个 id 对号入座。 */
  pageId?: string;
  /** 那一排灯的容器（灯变了只改它，不重建导航）。 */
  lamps?: HTMLSpanElement;
}

/**
 * 这一项是不是当前所在处。判据是**前缀匹配**：框架页只有一段（`['usage']`），
 * 贡献方的页有两段（`['provider','world:sample']`），同一条规则两边都成立，
 * 而且页内子页签（第三段）变了不会让高亮掉下来。
 */
function matches(entry: NavEntry, route: Route | null): boolean {
  if (!route) return false;
  return entry.segments.every((s, i) => route.segments[i] === s);
}

export function createShell(deps: ShellDeps): WebUiShell {
  const { doc, ui, router } = deps;

  /** 外壳自己的账本。`dispose()` 与传进来的 signal 都收敛到这里。 */
  const life = new AbortController();
  const signal = life.signal;
  if (deps.signal) {
    if (deps.signal.aborted) life.abort();
    else deps.signal.addEventListener('abort', () => life.abort(), { once: true, signal });
  }

  const onError = deps.onError ?? ((): void => {});

  const features: readonly FrameworkFeature[] = deps.features ?? [];
  let capabilities: Record<string, boolean> = deps.capabilities ?? {};
  let webUiPages: readonly WebUiPageManifest[] = deps.pages ?? [];
  let route: Route | null = null;
  let entries: NavEntry[] = [];
  /**
   * 灯的当茬读数。`setLamps` 写它，导航重排时再照它把灯补回去——否则一次
   * `setPages` 会让所有灯退回 manifest 那一帧的旧值。
   */
  let lamps: Record<string, WebUiLamp[]> = {};
  /**
   * 每次重排换一茬监听。挂在外壳总 signal 上的话，反复 `setPages` 会在
   * 已经摘掉的节点上攒下一堆永不触发、也永不回收的监听。
   */
  let navLife: AbortController | null = null;
  // 外壳一停,当茬导航的监听跟着停(`dispose()` 之外,传进来的 signal 也走这条路)。
  signal.addEventListener('abort', () => navLife?.abort(), { once: true });

  // ---- 骨架 -------------------------------------------------------------

  const el = ui.h('div');
  el.id = 'rail';

  // 左上角是框架字标。这个 bot 叫什么写在底栏头像旁边——那才是这一台的名字。
  const brand = ui.h('div', 'brand');
  const mark = wordmark(doc);
  mark.removeAttribute('aria-hidden');
  mark.setAttribute('role', 'img');
  mark.setAttribute('aria-label', FRAMEWORK_NAME);
  brand.appendChild(mark);

  const nav = ui.h('nav', 'stack');
  nav.setAttribute('aria-label', S.navAria);

  const foot = ui.h('div', 'railfoot');
  const avatar = createAvatarControl({ doc, ui, signal, onError });
  const botName = ui.h('button', 'rail-name');
  botName.type = 'button';
  // 名字自己是按钮(点了就地改名);铅笔只在悬停时露出来,不占额外宽度。
  const botNameText = ui.h('span', 'rail-name-text', DEFAULT_BRAND);
  const botNameEdit = ui.h('span', 'rail-name-edit');
  botNameEdit.setAttribute('aria-hidden', 'true');
  botNameEdit.appendChild(icon(doc, 'pencil'));
  botName.append(botNameText, botNameEdit);
  // 暂停键的 aria-label 已说明运行状态，读屏跳过这行。
  const runState = ui.h('span', 'rail-runstate');
  runState.setAttribute('aria-hidden', 'true');
  const ident = ui.h('div', 'rail-ident');
  ident.append(botName, runState);
  const who = ui.h('div', 'rail-who');
  who.append(avatar.el, ident);
  const footActions = ui.h('div', 'rail-actions');
  const runButton = ui.h('button', 'rail-action rail-run');
  runButton.type = 'button';
  const shutdownButton = ui.h('button', 'rail-action rail-shutdown');
  shutdownButton.type = 'button';
  shutdownButton.appendChild(icon(doc, 'power'));
  const settingsButton = ui.h('button', 'rail-action');
  settingsButton.type = 'button';
  settingsButton.setAttribute('aria-label', S.settingsAria);
  settingsButton.title = S.settingsTitle;
  settingsButton.appendChild(icon(doc, 'settings'));
  footActions.append(runButton, settingsButton, shutdownButton);
  foot.append(who, footActions);

  let paused = false;
  let runStatusRevision = 0;
  let runPending = false;
  const renderRun = (): void => {
    const available = capabilities.run === true;
    runButton.disabled = !available || runPending;
    runButton.replaceChildren(icon(doc, paused ? 'play' : 'pause'));
    runButton.setAttribute('aria-label', paused ? S.runResume : S.runPause);
    runButton.title = available ? (paused ? S.runResume : S.runPause) : S.runUnavailable;
    runButton.classList.toggle('paused', paused);
    runState.textContent = paused ? S.runStatePaused : S.runStateRunning;
    runState.classList.toggle('paused', paused);
    runState.hidden = !available;
  };
  renderRun();

  const setRunStatus = (status: unknown): void => {
    if (signal.aborted || !status || typeof status !== 'object') return;
    const loop = (status as { loop?: { paused?: unknown } }).loop;
    if (typeof loop?.paused !== 'boolean') return;
    runStatusRevision++;
    paused = loop.paused;
    renderRun();
  };

  /** 关机请求的锁，等待请求完成后释放。 */
  let shuttingDown = false;
  const renderPower = (): void => {
    const canShutdown = capabilities.shutdown === true;
    shutdownButton.hidden = !canShutdown;
    shutdownButton.disabled = !canShutdown || shuttingDown;
    shutdownButton.setAttribute('aria-label', S.shutdownAria);
    shutdownButton.title = shuttingDown ? S.finishing : S.shutdownTitle;
  };
  renderPower();

  const powerAction = async (): Promise<void> => {
    if (shuttingDown) return;
    if (capabilities.shutdown !== true) return;
    const first = await ui.confirm({
      title: S.confirmShutdownTitle,
      body: S.shutdownBody,
      danger: true,
    });
    if (!first || signal.aborted) return;
    const second = await ui.confirm({
      title: S.confirmShutdownAgainTitle,
      body: S.confirmShutdownAgainBody,
      danger: true,
    });
    if (!second || signal.aborted) return;
    shuttingDown = true;
    renderPower();
    const hold = ui.toast(S.finishingToast);
    try {
      const out = await post<{
        ok?: boolean; localComplete?: boolean; result?: string; error?: string;
        steps?: Array<{ label: string; ok: boolean; elapsedMs: number; detail?: string }>;
        externalChecks?: Array<{ status: 'verified-ended' | 'still-live' | 'unknown' }>;
      }>('/api/run/shutdown', undefined, { signal });
      if (out?.error) throw new Error(out.error);
      const steps = out?.steps ?? [];
      const localComplete = out?.localComplete ?? steps.every((step) => step.ok);
      const externalUnverified = (out?.externalChecks ?? [])
        .some((check) => check.status !== 'verified-ended');
      const lines = steps.map((s) =>
        `${s.ok ? '✓' : '✗'} ${s.label} · ${(s.elapsedMs / 1000).toFixed(1)}s${s.ok ? '' : ` — ${s.detail ?? S.stepIncomplete}`}`);
      void notice(ui, {
        title: !localComplete
          ? S.resultLocalIncomplete
          : externalUnverified
            ? S.resultExternalUnverified
            : out?.ok === false ? S.resultUnverified : S.doneShutdown,
        body: [out?.result ?? S.resultDefault, '', ...lines].join('\n'),
      });
    } catch (err) {
      if ((err as { name?: string } | null)?.name === 'AbortError') return;
      // 连接在收尾途中断了是**预期之一**:进程退出得比回执快时就会这样。
      // 所以不说"失败",只说不知道 —— 逐步明细在 runlog 的 shutdown 条目里。
      onError(err);
      ui.toast(S.noReceipt(String((err as Error)?.message ?? err)), 'bad');
    } finally {
      hold.dispose();
      shuttingDown = false;
      renderPower();
    }
  };
  shutdownButton.addEventListener('click', () => { void powerAction(); }, { signal });

  runButton.addEventListener('click', () => {
    if (runPending || capabilities.run !== true) return;
    runPending = true;
    renderRun();
    void post<{ paused?: boolean; result?: string }>(
      paused ? '/api/run/resume' : '/api/run/pause',
      undefined,
      { signal },
    ).then((out) => {
      setRunStatus({ loop: { paused: out.paused === true } });
      if (out.result) ui.toast(out.result);
    }).catch((err: unknown) => {
      if ((err as { name?: string } | null)?.name === 'AbortError') return;
      onError(err);
      ui.toast(err instanceof Error ? err.message : String(err), 'bad');
    }).finally(() => {
      runPending = false;
      renderRun();
    });
  }, { signal });
  settingsButton.addEventListener('click', () => {
    try { router.navigate(['settings']); } catch (err) { onError(err); }
  }, { signal });

  // ── Persona Switcher (rail variant, between brand and nav) ─────────────
  const personaSwitch = createPersonaSwitch({
    variant: 'rail',
    doc,
    ui,
    signal,
    onError,
  });
  // Enable once we know world:native-engine is in the manifest
  personaSwitch.setEnabled((deps.pages ?? []).some(p => p.id === NATIVE_ENGINE_PAGE_ID));

  el.append(brand, personaSwitch.el, nav, foot);

  get<{ currentVersion: string; update?: { version: string; url: string } }>('/api/framework/release', { signal })
    .then((status) => {
      if (signal.aborted || !status?.update) return;
      const hint = ui.h('a', 'release-hint', S.releaseUpdate(status.update.version, status.currentVersion));
      hint.href = status.update.url;
      hint.target = '_blank';
      hint.rel = 'noopener noreferrer';
      brand.appendChild(hint);
    })
    .catch(() => {});

  // ---- 导航 -------------------------------------------------------------

  /** 某一页此刻该点哪盏灯。轮询的读数优先于 manifest 那一帧。 */
  const lampsFor = (pageId: string): readonly WebUiLamp[] =>
    lamps[pageId] ?? webUiPages.find((p) => p.id === pageId)?.lamps ?? [];

  const addItem = (
    parent: HTMLElement,
    opts: {
      label: string;
      icon?: WebUiIconName;
      /** 带灯的行（贡献方的页）。给了就画灯，`null` 是"还没报"的空位。 */
      pageId?: string;
      segments: readonly string[];
    },
    itemSignal: AbortSignal,
  ): NavEntry => {
    const href = buildHash(opts.segments);
    const item = ui.h('a', 'navitem');
    item.href = href;
    if (opts.icon) {
      item.appendChild(icon(doc, opts.icon, 'navicon'));
      // 窄屏只露图标,名字靠悬停读到。
      item.title = opts.label;
    }
    const label = ui.h('span', 'lbl', opts.label);
    // 名字给灯让位后可能被截断,悬停仍读得到全名(灯自己的说明挂在各自那颗上)。
    if (opts.pageId) label.title = opts.label;
    item.appendChild(label);
    const lampHost = opts.pageId ? lampRow(doc, lampsFor(opts.pageId)) : undefined;
    if (lampHost) item.appendChild(lampHost);
    // 修饰键与中键保留浏览器默认行为；普通左键经 router 导航。
    item.addEventListener('click', (ev) => {
      if (ev.button !== 0) return;
      if (ev.metaKey || ev.ctrlKey || ev.shiftKey || ev.altKey) return;
      ev.preventDefault();
      try {
        router.navigate(opts.segments);
      } catch (err) {
        onError(err);
      }
    }, { signal: itemSignal });
    parent.appendChild(item);
    const entry: NavEntry = {
      el: item,
      segments: opts.segments,
      ...(opts.pageId && lampHost ? { pageId: opts.pageId, lamps: lampHost } : {}),
    };
    entries.push(entry);
    return entry;
  };

  const addGroup = (label: string, kind: 'framework' | 'persona'): HTMLDivElement => {
    // CSS class 仍写 `navgroup-provider`:样式表与构建产物同步,不随类型改名。
    const pageClass = kind === 'framework' ? '' : ' navgroup-provider';
    const group = ui.h('div', `navgroup navgroup-${kind}${pageClass}`);
    group.setAttribute('role', 'group');
    group.setAttribute('aria-label', label);
    group.appendChild(ui.h('div', 'stacklabel', label));
    nav.appendChild(group);
    return group;
  };

  const addPrimary = (label: string): HTMLDivElement => {
    const group = ui.h('div', 'navgroup navgroup-framework navgroup-primary');
    group.setAttribute('role', 'group');
    group.setAttribute('aria-label', label);
    nav.appendChild(group);
    return group;
  };

  const renderNav = (): void => {
    const before = new Set(entries.flatMap(entry => entry.pageId ? [entry.pageId] : []));
    const was = new Map<string, number>();
    if (!prefersStill(doc.defaultView)) for (const { el, pageId } of entries) {
      if (!pageId || !el.animate) continue;
      const rect = el.getBoundingClientRect();
      if (rect.height) was.set(pageId, rect.top);
    }
    const scroll = nav.scrollTop;
    navLife?.abort();
    if (signal.aborted) return;
    navLife = new AbortController();
    const itemSignal = navLife.signal;

    entries = [];
    nav.replaceChildren();

    const pages = features.filter((f) => featureAvailable(f, capabilities));
    const worldRoots = pages.filter((f) => f.navMode === 'world-root');
    const personaTail = pages.filter((f) => f.navMode === 'persona');
    const groups = new Map<string, HTMLElement>();
    for (const f of pages) {
      if (f.navMode === undefined || f.navMode === 'group') {
        const label = f.navGroup;
        let group = groups.get(label);
        if (!group) {
          group = addGroup(label, 'framework');
          groups.set(label, group);
        }
        addItem(group, {
          label: f.label,
          icon: f.icon,
          ...(f.lampId ? { pageId: f.lampId } : {}),
          segments: [f.route],
        }, itemSignal);
      } else if (f.navMode === 'primary') {
        addItem(addPrimary(f.label), {
          label: f.label,
          icon: f.icon,
          ...(f.lampId ? { pageId: f.lampId } : {}),
          segments: [f.route],
        }, itemSignal);
      }
    }

    // 只列已装配的:左栏是"能去的地方",不是全量清单。未装配的仍由各自的
    // 总览页负责露面(那里才有"为什么没装上"的位置)。供应模块(kind `llm`)不在
    // 这里逐个列出:它们的入口是框架的「模型提供商」页,模块清单是那一页里的次级菜单。
    const listed = webUiPages.filter((p) => p.availability === 'active');
    // Persona 页在前,它的 Memory 页跟在后面,再是归这一组的框架页(系统提示词),同一组。
    const personas = [
      ...listed.filter((page) => page.kind === 'persona'),
      ...listed.filter((page) => page.kind === 'memory'),
    ];
    if (personas.length || personaTail.length) {
      const group = addGroup(GROUP_PERSONAS, 'persona');
      for (const p of personas) {
        addItem(group, {
          label: p.label || p.id,
          icon: p.kind === 'memory' ? 'folder-open' : 'bot',
          pageId: p.id,
          segments: [PROVIDER_ROUTE, p.id],
        }, itemSignal);
      }
      for (const f of personaTail) {
        addItem(group, { label: f.label, icon: f.icon, segments: [f.route] }, itemSignal);
      }
    }

    // 用户在 World 列表里设为不显示在侧栏的那些不列。
    const hidden = doc.defaultView ? navHidden(doc.defaultView) : new Set<string>();
    const worldPages = listed.filter((page) => page.kind === 'world' && !hidden.has(page.id));
    const worlds = doc.defaultView ? inNavOrder(doc.defaultView, worldPages, page => page.id) : worldPages;
    if (worldRoots.length || worlds.length) {
      const group = ui.h('div', 'navgroup navgroup-world-tree');
      group.setAttribute('role', 'group');
      group.setAttribute('aria-label', GROUP_WORLDS);
      group.appendChild(ui.h('div', 'stacklabel', GROUP_WORLDS));
      nav.appendChild(group);
      for (const f of worldRoots) {
        addItem(group, {
          label: f.label,
          icon: f.icon,
          segments: [f.route],
        }, itemSignal);
      }
      if (worlds.length) {
        const list = ui.h('div', 'navmodule-list');
        list.setAttribute('role', 'group');
        list.setAttribute('aria-label', S.moduleInstancesAria);
        group.appendChild(list);
        for (const p of worlds) {
          addItem(list, {
            label: p.label || p.id,
            pageId: p.id,
            segments: [PROVIDER_ROUTE, p.id],
          }, itemSignal);
        }
      }
    }

    applyRoute();
    nav.scrollTop = scroll;
    const arriving = entries.some(entry => entry.pageId && !before.has(entry.pageId));
    if (!arriving && was.size) slide(was);
  };

  const slide = (was: ReadonlyMap<string, number>): void => {
    const order = new Map([...was.keys()].map((id, index) => [id, index]));
    const now = entries.flatMap(({ el, pageId }) => {
      const top = pageId ? was.get(pageId) : undefined;
      if (top === undefined) return [];
      const rect = el.getBoundingClientRect();
      return rect.height ? [{ el, dy: top - rect.top, rank: order.get(pageId!)! }] : [];
    });
    const kept = new Set(steadiest(now.map(({ rank }) => rank)));
    for (const { el, dy, rank } of now) {
      if (Math.abs(dy) <= .5) continue;
      const mover = !kept.has(rank);
      if (mover) el.classList.add('nav-reorder');
      const motion = el.animate([{ transform: `translateY(${dy}px)` }, { transform: 'none' }], { duration: 240, easing: 'cubic-bezier(.32, .72, 0, 1)' });
      if (mover) void motion.finished.finally(() => el.classList.remove('nav-reorder')).catch(() => {});
    }
  };

  const applyRoute = (): void => {
    for (const entry of entries) {
      const on = matches(entry, route);
      entry.el.classList.toggle('active', on);
      if (on) entry.el.setAttribute('aria-current', 'page');
      else entry.el.removeAttribute('aria-current');
    }
    const settingsOn = route?.segments[0] === 'settings';
    settingsButton.classList.toggle('active', settingsOn);
    if (settingsOn) settingsButton.setAttribute('aria-current', 'page');
    else settingsButton.removeAttribute('aria-current');
  };

  // ---- bot 实例名 -------------------------------------------------------

  /** 当前展示名；改名时拿它作输入框的初值。 */
  let shownName = DEFAULT_BRAND;

  const setBrand = (name: string | null | undefined): void => {
    const shown = typeof name === 'string' && name.trim() !== '' ? name.trim() : DEFAULT_BRAND;
    shownName = shown;
    botNameText.textContent = shown;
    // 悬停说的是这一下能做什么;全名在改名框里看得到。
    botName.title = S.renameTitle;
    avatar.setLabel(shown);
    doc.title = S.docTitle(shown);
  };

  /**
   * 就地改名。写的是 core 配置里的 `displayName`，与配置页上那一项同一个值。
   * Esc 放弃，回车或失焦提交；名字没变或清空就当放弃。
   */
  const startRename = (): void => {
    const field = ui.input({ value: shownName });
    field.className = 'field rail-rename';
    botName.replaceWith(field);
    field.focus();
    field.select();
    let done = false;
    const finish = (save: boolean): void => {
      if (done) return;
      done = true;
      const next = field.value.trim();
      field.replaceWith(botName);
      if (!save || !next || next === shownName) return;
      setBrand(next);
      void setConfig('core', { displayName: next }).then(
        () => ui.toast(S.renameSaved),
        (err) => {
          ui.toast(S.renameFailed(String((err as Error)?.message ?? err)), 'bad');
          onError(err);
        },
      );
    };
    field.addEventListener('keydown', (event) => {
      if (event.key === 'Enter') finish(true);
      else if (event.key === 'Escape') finish(false);
    }, { signal });
    field.addEventListener('blur', () => finish(true), { signal });
  };
  botName.addEventListener('click', startRename, { signal });
  botName.title = S.renameTitle;

  /**
   * 展示名来自部署配置。**取不到只影响这一个字**：不改状态灯、不报错卡——
   * 外壳没有"整站是否可达"的判据，一个接口的失败也不该被当成那个判据。
   */
  void (async () => {
    const initialRunStatusRevision = runStatusRevision;
    try {
      const st = await get<{
        displayName?: unknown;
        loop?: { paused?: unknown };
      } | null>('/api/status', { signal });
      if (signal.aborted) return;
      const name = st?.displayName;
      if (typeof name === 'string' && name.trim() !== '') setBrand(name);
      if (runStatusRevision === initialRunStatusRevision) setRunStatus(st);
    } catch { /* 留中性缺省 */ }
  })();

  renderNav();
  doc.defaultView?.addEventListener(NAV_HIDDEN_EVENT, renderNav, { signal });

  return {
    el,
    setRoute(next: Route): void {
      route = next;
      applyRoute();
    },
    setBrand,
    setRunStatus,
    setCapabilities(next: Record<string, boolean>): void {
      capabilities = next;
      renderRun();
      renderPower();
      renderNav();
    },
    setPages(next: readonly WebUiPageManifest[]): void {
      webUiPages = next;
      personaSwitch.setEnabled(next.some(p => p.id === NATIVE_ENGINE_PAGE_ID));
      renderNav();
    },
    setLamps(next: Record<string, WebUiLamp[]>): void {
      lamps = next;
      for (const entry of entries) {
        if (entry.lamps && entry.pageId) paintLamps(entry.lamps, lampsFor(entry.pageId));
      }
    },
    dispose(): void {
      navLife?.abort();
      life.abort();
      el.remove();
    },
  };
}
