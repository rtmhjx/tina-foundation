import { pick } from '../../core/language.ts';
import { S as zhHant } from './strings.zh-Hant.ts';
import { S as ja } from './strings.ja.ts';
import { S as ko } from './strings.ko.ts';
import { S as fr } from './strings.fr.ts';
import { S as de } from './strings.de.ts';
import { S as es419 } from './strings.es-419.ts';
import { S as ptBR } from './strings.pt-BR.ts';
import { S as it } from './strings.it.ts';
import { S as ru } from './strings.ru.ts';

const zh = {
  loading: '加载中…',
  optionCurrent: '(当前)',
  ownerPersona: 'Persona',
  chooseFile: '选择文件',
  chooseDirectory: '选择目录',
  recommendedDir: (dir: string) => `推荐目录：${dir}`,
  download: '下载',
  on: '开启',
  autoSaves: '修改后自动保存。',
  saved: '已保存。',
  worldRestartPending: '有改动需重启 World 后生效。',
  leaveBlank: '留空',
  saving: '保存中…',
  saveFailed: (err: string) => '失败：' + err,
  emptyDefault: "此页没有配置项。",
  noSchema: "未提供配置项。",
  restartWorld: '重启 World 生效',
  restartProcess: '重启生效',
  loadFailed: (err: string) => '配置项加载失败：' + err,
};

export const en: typeof zh = {
  loading: 'Loading…',
  optionCurrent: '(current)',
  ownerPersona: 'Persona',
  chooseFile: 'Choose file',
  chooseDirectory: 'Choose directory',
  recommendedDir: (dir: string) => `Recommended directory: ${dir}`,
  download: 'Download',
  on: 'On',
  autoSaves: 'Changes save automatically.',
  saved: 'Saved.',
  worldRestartPending: 'Some changes take effect after the World restarts.',
  leaveBlank: 'Leave blank',
  saving: 'Saving…',
  saveFailed: (err: string) => 'Failed: ' + err,
  emptyDefault: "No configuration fields on this page.",
  noSchema: "No configuration fields provided.",
  restartWorld: 'takes effect after World restart',
  restartProcess: 'takes effect after restart',
  loadFailed: (err: string) => 'Failed to load config: ' + err,
};

export const S = pick({
  zh, en, 'zh-Hant': zhHant, ja, ko, fr, de, 'es-419': es419, 'pt-BR': ptBR, it, ru,
});
