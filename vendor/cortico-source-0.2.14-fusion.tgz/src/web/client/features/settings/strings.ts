import { pick } from '../../core/language.ts';
import { S as zhHant } from './strings.zh-Hant.ts';
import { S as ja } from './strings.ja.ts';
import { S as ko } from './strings.ko.ts';
import { S as fr } from './strings.fr.ts';
import { S as de } from './strings.de.ts';
import { S as es419 } from './strings.es-419.ts';
import { S as ptBR } from './strings.pt-BR.ts';
import { S as it } from './strings.it.ts';
import { S as ru } from './strings.ru.ts';

const zh = {
  general: '通用',
  generalDesc: 'WebUI 语言偏好。',
  language: '界面语言 / Language',
  languageDesc: '仅保存在当前浏览器，刷新页面后生效。',
  reloadTitle: '切换界面语言？',
  reloadBody: '页面将刷新，未保存的编辑会丢失。Bot 将继续运行。',
  access: '访问',
  accessDesc: '这个 WebUI 设置了访问密码;登录态保存在当前浏览器的 Cookie 里。',
  signOut: '退出登录',
  appearance: '外观',
  appearanceDesc: 'WebUI 主题、明暗模式与自定义配色。',

  pageTitle: '设置',
  sectionsAria: '设置分区',
  navLabel: '设置',
};

export const en: typeof zh = {
  general: 'General',
  generalDesc: 'WebUI language preferences.',
  language: '界面语言 / Language',
  languageDesc: 'Saved in this browser; takes effect after reloading.',
  reloadTitle: 'Change interface language?',
  reloadBody: 'The page will reload and unsaved edits will be lost. The bot will keep running.',
  access: 'Access',
  accessDesc: 'This WebUI is protected by an access password; the sign-in is kept in a cookie in this browser.',
  signOut: 'Sign out',
  appearance: 'Appearance',
  appearanceDesc: 'WebUI theme, light/dark mode and custom palettes.',

  pageTitle: 'Settings',
  sectionsAria: 'Settings sections',
  navLabel: 'Settings',
};

export const S = pick({
  zh, en, 'zh-Hant': zhHant, ja, ko, fr, de, 'es-419': es419, 'pt-BR': ptBR, it, ru,
});
