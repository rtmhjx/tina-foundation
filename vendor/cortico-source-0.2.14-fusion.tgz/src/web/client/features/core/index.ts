/**
 * core 的运行态、会话统计、事件流、日志、数据与配置页，不持有或显示人格前缀。
 * 工具表不在这里:那是 Persona 页的框架页签。
 * 子页状态由路由表达；未挂载的能力不显示页签。仅当前子页运行轮询，状态保存在挂载闭包，由调试帧或一次性 GET 填充。
 */

import type { Disposable } from '../../../shared/client-panel.ts';
import type { FeatureContext, FrameworkFeature } from '../feature.ts';
import { pageTabs } from '../../ui/page-tabs.ts';
import { pageIntro } from '../../ui/page.ts';
import { get } from '../../core/api.ts';
import { browserSocketEnv, openFrameworkSocket, type SocketEnv } from '../../core/websocket.ts';
import {
  arr,
  str,
  type SessionStat,
  type StatusSnapshot,
} from '../live/protocol.ts';
import { createEventsView } from './events.ts';
import { createRunlogView } from './runlog.ts';
import { createRunView } from './run.ts';
import { createSessionTable } from './sessions.ts';
import { S } from './strings.ts';
import { createConfigView } from '../config/view.ts';
import { exportDiagnostics } from '../live/diagnostics.ts';
import { S as LIVE_S } from '../live/strings.ts';
import { icon } from '../../ui/icons.ts';
import { createStorageView } from '../storage/view.ts';

const CORE_ROUTE = 'core';
const DEBUG_WS_PATH = '/ws/debug';

/** 一个子页签。`need` 是它依赖的 capability(null = 永远有)。 */
interface SubDef {
  id: string;
  label: string;
  need: string | null;
}

const CORE_SUBS: readonly SubDef[] = [
  { id: 'run', label: S.subRun, need: null },
  { id: 'runlog', label: S.subRunlog, need: null },
  { id: 'data', label: S.subData, need: 'storage' },
  { id: 'config', label: S.subConfig, need: 'config' },
];

export interface CoreFeatureOptions {
  env?: SocketEnv;
}

export function createCoreFeature(opts: CoreFeatureOptions = {}): FrameworkFeature {
  return {
    route: CORE_ROUTE,
    label: S.navLabel,
    icon: 'activity',
    navGroup: S.navGroup,
    // 事件流与运行日志不依赖任何可选表面,所以这一页永远有意义。
    mount(ctx) {
      return mountHarness(ctx, opts.env ?? browserSocketEnv(window));
    },
  };
}

export const coreFeature: FrameworkFeature = createCoreFeature();

/** 上次停留的子页，跨窗口保留。 */
const LAST_SUB_KEY = 'cortico.core.sub';

function mountHarness(ctx: FeatureContext, env: SocketEnv): Disposable | void {
  const { ui } = ctx;

  const state = {
    status: null as StatusSnapshot | null,
    sessions: [] as SessionStat[],
  };

  const subs = CORE_SUBS.filter((s) => s.need === null || ctx.capabilities[s.need] === true);
  // 没指定子页时回到上次停留的那个；切换子页时记下来。
  const storage = ((): Storage | null => { try { return ctx.root.ownerDocument.defaultView?.localStorage ?? null; } catch { return null; } })();
  const wanted = str(ctx.route.segments[1]) || (storage?.getItem(LAST_SUB_KEY) ?? '');
  let current = subs.some((s) => s.id === wanted) ? wanted : (subs[0]?.id ?? 'run');

  // ── 页头 ─────────────────────────────────────────────────────────
  const view = ui.h('div', 'coreview');
  const head = pageIntro(ui, S.pageTitle);
  head.className = 'featureintro pagehead';
  // 换子页是换页面，用页内栏目条。
  const tabs = pageTabs(ctx.root.ownerDocument, ctx.signal, subs.map((s) => ({ value: s.id, label: s.label })), {
    value: current,
    onSelect: (v) => show(v, true),
  });
  const tabBar = tabs.el;
  const net = ui.msgline('');
  const exportButton = ui.button('', {
    size: 'sm',
    onClick: () => {
      void exportDiagnostics({ ui, doc: ctx.root.ownerDocument, signal: ctx.signal }).catch((err: unknown) => {
        ui.toast(LIVE_S.exportFailed, 'bad');
        ctx.onError(err);
      });
    },
  });
  exportButton.className = 'pagetabs-action';
  exportButton.append(icon(ctx.root.ownerDocument, 'download'), ui.h('span', null, LIVE_S.exportDiagnostics));
  tabBar.append(net, ui.h('span', 'grow'), exportButton);
  const scroll = ui.h('div', 'scroll');
  const measure = ui.h('div', 'measure');
  scroll.appendChild(measure);
  view.append(head, tabBar, scroll);
  ctx.root.appendChild(view);

  const setNet = (online: boolean): void => {
    net.className = online ? 'msgline' : 'msgline bad';
    net.textContent = online ? '' : S.netOffline;
  };

  // ── 子页 ─────────────────────────────────────────────────────────
  const run = createRunView({
    ui,
    openProvider: (name) => ctx.router.navigate(name ? ['providers', name] : ['providers']),
  });
  const hasSessions = ctx.capabilities.sessions === true;
  const sessions = createSessionTable(ui);
  const events = createEventsView({
    ui,
    lifecycle: ctx.lifecycle,
    signal: ctx.signal,
    onNet: setNet,
    onError: (err) => ctx.onError(err),
  });
  const runlog = createRunlogView({
    ui,
    signal: ctx.signal,
    onNet: setNet,
    onError: (err) => ctx.onError(err),
  });
  // Core 自己的存储项与配置组:按 owner 取,World / Persona / Memory 的各在自己页上。
  const data = createStorageView({ ui, signal: ctx.signal, filter: (p) => p.owner === 'core', clearAll: true });
  const config = createConfigView({
    ui,
    lifecycle: ctx.lifecycle,
    signal: ctx.signal,
    filter: (group) => group.owner === 'core',
    showOwner: false,
    emptyText: S.configEmpty,
  });

  const runPane = ui.h('div', 'core-run');
  runPane.append(run.el, ...(hasSessions ? [sessions.el] : []), events.el);

  const panes: Record<string, HTMLElement> = {
    run: runPane,
    runlog: runlog.el,
    data: data.el,
    config: config.el,
  };

  /** 每次进入某个子页要做的事。进来才拉数据——没打开的页不该占网络。 */
  const enter: Record<string, () => void> = {
    run: () => {
      run.render(state.status, state.sessions);
      sessions.render(state.sessions);
      if (!hasDebug) {
        void refreshStatus();
        if (hasSessions) void refreshSessions();
      }
      void events.init();
      events.setPolling(!hasDebug);
    },
    runlog: () => {
      void runlog.refresh();
    },
    data: () => {
      void data.load();
    },
    config: () => {
      void config.load();
    },
  };

  function show(sub: string, navigate: boolean): void {
    const next = subs.some((s) => s.id === sub) ? sub : (subs[0]?.id ?? 'run');
    if (next !== current) {
      // 离开事件流就停它的轮询:一个看不见的表不该继续问服务端要数据。
      if (current === 'run') events.setPolling(false);
      current = next;
    }
    tabs.setValue(current);
    try { storage?.setItem(LAST_SUB_KEY, current); } catch { /* 存不下就只记本次 */ }
    while (measure.children.length) measure.children[0].remove();
    const pane = panes[current];
    if (pane) measure.appendChild(pane);
    enter[current]?.();
    if (navigate) ctx.router.navigate([CORE_ROUTE, current]);
  }

  // 地址栏被别处改了(后退键、别的页跳过来)时跟上,不重建整页。
  ctx.lifecycle.own(
    ctx.router.onChange((route) => {
      if (route.segments[0] !== CORE_ROUTE) return;
      const sub = str(route.segments[1]) || (subs[0]?.id ?? 'run');
      if (sub !== current) show(sub, false);
    }),
  );

  // ── 数据 ─────────────────────────────────────────────────────────
  async function refreshStatus(): Promise<void> {
    try {
      const st = await get<StatusSnapshot>('/api/status', { signal: ctx.signal });
      state.status = st;
      setNet(true);
      if (current === 'run') run.render(st, state.sessions);
    } catch (err) {
      if ((err as { name?: string } | null)?.name === 'AbortError') return;
      setNet(false);
      ctx.onError(err);
    }
  }

  async function refreshSessions(): Promise<void> {
    try {
      const d = await get<{ sessions?: SessionStat[] }>('/api/sessions', { signal: ctx.signal });
      state.sessions = d?.sessions ?? [];
      if (current === 'run') {
        sessions.render(state.sessions);
        run.render(state.status, state.sessions);
      }
    } catch (err) {
      if ((err as { name?: string } | null)?.name === 'AbortError') return;
      ctx.onError(err);
    }
  }

  const hasDebug = ctx.capabilities.debug === true;
  if (hasDebug) {
    openFrameworkSocket({
      path: DEBUG_WS_PATH,
      lifecycle: ctx.lifecycle,
      env,
      onNet: setNet,
      onError: (err) => ctx.onError(err),
      onFrame: (f) => {
        switch (f.t) {
          case 'hello':
            state.sessions = arr<SessionStat>(f.sessions);
            state.status = (f.status as StatusSnapshot | null) ?? null;
            if (current === 'run') {
              run.render(state.status, state.sessions);
              sessions.render(state.sessions);
            }
            break;
          case 'status':
            state.status = (f.status as StatusSnapshot | null) ?? null;
            if (current === 'run') run.render(state.status, state.sessions);
            break;
          case 'sessions':
            state.sessions = arr<SessionStat>(f.sessions);
            if (current === 'run') {
              run.render(state.status, state.sessions);
              sessions.render(state.sessions);
            }
            break;
          // 有推送就不必轮询:到了才追一次。
          case 'event':
            if (current === 'run') void events.poll();
            break;
          case 'runlog':
            if (current === 'runlog') runlog.noteLive();
            break;
          default:
            break;
        }
      },
    });
  } else {
    void refreshStatus();
  }

  show(current, false);
}
