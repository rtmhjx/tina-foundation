import type { FeatureContext } from '../feature.ts';
import { get, post } from '../../core/api.ts';
import { Lifecycle } from '../../core/lifecycle.ts';
import { configField, type ConfigGroup } from '../config/view.ts';
import { validateProviderName } from '../../../../providers/name.ts';
import { connectionPath, type Detail, type Editing, type ListedModel, type Module } from './types.ts';
import { pricingEditor } from './pricing.ts';
import type { Disposable } from '../../../shared/client-panel.ts';
import { S } from './strings.ts';
import { notice } from '../../ui/index.ts';

export interface DetailController { dispose(): void; }
interface Options {
  ctx: FeatureContext; root: HTMLElement; modules: Module[]; saved: Detail | null; draft: Editing | null;
  /** Every edit; `dirty` is false when the form again equals the saved connection. */
  changed(editing: Editing, invalid: boolean, dirty: boolean): void;
  onSaved(name: string, select?: boolean): Promise<void>; cancelled(): Promise<void>;
  deleted(): Promise<void>; duplicate(editing: Editing): Promise<void>;
}
type Section = Module['sections'][number];
type Spec = NonNullable<Detail['entry']['spec']>;
/** What a save would write; `raw` only carries field text and never reaches the server. */
const snapshot = (editing: Editing) => JSON.stringify({ name: editing.name, entry: editing.entry, secretValue: editing.secretValue });
/** Protocol knobs the editor keeps under the protocol block; the rest of a module's scalars belong to its own sections. */
const PROTOCOL_FIELDS = ['endpointPath', 'extraHeaders', 'extraBody'];
/**
 * One connection's editor. Sections come from `module.sections` in declared order: a `builtin`
 * names a block drawn here, the rest are the module's own panels, mounted with their edits staged
 * into `editing`.
 */
export async function mountDetail(options: Options): Promise<DetailController> {
  const { ctx, root, saved, modules } = options;
  const { ui } = ctx;
  const lifecycle = new Lifecycle(ctx.onError);
  const opts = { signal: lifecycle.signal };
  const persisted: Editing | null = saved ? { original: saved.name, name: saved.name, entry: saved.entry, revision: saved.revision, secretValue: '', raw: {} } : null;
  const editing: Editing = structuredClone(options.draft ?? persisted!);
  editing.entry.spec ??= { model: '', thinking: false };
  if (persisted) (persisted.entry.spec ??= { model: '', thinking: false });
  const dirty = () => !persisted || snapshot(editing) !== snapshot(persisted);
  const report = ui.msgline();
  const form = ui.h('div');
  root.append(form);
  const errors = new Map<string, () => boolean>();
  let rendering = 0;
  let saving = false;
  const panelHandles: Disposable[] = [];
  let panelHost: ReturnType<NonNullable<FeatureContext['webUiPageHost']>> | null = null;
  /** The model block's way of showing a spec a module panel changed. */
  let syncSpec: (() => void) | null = null;
  /** A saved connection shows the discard button only while the form differs from what is saved. */
  let cancel: HTMLButtonElement | null = null;
  const change = () => {
    if (cancel) cancel.hidden = !!saved && !dirty();
    options.changed(editing, !!form.querySelector('[aria-invalid="true"]'), dirty());
  };
  const run = (work: () => Promise<unknown>, source?: HTMLElement) => {
    if (source) source.after(report);
    report.textContent = '';
    report.classList.remove('bad');
    void work().catch(error => { if (!lifecycle.disposed) { report.textContent = String(error); report.classList.add('bad'); } });
  };
  /** Preview name for an unsaved connection; the server resolves secrets by it. */
  const identity = saved?.name ?? 'draft';
  /** The probe and the model list run on what the form holds, key included, before anything is saved. */
  const draftBody = () => ({ entry: editing.entry, ...(editing.secretValue ? { secretValue: editing.secretValue } : {}) });
  const disposePanels = () => { for (const handle of panelHandles.splice(0)) handle.dispose(); };
  function field(body: HTMLElement, key: string, label: string, value: string, set: (value: string) => void, validate?: (value: string) => string | null, type = 'text') {
    const input = ui.input({ value, type: type as 'text' }); input.setAttribute('aria-label', label);
    const note = ui.h('div', 'field-error');
    const row = ui.h('div', 'connection-field'); row.append(ui.field(label + (['name', 'baseUrl', 'model'].includes(key) ? ' *' : ''), input), note); body.append(row);
    const check = () => { const error = validate?.(input.value); note.textContent = error ?? ''; input.setAttribute('aria-invalid', String(!!error)); return !error; };
    errors.set(key, check);
    input.addEventListener('input', () => { set(input.value); check(); change(); }, opts);
    return input;
  }
  function jsonField(body: HTMLElement, key: string, label: string, value: unknown, array: boolean, set: (value: unknown) => void) {
    const input = ui.textarea({ rows: 4, value: editing.raw[key] ?? (value === undefined ? '' : JSON.stringify(value, null, 2)), cls: 'mono' });
    input.setAttribute('aria-label', label);
    const error = ui.h('div', 'field-error'); body.append(ui.field(label, input), error);
    const check = () => {
      try {
        const parsed: unknown = input.value.trim() ? JSON.parse(input.value) : undefined;
        if (parsed !== undefined && (array ? !Array.isArray(parsed) : !parsed || typeof parsed !== 'object' || Array.isArray(parsed))) throw new Error();
        set(parsed); error.textContent = ''; input.setAttribute('aria-invalid', 'false'); return true;
      } catch { error.textContent = array ? S.jsonArray : S.jsonObject; input.setAttribute('aria-invalid', 'true'); return false; }
    };
    errors.set(key, check);
    if (editing.raw[key] !== undefined) check();
    input.addEventListener('input', () => { editing.raw[key] = input.value; check(); change(); }, opts);
  }
  function block(box: HTMLElement, section: Section, fold = false) {
    const card = fold ? ui.foldSheet('connection-' + section.id, { title: section.title, desc: section.description, defaultOpen: section.defaultOpen ?? true }) : ui.sheet({ title: section.title, desc: section.description });
    if (fold) card.el.classList.add('connection-section');
    const header = fold ? card.el.querySelector('summary') : card.el;
    const title = header?.querySelector('h3');
    if (header && title) {
      const heading = ui.h('div', 'connection-step-heading');
      heading.append(title);
      if (card.desc) heading.append(card.desc);
      header.prepend(heading);
    }
    box.append(card.el); return card.body;
  }
  /** Reads a dotted path under the entry; writes create the objects on the way. */
  const entryPath = (suffix: string) => {
    const parts = suffix.split('.');
    return {
      get: () => parts.reduce<unknown>((value, part) => (value as Record<string, unknown> | undefined)?.[part], editing.entry),
      set: (value: unknown) => {
        let target = editing.entry as unknown as Record<string, unknown>;
        for (const part of parts.slice(0, -1)) target = (target[part] ??= {}) as Record<string, unknown>;
        if (value === undefined) delete target[parts.at(-1)!]; else target[parts.at(-1)!] = value;
      },
    };
  };
  function endpointBlock(box: HTMLElement, section: Section) {
    const body = block(box, section, true);
    field(body, 'baseUrl', S.url, editing.entry.baseUrl, value => { editing.entry.baseUrl = value; }, value => {
      try { const url = new URL(value); return ['https:', 'http:'].includes(url.protocol) && !url.username && !url.password ? null : S.required; } catch { return S.required; }
    });
    const key = field(body, 'key', S.key, editing.secretValue, value => { editing.secretValue = value; }, undefined, 'password');
    key.placeholder = saved?.secretConfigured !== 'none' && saved ? '••••••••' : S.keyEmpty;
    const testResult = ui.msgline();
    const test = ui.button(S.test, { onClick: () => void (async () => {
      test.disabled = true;
      testResult.textContent = '';
      try {
        const result = await post<{ ok: boolean; status: number | null; elapsedMs: number; model?: string; error?: string; hint?: string }>(connectionPath(identity) + '/test', draftBody(), opts);
        testResult.textContent = result.ok ? `${S.testOk} · HTTP ${result.status ?? '—'} · ${(result.elapsedMs / 1000).toFixed(1)}s · ${result.model ?? ''}` : `${S.testFailed}: ${result.hint ?? result.error ?? ''}`;
        testResult.classList.toggle('bad', !result.ok);
      } catch (error) {
        if (lifecycle.disposed) return;
        testResult.textContent = `${S.testFailed}: ${String(error)}`;
        testResult.classList.add('bad');
      } finally { test.disabled = false; }
    })() });
    const testRow = ui.rowbar(); testRow.classList.add('connection-test'); testRow.append(test, testResult);
    if (saved?.readiness.reason) testRow.append(ui.msgline(saved.readiness.reason, true));
    body.append(testRow);
  }
  function modelBlock(box: HTMLElement, section: Section, module: Module, spec: Spec) {
    const body = block(box, section, true);
    const modelInput = field(body, 'model', S.model, spec.model, value => { spec.model = value; }, value => value.trim() ? null : S.required);
    let listedModels: ListedModel[] = [];
    let contextInput: HTMLInputElement | null = null;
    const windowNote = ui.msgline();
    const outputNote = ui.msgline();
    const picker = ui.select({ onChange: value => {
      if (!value) return;
      modelInput.value = value;
      modelInput.dispatchEvent(new Event('input'));
      modelInput.dispatchEvent(new Event('change'));
    } });
    picker.setAttribute('aria-label', S.modelList); picker.hidden = true;
    const noteCatalog = () => {
      const listed = listedModels.find(item => item.id === spec.model);
      picker.value = listed?.id ?? '';
      windowNote.textContent = listedModels.length && !listed?.contextWindow ? S.catalogNoWindow : '';
      outputNote.textContent = listed?.maxOutputTokens ? S.catalogMaxOutput(listed.maxOutputTokens) : '';
    };
    modelInput.addEventListener('change', () => {
      const listed = listedModels.find(item => item.id === modelInput.value);
      if (listed?.contextWindow && contextInput) { spec.contextWindow = listed.contextWindow; contextInput.value = String(listed.contextWindow); delete editing.raw.contextWindow; errors.get('contextWindow')?.(); }
      if (listed?.inputImages !== undefined) { editing.entry.multimodal = listed.inputImages; images.checked = listed.inputImages; }
      change();
      noteCatalog();
    }, opts);
    const fetchResult = ui.msgline();
    const fetch = ui.button(S.fetchModels, { onClick: () => void (async () => {
      fetch.disabled = true;
      fetchResult.textContent = '';
      fetchResult.classList.remove('bad');
      try { const result = await post<{ models: ListedModel[] }>(connectionPath(identity) + '/models', draftBody(), opts);
        listedModels = result.models;
        picker.replaceChildren(...[{ id: '', displayName: '—' }, ...listedModels].map(item => { const option = ui.h('option', null, item.displayName ?? item.id); option.value = item.id; return option; }));
        picker.hidden = !listedModels.length;
        fetchResult.textContent = S.modelsFetched(listedModels.length);
        noteCatalog();
      } catch (error) {
        if (!lifecycle.disposed) { fetchResult.textContent = String(error); fetchResult.classList.add('bad'); }
      } finally { fetch.disabled = false; }
    })() });
    const fetchRow = ui.rowbar(); fetchRow.classList.add('connection-test'); fetchRow.append(fetch, picker, fetchResult); body.append(fetchRow);
    const tiers = module.reasoningTiers;
    if (tiers.length) {
      const select = ui.select({ value: tiers.find(tier => tier.thinking === spec.thinking && tier.effort === spec.reasoningEffort)?.id ?? '', options: tiers.map(tier => ({ value: tier.id, label: tier.label })), onChange: value => {
        const tier = tiers.find(tier => tier.id === value)!; spec.thinking = tier.thinking;
        if (tier.effort) spec.reasoningEffort = tier.effort; else delete spec.reasoningEffort; change();
      } }); select.setAttribute('aria-label', S.reasoning); body.append(ui.field(S.reasoning, select));
    } else field(body, 'reasoning', S.reasoning, !spec.thinking ? 'none' : spec.reasoningEffort ?? '', value => {
      spec.thinking = value !== 'none'; if (value && value !== 'none') spec.reasoningEffort = value; else delete spec.reasoningEffort;
    });
    for (const [name, label] of [['temperature', S.temperature], ['maxTokens', S.maxTokens], ['contextWindow', S.context]] as const) {
      const input = field(body, name, label, editing.raw[name] ?? String(spec[name] ?? ''), value => {
        editing.raw[name] = value; if (!value) delete spec[name]; else spec[name] = Number(value);
      }, value => {
        if (!value) return null;
        const number = Number(value);
        if (!Number.isFinite(number) || !(name === 'temperature' ? number >= 0 && number <= 2 : Number.isInteger(number) && number > 0)) return S.invalidNumber;
        return name === 'contextWindow' && spec.maxTokens !== undefined && number <= spec.maxTokens ? S.contextAboveOutput : null;
      }, 'number');
      if (name === 'contextWindow') contextInput = input;
      if (name === 'maxTokens') {
        body.append(outputNote);
        input.addEventListener('input', () => { errors.get('contextWindow')?.(); change(); }, opts);
      }
    }
    errors.get('contextWindow')?.();
    body.append(windowNote);
    if (module.serviceTiers.length) {
      const select = ui.select({ value: editing.entry.serviceTier ?? '', options: [{ value: '', label: '—' }, ...module.serviceTiers.map(tier => ({ value: tier.id, label: tier.label }))], onChange: value => { editing.entry.serviceTier = value; change(); } });
      select.setAttribute('aria-label', S.tier); body.append(ui.field(S.tier, select));
    }
    const images = ui.h('input'); images.type = 'checkbox'; images.checked = editing.entry.multimodal === true; images.setAttribute('aria-label', S.images);
    images.setAttribute('role', 'switch'); images.classList.add('connection-switch');
    images.addEventListener('change', () => { editing.entry.multimodal = images.checked; change(); }, opts);
    const imagesField = ui.field(S.images, images); imagesField.classList.add('connection-toggle'); body.append(imagesField);
    syncSpec = () => { modelInput.value = spec.model; errors.get('model')?.(); if (contextInput && spec.contextWindow !== undefined) contextInput.value = String(spec.contextWindow); errors.get('contextWindow')?.(); noteCatalog(); };
  }
  function pricingBlock(box: HTMLElement, section: Section) {
    const body = block(box, section, true);
    const prices = pricingEditor(ui, editing.entry.pricing ?? [], saved?.quotes ?? [], value => {
      editing.entry.pricing = value as Detail['entry']['pricing']; change();
    }, { raw: editing.raw.pricing, onRaw: value => { editing.raw.pricing = value; change(); } });
    body.append(prices.body);
    errors.set('pricing', prices.validate);
  }
  /** Module scalars the editor renders itself: declared fields of a module that ships no sections of its own. */
  function groupBlock(box: HTMLElement, group: ConfigGroup) {
    const scalars = Object.entries(group.schema.properties ?? {}).filter(([path, property]) => property.type !== 'object' && !PROTOCOL_FIELDS.some(name => path.endsWith('.' + name)));
    if (!scalars.length) return;
    const body = block(box, { id: group.id, title: group.schema.title ?? group.id, description: group.schema.description });
    for (const [path, property] of scalars) {
      const at = entryPath(path.slice(`providers.${identity}.`.length));
      const control = configField(ui, property, at.get(), () => { if (control.read) { at.set(control.read()); change(); } }, lifecycle.signal);
      control.node.setAttribute('aria-label', property.title ?? path);
      body.append(ui.field(property.title ?? path, control.node));
      if (property.description) body.append(ui.h('p', 'tdesc', property.description));
    }
  }
  function protocolBlock(box: HTMLElement, section: Section, groups: ConfigGroup[]) {
    const body = block(box, section, true);
    field(body, 'secret', S.secret, editing.entry.secret ?? '', value => { if (value) editing.entry.secret = value; else delete editing.entry.secret; });
    for (const group of groups) for (const [path, property] of Object.entries(group.schema.properties ?? {})) {
      const suffix = path.slice(`providers.${identity}.`.length);
      const at = entryPath(suffix);
      if (property.type === 'object') { jsonField(body, path, property.title ?? suffix.split('.').at(-1)!, at.get(), false, at.set); continue; }
      if (!PROTOCOL_FIELDS.some(name => suffix.endsWith(name))) continue;
      const control = configField(ui, property, at.get(), () => { if (control.read) { at.set(control.read()); change(); } }, lifecycle.signal);
      control.node.setAttribute('aria-label', property.title ?? suffix);
      body.append(ui.field(property.title ?? suffix, control.node));
      if (property.description) body.append(ui.h('p', 'tdesc', property.description));
    }
  }
  async function render() {
    const gen = ++rendering;
    disposePanels(); syncSpec = null;
    errors.clear(); form.replaceChildren();
    const identityCard = ui.sheet({ title: S.basic }); identityCard.el.classList.add('connection-identity'); form.append(identityCard.el);
    const basic = identityCard.body;
    field(basic, 'name', S.name, editing.name, value => { editing.name = value; }, value => value === saved?.name ? null : validateProviderName(value) ? S.nameHint : null)
      .placeholder = S.newName;
    basic.append(ui.msgline(S.nameHint));
    const selectedModule = modules.find(module => module.id === editing.entry.kind);
    if (saved) {
      const module = ui.input({ value: selectedModule?.title ?? editing.entry.kind });
      module.readOnly = true;
      module.setAttribute('aria-label', S.module); module.classList.add('connection-module-readonly');
      basic.append(ui.field(S.module, module), ui.msgline(S.fixedModule));
    }
    else {
      const select = ui.select({ value: editing.entry.kind, options: [{ value: '', label: '—' }, ...modules.map(module => ({ value: module.id, label: module.title }))],
        onChange: kind => {
          const module = modules.find(module => module.id === kind);
          editing.entry = { kind, baseUrl: module?.defaultBaseUrl ?? '', spec: { model: '', thinking: module?.reasoningTiers[0]?.thinking ?? true, ...(module?.reasoningTiers[0]?.effort ? { reasoningEffort: module.reasoningTiers[0].effort } : {}) } };
          editing.raw = {}; change(); run(render);
        } });
      select.setAttribute('aria-label', S.module);
      const moduleField = ui.field(S.module + ' *', select);
      const required = ui.h('span', 'connection-module-hint', editing.entry.kind ? '' : S.chooseModule);
      moduleField.querySelector('.fieldlabel')?.append(required);
      basic.append(moduleField);
      errors.set('module', () => { required.textContent = editing.entry.kind ? '' : S.chooseModule; select.setAttribute('aria-invalid', String(!editing.entry.kind)); return !!editing.entry.kind; });
    }
    const spec = editing.entry.spec ??= { model: '', thinking: false };
    const actions = ui.h('div', 'connection-actions');
    if (saved) {
      actions.append(ui.button(S.remove, { variant: 'danger', onClick: ev => run(async () => {
        const current = await get<Detail>(connectionPath(saved.name), opts);
        if (current.references.length) { await notice(ui, { title: S.remove, body: S.referenced + current.references.join(', ') }); return; }
        if (!(await ui.confirm({ title: S.remove, body: S.deleteConfirm, danger: true }))) return;
        await post(connectionPath(saved.name) + '/delete', { expectedRevision: saved.revision }, opts); await options.deleted();
      }, ev.currentTarget as HTMLElement) }), ui.button(S.duplicate, { onClick: ev => run(() => options.duplicate({ original: null, copyFrom: { name: saved.name, revision: saved.revision }, name: (validateProviderName(saved.name) ? 'Connection' : saved.name) + '-Copy', entry: structuredClone(saved.entry), secretValue: '', raw: {} }), ev.currentTarget as HTMLElement) }));
    }
    cancel = ui.button(S.cancel, { onClick: () => run(() => options.cancelled()) });
    cancel.hidden = !!saved && !dirty();
    actions.append(ui.h('span', 'grow'), cancel, ui.button(S.save, { variant: 'primary', onClick: ev => run(() => save(), ev.currentTarget as HTMLElement) }), report);
    form.append(actions, ui.h('div', 'connection-shared', S.shared), ui.h('div', 'connection-shared', S.draftNote));
    if (!selectedModule) return;
    const flow = ui.h('div', 'connection-flow');
    identityCard.el.after(flow);
    const groups = (await post<ConfigGroup[]>('/api/provider-modules/config', { name: identity, entry: editing.entry }, opts)).filter(group => !group.id.endsWith('.connection'));
    if (gen !== rendering || lifecycle.disposed) return;
    const ownSections = selectedModule.sections.some(section => !section.builtin);
    const pending: Array<{ section: Section; host: HTMLElement }> = [];
    for (const section of selectedModule.sections) {
      const box = ui.h('div', 'connection-step'); flow.append(box);
      switch (section.builtin) {
        case 'connection-endpoint': endpointBlock(box, section); break;
        case 'connection-model':
          modelBlock(box, section, selectedModule, spec);
          if (!ownSections) for (const group of groups) groupBlock(box, group);
          break;
        case 'connection-pricing': pricingBlock(box, section); break;
        case 'connection-protocol': protocolBlock(box, section, groups); break;
        default: pending.push({ section, host: block(box, section, true) });
      }
    }
    if (!pending.length || !ctx.webUiPageHost) return;
    panelHost ??= ctx.webUiPageHost({ root: ui.h('div'), route: () => ['providers', saved?.name ?? ''] });
    await panelHost.load();
    if (gen !== rendering || lifecycle.disposed) return;
    for (const { section, host } of pending) {
      const handle = await panelHost.mountConnection(`llm:${editing.entry.kind}`, section.id, host, { instance: identity }, context => ({
        ...context,
        setConfig: async (_id, values) => {
          for (const [path, value] of Object.entries(values)) {
            const prefix = `providers.${identity}.`;
            if (!path.startsWith(prefix)) throw new Error('Foreign connection field');
            entryPath(path.slice(prefix.length)).set(value);
          }
          change(); return S.unsaved;
        },
        invoke: async <T>(method: string, args?: unknown[]): Promise<T> => {
          const before = JSON.stringify(editing.entry);
          const reply = await post<{ result: T; entry: Detail['entry'] }>('/api/provider-modules/preview', { name: identity, entry: editing.entry, panel: context.panelId, method, args }, opts);
          if (before === JSON.stringify(editing.entry) && JSON.stringify(reply.entry) !== before) {
            if (reply.entry.spec) Object.assign(spec, reply.entry.spec);
            editing.entry = { ...reply.entry, spec }; syncSpec?.(); change();
          }
          return reply.result;
        },
        refresh: async () => {},
      }));
      if (gen !== rendering || lifecycle.disposed) { handle.dispose(); return; }
      panelHandles.push(handle);
    }
  }
  async function save(select = true): Promise<boolean> {
    if (saving) return false;
    const valid = [...errors.values()].map(check => check()).every(Boolean); change();
    if (!valid) {
      for (const input of form.querySelectorAll('[aria-invalid="true"]')) { const fold = input.closest('details'); if (fold) fold.open = true; }
      report.textContent = S.readiness.invalid; report.classList.add('bad'); return false;
    }
    saving = true;
    try {
      const result = await post<Detail>(saved ? connectionPath(saved.name) + '/save' : '/api/providers', { name: editing.name, entry: editing.entry, expectedRevision: editing.revision, copyFrom: editing.copyFrom, ...(editing.secretValue ? { secretValue: editing.secretValue } : {}) }, opts);
      await options.onSaved(result.name, select); return true;
    } catch (error) { report.textContent = String(error); report.classList.add('bad'); return false; }
    finally { saving = false; }
  }
  await render(); change();
  return { dispose: () => { lifecycle.dispose(); disposePanels(); panelHost?.unmount(); } };
}
