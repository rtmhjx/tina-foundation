import type { ContextRecord } from '../../../../protocol/open-responses/context.ts';
/**
 * 页面状态由 /ws/debug 推送，保存在挂载闭包中，随 Lifecycle 释放。
 * 调试通道不可用时改用 /ws/sessions，只接收 session 列表。
 */

import type {
  WebUiStreamHandle,
  Disposable,
} from '../../../shared/client-panel.ts';
import { panelStreamRoute } from '../../../shared/webui-protocol.ts';
import type { FeatureContext, FrameworkFeature } from '../feature.ts';
import { get, post } from '../../core/api.ts';
import { openStream } from '../../core/stream.ts';
import { browserSocketEnv, openFrameworkSocket, type SocketEnv } from '../../core/websocket.ts';
import { buildCtxPanel, computeCtx, type ContextBreakdown } from './context.ts';
import { exportDiagnostics } from './diagnostics.ts';
import { createForkView, MAIN_ID, MAIN_LABEL } from './fork.ts';
import {
  arr,
  loopOf,
  str,
  type RunPhase,
  type SessionStat,
  type StatusSnapshot,
  type ToolSchemaDoc,
} from './protocol.ts';
import { icon } from '../../ui/icons.ts';
import { pageIntro } from '../../ui/page.ts';
import { promptInput } from '../../ui/prompt-input.tsx';
import { createOnboarding, type OnboardingView } from './onboarding.ts';
import { createSessionBand } from './sessions.ts';
import { applyDisplayName, createConnectionButton, createStatusBand, phaseLabel, type ViewedSession } from './status.ts';
import { S } from './strings.ts';
import { createTimeline } from './timeline.ts';
import type { UsageAggregate } from '../usage/types.ts';
import { S as UsageS } from '../usage/strings.ts';
import { createPersonaSwitch } from '../../ui/persona-switch.ts';

const DEBUG_WS_PATH = '/ws/debug';
const SESSIONS_WS_PATH = '/ws/sessions';

/** 测试注入点:不传就是真浏览器那一套。 */
export interface LiveFeatureOptions {
  env?: SocketEnv;
}

export function createLiveFeature(opts: LiveFeatureOptions = {}): FrameworkFeature {
  return {
    route: 'live',
    label: S.navLabel,
    icon: 'console',
    navMode: 'primary',
    // 两条通道任一挂着这一页就有意义;都没有的话导航里根本不出现它。
    needsAny: ['debug', 'sessions'],
    mount(ctx) {
      return mountLive(ctx, opts.env ?? browserSocketEnv(window));
    },
  };
}

/** 缺省实例。host 直接用这个。 */
export const liveFeature: FrameworkFeature = createLiveFeature();

function ctxRingStyle(d: ContextBreakdown | null): string {
  if (!d || !d.total || d.maxTokens === null) return '--ctx-ring:conic-gradient(var(--border) 0 100%)';
  const stops: string[] = [];
  let cursor = 0;
  for (const cat of d.cats) {
    if (cat.tok <= 0) continue;
    const next = Math.min(100, cursor + cat.tok / d.maxTokens * 100);
    if (next > cursor) stops.push(`${cat.color} ${cursor.toFixed(2)}% ${next.toFixed(2)}%`);
    cursor = next;
  }
  stops.push(`var(--border) ${cursor.toFixed(2)}% 100%`);
  return `--ctx-ring:conic-gradient(${stops.join(',')})`;
}

function mountLive(ctx: FeatureContext, env: SocketEnv): Disposable | void {
  const { ui } = ctx;
  const doc = ctx.root.ownerDocument;

  // ── 这一页的全部活数据 ────────────────────────────────────────────
  const state = {
    messages: [] as ContextRecord[],
    /** 合成开头，不写入 session 记录。 */
    head: [] as ContextRecord[],
    toolSchemas: [] as ToolSchemaDoc[],
    status: null as StatusSnapshot | null,
    sessions: [] as SessionStat[],
    displayName: '',
    /** 主循环运行阶段,只取自调试通道的帧;断线时清空。 */
    phase: null as RunPhase | null,
  };

  const view = ui.h('div', 'liveview');
  const band = ui.h('div', 'liveband');
  view.append(pageIntro(ui, S.navLabel), band);
  ctx.root.appendChild(view);

  // ── 顶栏 ──────────────────────────────────────────────────────────
  const status = createStatusBand(ui);
  status.render(null);

  const timeline = createTimeline({ ui, lifecycle: ctx.lifecycle, signal: ctx.signal });

  const sessionBand = createSessionBand({
    ui,
    signal: ctx.signal,
    onPick: (id, label) => fork.switchTo(id, label),
  });

  const ctxAnchor = ui.h('span', 'ctxanchor');
  const ctxOpen = ui.h('button', 'ctxdonut');
  ctxOpen.type = 'button';
  ctxOpen.setAttribute('aria-haspopup', 'dialog');
  ctxOpen.setAttribute('aria-expanded', 'false');
  ctxOpen.setAttribute('aria-label', S.ctxOpenAria);
  const ctxPct = ui.h('span', 'ctxpct', '—');
  ctxOpen.appendChild(ctxPct);
  ctxAnchor.appendChild(ctxOpen);

  let ctxPanel: HTMLElement | null = null;
  const closeCtx = (): void => {
    ctxPanel?.remove();
    ctxPanel = null;
    ctxOpen.setAttribute('aria-expanded', 'false');
  };
  ctxOpen.addEventListener('click', () => {
    if (ctxPanel) {
      closeCtx();
      return;
    }
    ctxPanel = buildCtxPanel(
      ui,
      computeCtx({
        messages: state.messages,
        head: state.head,
        toolSchemas: state.toolSchemas,
        status: state.status,
      }),
    );
    ctxPanel.setAttribute('role', 'dialog');
    ctxPanel.setAttribute('aria-label', S.ctxPanelAria);
    ctxAnchor.appendChild(ctxPanel);
    ctxOpen.setAttribute('aria-expanded', 'true');
  }, { signal: ctx.signal });
  doc.addEventListener('pointerdown', (event) => {
    if (ctxPanel && !ctxAnchor.contains(event.target as Node)) closeCtx();
  }, { signal: ctx.signal });
  doc.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') closeCtx();
  }, { signal: ctx.signal });

  /** 运行阶段说的是主 session,查看后台会话时不显示。 */
  const syncActivity = (): void => {
    timeline.setActivity(fork.isMain() ? phaseLabel(ui, state.phase) : null);
  };

  let netEl: HTMLElement = ui.pill(S.netConnecting, 'plain');
  const setNet = (online: boolean): void => {
    if (!online) {
      state.phase = null;
      syncActivity();
    }
    const next = ui.pill(online ? S.netOnline : S.netOffline, online ? 'on' : 'off');
    netEl.replaceWith(next);
    netEl = next;
  };

  const summary = ui.h('div', 'live-summary');
  const connection = createConnectionButton(ui, (name) => ctx.router.navigate(name ? ['providers', name] : ['providers']));
  // 今日花费:`/api/usage` 部署时区的今天;没有 usage 能力、totals 为 null 或取不到时不显示。
  // 服务端每次都整本读账本，所以只在挂载时和 main 记下一次调用后重取，过了零点要等下一次调用才换到新的一天。
  const cost = ui.button('', { onClick: () => ctx.router.navigate(['usage']) });
  cost.className = 'live-cost';
  cost.hidden = true;
  const usageOn = ctx.capabilities.usage === true;
  let costSeq = 0;
  const loadCost = async (): Promise<void> => {
    const seq = ++costSeq;
    try {
      const d = await get<UsageAggregate>('/api/usage?bucket=day&days=1', { signal: ctx.signal });
      if (seq !== costSeq) return;
      const t = d.totals;
      cost.hidden = !t;
      if (!t) return;
      const partial = (t.unpricedCalls || 0) > 0 ? '+' : '';
      const unknown = (t.unpricedCalls || 0) > 0 && !(t.pricedCalls || 0) && !t.cost;
      cost.textContent = S.todayCost(unknown ? UsageS.unknown : ui.fmt.money(t.cost ?? 0, d.currency || 'USD') + partial);
      cost.title = S.todayCostTitle(t.calls || 0);
    } catch (err) {
      if ((err as { name?: string } | null)?.name === 'AbortError' || seq !== costSeq) return;
      cost.hidden = true;
    }
  };
  let costSoon: ReturnType<typeof setTimeout> | undefined;
  /** 去抖：同一轮里接连几次调用只重取一回。 */
  const refreshCostSoon = (): void => {
    if (!usageOn) return;
    clearTimeout(costSoon);
    costSoon = setTimeout(() => { void loadCost(); }, 4000);
  };
  ctx.signal.addEventListener('abort', () => clearTimeout(costSoon), { once: true });
  if (usageOn) void loadCost();

  // 右边三项是一组:放不下时整组换行
  const right = ui.h('div', 'live-summary-right');
  // Persona switcher (inline variant) sits at the leading edge of the status strip.
  const personaSwitch = createPersonaSwitch({
    variant: 'inline',
    doc,
    ui,
    signal: ctx.signal,
    onError: (err) => ctx.onError(err),
  });
  // Probe once on mount; silently hides itself if world:native-engine is absent (404).
  personaSwitch.setEnabled(true);
  right.append(personaSwitch.el, connection.el, cost, netEl);
  summary.append(status.el, right);
  const sessions = ui.h('div', 'live-sessions');
  sessions.append(ui.h('span', 'live-sessions-label', S.sessionsLabel), sessionBand.el);
  band.append(summary, sessions);

  const exportButton = ui.button('', {
    onClick: () => {
      void exportDiagnostics({ ui, doc, signal: ctx.signal }).catch((err: unknown) => {
        ui.toast(S.exportFailed, 'bad');
        ctx.onError(err);
      });
    },
  });
  exportButton.className = 'live-export';
  exportButton.append(icon(doc, 'download'), ui.h('span', null, S.exportDiagnostics));
  sessions.appendChild(exportButton);

  const composer = promptInput(doc, ctx.signal, {
    label: S.composerLabel,
    draftKey: 'cortico.console.draft.live',
    placeholder: S.composerPlaceholder,
    tools: ctxAnchor,
    images: { max: 8 },
    onSubmit: (text, images) => {
      if (!chatStream?.open) ui.toast(S.composerQueued);
      // 首启时运行是停着的（见 launcher）；发话与按下那颗按钮同样是让它开始跑。
      if (onboarding) {
        void resumeRun();
        dismissOnboarding();
      }
      const attached = images.map((i) => ({ mime: i.mime, base64: i.base64, name: i.name }));
      chatStream?.send(JSON.stringify({ type: 'msg', text, ...(attached.length ? { images: attached } : {}) }));
      return true;
    },
  });
  view.append(timeline.el, composer.el);
  timeline.rebuild([], { empty: S.emptyConnecting });

  let providerReady = false;
  const syncPlaceholder = (): void => {
    composer.setPlaceholder(!fork.isMain() ? S.composerFork : providerReady ? null : S.composerNoProvider);
  };

  const resumeRun = (): Promise<unknown> => post('/api/run/resume', {}, { signal: ctx.signal });

  /**
   * 开场引导认部署目录里那个一次性标记（`.onboarding`，自建部署时写入）。session 与事件游标
   * 都当不了判据：全新部署起来就有一条系统前缀和一条 session 开场事件，而上下文交接后 session
   * 反倒是空的。
   */
  let onboarding: OnboardingView | null = null;
  /** 本次挂载里已经收过一次；销标记的请求在路上时状态帧还会报 pending。 */
  let dismissed = false;
  const dismissOnboarding = (): void => {
    dismissed = true;
    void post('/api/onboarding/dismiss', {}, { signal: ctx.signal }).catch(() => { /* 下次打开再收 */ });
    syncOnboarding();
  };
  const syncOnboarding = (): void => {
    const fresh = !dismissed && state.status?.onboardingPending === true;
    if (fresh && !onboarding) {
      onboarding = createOnboarding({
        ui,
        doc,
        signal: ctx.signal,
        go: (segments) => ctx.router.navigate(segments),
        start: (label) => {
          void resumeRun().then(
            () => {
              chatStream?.send(JSON.stringify({ type: 'greet', label }));
              dismissOnboarding();
            },
            (err) => ctx.onError(err),
          );
        },
      });
      onboarding.setProvider(providerReady);
      timeline.setHeader(onboarding.el);
      // 引导期间系统前缀那张卡先收起来:这一页此刻要说的是怎么把 bot 配起来。
      timeline.setHideSystem(true);
      timeline.rebuild(state.messages, { head: state.head });
      return;
    }
    if (!fresh && onboarding) {
      timeline.setHeader(null);
      onboarding = null;
      timeline.setHideSystem(false);
      timeline.rebuild(state.messages, { head: state.head });
    }
  };

  const hello = JSON.stringify({ type: 'hello', name: '控制台' });
  let chatStream: WebUiStreamHandle | null = null;

  // ── fork 视图 ─────────────────────────────────────────────────────
  const fork = createForkView({
    ui,
    lifecycle: ctx.lifecycle,
    signal: ctx.signal,
    timeline,
    mainMessages: () => state.messages,
    mainHead: () => state.head,
    sessions: () => state.sessions,
    onChange: () => {
      sessionBand.render(state.sessions, fork.id);
      renderStatus();
      syncPlaceholder();
      syncActivity();
    },
    onError: (err) => ctx.onError(err),
  });

  const updateCtx = (): void => {
    const d = computeCtx({
      messages: state.messages,
      head: state.head,
      toolSchemas: state.toolSchemas,
      status: state.status,
    });
    ctxOpen.setAttribute('style', ctxRingStyle(d));
    const known = d !== null && d.maxTokens !== null && d.maxTokens > 0;
    const ratio = known ? d.total / d.maxTokens! : 0;
    // 分母未知(Persona没报预算、Provider 也没报窗口)时圈里只写计数,不编百分比
    ctxPct.textContent = d ? (known ? ui.fmt.percent(ratio) : ui.fmt.count(d.total)) : '—';
    ctxOpen.className = `ctxdonut${ratio >= 1 ? ' danger' : d && d.softTokens !== null && d.total >= d.softTokens ? ' warn' : ''}`;
    ctxOpen.title = d
      ? S.ctxTitle(ui.fmt.count(d.total), known ? ui.fmt.count(d.maxTokens!) : null)
      : S.ctxWaiting;
  };

  const mainStat = (): SessionStat | null => state.sessions.find((s) => s.id === MAIN_ID) ?? null;
  /** 看着 fork 时顶栏的 token 三项报它的;主视图时是 null。 */
  const viewed = (): ViewedSession | null => fork.isMain()
    ? null
    : { label: fork.label, stat: state.sessions.find((s) => s.id === fork.id) ?? null, estTokens: fork.estTokens };
  const renderStatus = (): void => status.render(state.status, mainStat(), viewed());

  const setStatus = (st: StatusSnapshot | null): void => {
    state.status = st;
    renderStatus();
    connection.render(st);
    providerReady = st?.modelConnection?.ready === true;
    syncPlaceholder();
    onboarding?.setProvider(providerReady);
    if (st && applyDisplayName(doc, st.displayName, state.displayName)) {
      state.displayName = str(st.displayName);
    }
    if (st) timeline.setSpeaker(str(st.displayName));
    updateCtx();
  };

  const setSessions = (list: SessionStat[]): void => {
    const before = mainStat()?.calls;
    state.sessions = list;
    const after = mainStat()?.calls;
    // 会话统计与账本在同一处记账：main 的调用数涨了，账本里已有那次调用
    if (before !== undefined && after !== undefined && after > before) refreshCostSoon();
    renderStatus();
    sessionBand.render(list, fork.id);
    fork.noteSessions();
  };

  // ── 调试帧 ────────────────────────────────────────────────────────
  const onFrame = (f: Readonly<Record<string, unknown>>): void => {
    switch (f.t) {
      case 'hello': {
        state.toolSchemas = arr<ToolSchemaDoc>(f.toolSchemas);
        state.messages = arr<ContextRecord>(f.session);
        state.head = arr<ContextRecord>(f.head);
        // 重连即回到主视图:那个 fork 的轮询若还开着,这里连它一起收。
        fork.switchTo(MAIN_ID, MAIN_LABEL);
        // 先记说话人再铺时间线:头像占位圆的首字在画气泡时就定了。
        setStatus((f.status as StatusSnapshot | null) ?? null);
        timeline.rebuild(state.messages, { head: state.head });
        setSessions(arr<SessionStat>(f.sessions));
        state.phase = loopOf(state.status).phase ?? null;
        syncActivity();
        break;
      }
      case 'session.append': {
        const index = f.index;
        if (typeof index === 'number' && Number.isInteger(index) && index >= 0) {
          if (index < state.messages.length) break;
          if (index === state.messages.length) {
            const message = f.message as ContextRecord;
            state.messages.push(message);
            if (fork.isMain()) timeline.append(message, index, true);
            break;
          }
        }
        // 缺失、非法或跳跃的索引需要重新获取完整会话。
        socket?.dispose();
        reopenDebug();
        break;
      }
      case 'session.reset':
        state.messages = arr<ContextRecord>(f.messages);
        if (f.head !== undefined) state.head = arr<ContextRecord>(f.head);
        if (f.toolSchemas !== undefined) state.toolSchemas = arr<ToolSchemaDoc>(f.toolSchemas);
        if (fork.isMain()) {
          timeline.rebuild(state.messages, { note: S.sessionResetNote, head: state.head });
        }
        break;
      case 'status':
        setStatus((f.status as StatusSnapshot | null) ?? null);
        state.phase = loopOf(state.status).phase ?? null;
        syncActivity();
        break;
      case 'phase':
        state.phase = (f.phase as RunPhase | null) ?? null;
        syncActivity();
        break;
      case 'sessions':
        setSessions(arr<SessionStat>(f.sessions));
        break;
      case 'sys':
        // 服务端明说通道不可用:别再画"连接中",也别让 fork 轮询留着。
        fork.switchTo(MAIN_ID, MAIN_LABEL);
        state.messages = [];
        timeline.rebuild([], { empty: str(f.text) || S.debugUnavailable });
        break;
      default:
        break; // 认不出的帧忽略:服务端以后加帧型不该让这一页炸
    }
    updateCtx();
    syncOnboarding();
  };

  let socket: Disposable | null = null;
  const reopenDebug = (): void => {
    socket = openFrameworkSocket({
      path: DEBUG_WS_PATH,
      lifecycle: ctx.lifecycle,
      env,
      onFrame,
      onNet: setNet,
      onError: (err) => ctx.onError(err),
    });
  };

  if (ctx.capabilities.debug) {
    reopenDebug();
  } else {
    timeline.rebuild([], { empty: S.debugNotMounted });
    // 状态读数仍然有:`/api/status` 是框架端点,不随调试通道走。
    void get<StatusSnapshot>('/api/status', { signal: ctx.signal }).then(
      (st) => {
        setStatus(st);
        setNet(true);
        syncOnboarding();
      },
      (err) => {
        if ((err as { name?: string } | null)?.name === 'AbortError') return;
        setNet(false);
        ctx.onError(err);
      },
    );
    if (ctx.capabilities.sessions) {
      openFrameworkSocket({
        path: SESSIONS_WS_PATH,
        lifecycle: ctx.lifecycle,
        env,
        onFrame: (f) => {
          if (f.t === 'sessions') setSessions(arr<SessionStat>(f.sessions));
        },
        onNet: setNet,
        onError: (err) => ctx.onError(err),
      });
    }
  }

  chatStream = ctx.lifecycle.own(openStream({
    url: env.wsUrl(panelStreamRoute('world:console', 'chat')),
    signal: ctx.signal,
    createSocket: env.createSocket,
    setTimer: env.setTimer,
    clearTimer: env.clearTimer,
    onError: (err) => ctx.onError(err),
    handlers: {
      // 时间线由调试通道画;这条流上只读控制台 World 对本连接所发帧的拒收与附带说明。
      message: (raw) => {
        let frame: unknown;
        try {
          frame = JSON.parse(raw);
        } catch {
          return;
        }
        const { type, kind, text } = (frame ?? {}) as { type?: unknown; kind?: unknown; text?: unknown };
        if (type !== 'sys' || typeof text !== 'string') return;
        if (kind === 'rejected') ui.toast(text, 'bad');
        else if (kind === 'warning') ui.toast(text);
      },
      close: (willRetry) => {
        if (willRetry) chatStream?.send(hello);
      },
    },
  }));
  chatStream.send(hello);
}
