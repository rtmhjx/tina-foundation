/**
 * 模型上下文中的结构标记，用于缺失、截断、不可用或中断的内容。
 * 标记使用英文，不受 WebUI 语言设置影响；语义说明由 Persona 提供。
 */

/** 工具回执被折叠(见 truncate.ts 的 FOLD_THRESHOLD) */
export const FOLD_PLACEHOLDER = '[result folded]';
/** 调用入参被折叠 */
export const FOLD_ARGS_PLACEHOLDER = '[arguments folded]';
/** 单条越过整份预算,整条换成记号 */
export const OVERSIZE_PLACEHOLDER = '[turn too long, omitted]';

/** 配对修复:重建后调用还开着,补一条回执 */
export const MISSING_RESULT = '[result missing]';
/** 进程重启后，为未完成的调用补充缺失回执。 */
export const MISSING_RESULT_RESTART = '[result missing (process restart)]';
/** 主线程调用仍在执行时，fork 快照中的临时回执。 */
export const PENDING_IN_MAIN_THREAD = '[result pending in the main thread]';

/** 工具名不在本 session 的工具表里 */
export const UNKNOWN_TOOL = '[unknown tool]';
/** fork 调用了当前工具表中不存在的名称。 */
export const forkUnknownTool = (name: string): string =>
  `[unknown tool ${name}] This thread wires a subset of the tools. Use the ones listed above.`;

/** 上游把这次调用标成未完成(流被截断),参数不可信,不执行 */
export const NOT_EXECUTED_INCOMPLETE = '[not executed: function call incomplete]';
/** 屏障工具(barrierAfter)之后同一条消息里的调用 */
export const NOT_EXECUTED_BARRIER = '[not executed: review the preceding tool result first]';
/** 接在屏障跳过的回执之后，列出同一条消息里越过屏障照常执行的 streamsOutput 工具 */
export const streamedPastBarrier = (names: readonly string[]): string =>
  `[streaming tools in this response ran as usual: ${names.join(', ')}]`;
/** fork 已结束，同一条消息中后续的调用不执行。 */
export const NOT_EXECUTED_THREAD_ENDED = '[not executed: this thread already ended]';
/** 流在响应中途断了,提前派发的调用没跑完 */
export const NOT_EXECUTED_STREAM_ABORTED = '[not executed: stream aborted mid-response]';
/** interrupt 事件到达时本轮尚未开始的调用 */
export const NOT_EXECUTED_INTERRUPTED = '[not executed: interrupted by a new event]';
/** interruptible 工具执行期间发出过 interrupt 信号,接在它的回执之后;做到哪一步由回执正文说明 */
export const INTERRUPTED_WHILE_RUNNING = '[an interrupt signal was sent while this tool ran]';
/** 主循环已停 */
export const NOT_EXECUTED_LOOP_STOPPED = '[not executed: main loop stopped]';
/** 关机打断了这一轮,回执取不回来了 */
export const SHUTDOWN_INTERRUPTED = '[tool result unavailable: shutdown interrupted the round]';

/** 取消原因：作为在途调用的 AbortSignal.reason，并传给 OutputTap.onAbort；工具抛出它时进入失败回执。 */
export const ABORT_PREEMPTED = 'model round preempted by new input';
export const ABORT_INTERRUPTED = 'model round interrupted by a new event';
/** interruptible 工具收到的 interrupt 信号的原因。 */
export const ABORT_TOOL_INTERRUPTED = 'interrupted by a new event';
/** 主循环停止时的取消原因：中止在途轮次与关机信号，并传给 OutputTap.onAbort。 */
export const ABORT_SHUTDOWN = 'core is shutting down';
/** World 停止或卸载后，旧宿主的 pushEvent / pushCandidate 抛错时带这段文本，认知请求以它作为 error。 */
export const HOST_LIFECYCLE_ENDED = 'host lifecycle ended';

/** 工具失败的模型可见标记；结构化失败状态使用 ToolOutcome.failed。 */
export const toolFailed = (detail: string): string => `[tool failed] ${detail}`;
/** 参数不是合法 JSON:不进 handler,就地失败 */
export const TOOL_FAILED_BAD_ARGS = toolFailed('arguments are not valid JSON');
/** handler 的返回值既不是字符串也不是带字符串 text 的对象 */
export const toolFailedBadReturn = (tool: string, got: string): string =>
  toolFailed(`${tool} broke the tool return contract: returned ${got}, expected a string or { text: string }`);

/** 合成投递帧的表头(见 loop.ts 的 EXTERNAL_EVENT_FRAME) */
export const eventFrameHeader = (count: number): string =>
  `[${count} new event${count === 1 ? '' : 's'}]`;
/** 读取投递帧正文时使用，需与写入的表头一致。 */
export const EVENT_FRAME_HEADER_RE = /^\[\d+ new events?\]\n?/;
