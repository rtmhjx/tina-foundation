## {{world.id}}
{{world.envPrompt}}
