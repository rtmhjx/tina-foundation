/** Model choices are bot-owned; framework WebUI surfaces are derived by `createBot`. */
import { resolve } from 'node:path';
import type { BotDefinition, BotParts } from 'cortico/bot.ts';
import type { CoreConfig, World } from 'cortico/core/types.ts';
import type { LoadedConfig } from 'cortico/deploy.ts';
import { CORE_DEFAULTS } from 'cortico/core/config.ts';
import { describeTools, type WorldDeclaration } from 'cortico/world.ts';
import type { ConsoleConfigSection } from 'cortico/worlds/console/config.ts';
import { CORMINI_CONTEXT_DEFAULTS, CORMINI_TOOL_DECLS, CORMINI_TOOL_SUMMARIES, Cormini, type ContextStagePolicy } from './persona/persona.ts';
import { contextStageConfigGroup } from './persona/config.ts';
import { readTextFile } from 'cortico/core/util.ts';

const HERE = resolve(import.meta.dirname);

export interface CorminiConfig extends CoreConfig {
  /** 阶段长度三项与首轮对话开关归 Persona,摘思维链归 core;同住 context 段。 */
  context: CoreConfig['context'] & ContextStagePolicy;
  rounds: { soft: number; hard: number };
  /** null disables baseline wakeups. */
  tick: { intervalMinutes: number | null };
  worlds: {
    console: ConsoleConfigSection;
  };
}

/** 这个Persona为之设计的渠道:只有控制台。 */
const DECLARES: readonly WorldDeclaration[] = ['console'];

function build(loaded: LoadedConfig<CorminiConfig>, worlds: World[]): BotParts<CorminiConfig> {
  const cfg = loaded.config;

  const persona = new Cormini({
    memoryDir: loaded.memoryDir,
    context: () => cfg.context,
    rounds: { ...cfg.rounds },
    seedConstitution: readTextFile(resolve(HERE, 'persona/CONSTITUTION.seed.md')),
    worlds: worlds,
    // 部署侧的自述覆盖:存在就用它,WebUI 保存也落到那边(见 PromptDocDecl.deploymentPath)。
    orientationOverrideFile: resolve(loaded.rootDir, 'prompts', 'ORIENTATION.md'),
    // 首轮对话是部署者自己写的,与 ORIENTATION 覆盖同住 prompts/;代码包不带。
    firstTurnDir: resolve(loaded.rootDir, 'prompts'),
    // Read per wakeup so WebUI changes take effect immediately.
    tickDelayMs: () =>
      cfg.tick.intervalMinutes === null ? null : cfg.tick.intervalMinutes * 60_000,
  });

  return {
    persona,
    onStart: () => {
      persona.startRhythm();
    },
    onStop: () => {
      persona.stopRhythm();
    },
    webUi: {
      configGroups: (language) => [contextStageConfigGroup('cormini', language)],
      // 阶段预算与软预警线(控制台页上下文圈的分母与黄线);计数与物理上限由 core 报
      status: () => ({ context: { maxTokens: cfg.context.maxTokens, softRatio: cfg.context.softRatio } }),
    },
  };
}

const definition: BotDefinition<CorminiConfig> = {
  id: 'cormini',
  memoryName: 'GitMem',
  declares: DECLARES,
  defaults: () => ({
    ...CORE_DEFAULTS,
    displayName: '可缇mini',
    providers: {},
    web: { port: 7788, theme: 'mint' },
    paths: { memory: 'workspace', data: 'data' },
    batching: { ...CORE_DEFAULTS.batching },
    // session 阶段长度属于人格配置。
    context: { ...CORMINI_CONTEXT_DEFAULTS, ...CORE_DEFAULTS.context },
    tick: { intervalMinutes: null },
    rounds: { soft: 6, hard: 12 },
  } as unknown as CorminiConfig),
  build,
  describe: {
    tools: describeTools(CORMINI_TOOL_DECLS, CORMINI_TOOL_SUMMARIES),
    memory: {
      form: {
        zh: '工作区目录里的文本文件;CONSTITUTION.md 与文件清单进系统前缀,其余按需用文件工具读写。',
        en: 'Text files in a workspace directory; CONSTITUTION.md and the file listing are in the system prefix, the rest is read and written with the file tools.',
      },
    },
  },
};

export default definition;
